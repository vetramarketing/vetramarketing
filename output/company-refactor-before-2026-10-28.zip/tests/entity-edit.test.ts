import assert from 'node:assert/strict';
import test from 'node:test';
import { entityEditIsCurrent } from '../src/lib/entity-edit';
import type { Group, Store } from '../src/lib/types';

const group: Group = {
  id: 'group-1',
  storeId: 'vetra',
  name: 'Local group',
  facebookId: '878540877111439',
  category: 'Community',
  notes: 'Original notes',
};

const store: Store = {
  id: 'vetra',
  name: 'VETRA',
  logoImageUrl: '',
  ownerName: '',
  sortOrder: 0,
  initials: 'VT',
  color: '#263b4b',
  description: 'Original description',
};

test('a group editor accepts an unchanged entity and rejects concurrent edits or deletion', () => {
  assert.equal(entityEditIsCurrent(group, { ...group }), true);
  assert.equal(entityEditIsCurrent(group, { ...group, notes: 'Edited in another tab' }), false);
  assert.equal(
    entityEditIsCurrent(group, { ...group, deletedAt: new Date().toISOString() }),
    false,
  );
  assert.equal(entityEditIsCurrent(group, undefined), false);
});

test('a store editor rejects concurrent edits without conflating field order', () => {
  assert.equal(
    entityEditIsCurrent(store, {
      sortOrder: store.sortOrder,
      ownerName: store.ownerName,
      logoImageUrl: store.logoImageUrl,
      description: store.description,
      color: store.color,
      initials: store.initials,
      name: store.name,
      id: store.id,
    }),
    true,
  );
  assert.equal(entityEditIsCurrent(store, { ...store, name: 'Renamed elsewhere' }), false);
});

test('a new editor accepts a free ID but rejects an ID created elsewhere', () => {
  assert.equal(entityEditIsCurrent<Group>(null, undefined), true);
  assert.equal(entityEditIsCurrent<Group>(null, group), false);
});
