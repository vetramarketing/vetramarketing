import assert from 'node:assert/strict';
import test from 'node:test';
import { createEmptyWorkspace, createSampleWorkspace } from '../src/lib/data';
import type { Workspace } from '../src/lib/types';
import {
  LocalWorkspaceRepository,
  WorkspaceRemovedError,
  WorkspaceRevisionConflict,
  WorkspaceUnreadableError,
  type WorkspaceEventSource,
  type WorkspaceStorage,
} from '../src/lib/workspace-repository';
import {
  LEGACY_WORKSPACE_KEY,
  PREVIOUS_WORKSPACE_KEY,
  OLDER_WORKSPACE_KEY,
  V3_WORKSPACE_KEY,
  V2_WORKSPACE_KEY,
  serializeWorkspace,
  WORKSPACE_KEY,
} from '../src/lib/workspace-storage';

class MemoryStorage implements WorkspaceStorage {
  readonly values = new Map<string, string>();
  failWrites = false;

  getItem(key: string): string | null {
    return this.values.get(key) ?? null;
  }

  setItem(key: string, value: string): void {
    if (this.failWrites) throw new Error('Storage quota exceeded');
    this.values.set(key, value);
  }
}

class FakeStorageEvents implements WorkspaceEventSource {
  readonly listeners = new Set<(event: StorageEvent) => void>();

  addEventListener(_type: 'storage', listener: (event: StorageEvent) => void): void {
    this.listeners.add(listener);
  }

  removeEventListener(_type: 'storage', listener: (event: StorageEvent) => void): void {
    this.listeners.delete(listener);
  }

  emit(key: string, newValue: string | null): void {
    for (const listener of this.listeners) listener({ key, newValue } as StorageEvent);
  }
}

function sampleLegacy(): Workspace {
  const workspace = createSampleWorkspace(new Date('2026-10-16T10:00:00Z'));
  workspace.sample = false;
  workspace.posts = workspace.posts.map((post) => ({
    ...post,
    metrics: post.viewers === null ? [] : [{ date: '2026-10-16', viewers: post.viewers }],
  }));
  return workspace;
}

test('first load creates v6 once, and revisions are stable across repository instances', async () => {
  const storage = new MemoryStorage();
  const first = await new LocalWorkspaceRepository(storage).load();
  const raw = storage.getItem(WORKSPACE_KEY);
  assert.ok(raw);
  assert.deepEqual(JSON.parse(raw), serializeWorkspace(createEmptyWorkspace()));
  assert.deepEqual(first.workspace, createEmptyWorkspace());
  assert.match(first.revision, /^[0-9a-f]{64}$/);

  const second = await new LocalWorkspaceRepository(storage).load();
  assert.equal(second.revision, first.revision);
  assert.equal(storage.getItem(WORKSPACE_KEY), raw);
});

test('v3, v2 and v1 workspaces migrate to v7 without deleting recovery copies', async () => {
  const legacy = sampleLegacy();
  const v2 = {
    ...legacy,
    version: 2,
    posts: legacy.posts.map(({ title, content, status, scheduledAt, ...post }) => post),
  };
  const v3 = { ...v2, version: 3, posts: v2.posts.filter((post) => post.publishedAt) };
  for (const [key, source] of [
    [V3_WORKSPACE_KEY, v3],
    [V2_WORKSPACE_KEY, v2],
    [LEGACY_WORKSPACE_KEY, legacy],
  ] as const) {
    const storage = new MemoryStorage();
    const backup = JSON.stringify(source);
    storage.setItem(key, backup);
    const snapshot = await new LocalWorkspaceRepository(storage).load();
    assert.equal(
      snapshot.workspace.posts.length,
      legacy.posts.filter((post) => post.status === 'published').length,
    );
    assert.ok(snapshot.workspace.posts.every((post) => !('status' in post)));
    assert.equal(JSON.parse(storage.getItem(WORKSPACE_KEY)!).version, 7);
    assert.equal(storage.getItem(key), backup);
  }
});

test('corrupt active data is preserved even when an older valid backup exists', async () => {
  const storage = new MemoryStorage();
  const repository = new LocalWorkspaceRepository(storage);
  storage.setItem(WORKSPACE_KEY, '{broken-json');
  storage.setItem(
    PREVIOUS_WORKSPACE_KEY,
    JSON.stringify(serializeWorkspace(createEmptyWorkspace())),
  );
  await assert.rejects(repository.load(), WorkspaceUnreadableError);
  assert.equal(repository.readPreservedRaw(), '{broken-json');

  const restored = await repository.recover(createEmptyWorkspace());
  assert.equal(JSON.parse(storage.getItem(WORKSPACE_KEY)!).version, 7);
  assert.equal(
    storage.getItem(PREVIOUS_WORKSPACE_KEY),
    JSON.stringify(serializeWorkspace(createEmptyWorkspace())),
  );
  assert.equal((await repository.load()).revision, restored.revision);
});

test('an unreadable v5 copy is preserved and does not silently fall back to v1', async () => {
  const storage = new MemoryStorage();
  storage.setItem(PREVIOUS_WORKSPACE_KEY, '{broken');
  storage.setItem(LEGACY_WORKSPACE_KEY, JSON.stringify(sampleLegacy()));
  await assert.rejects(new LocalWorkspaceRepository(storage).load(), WorkspaceUnreadableError);
  assert.equal(storage.getItem(WORKSPACE_KEY), null);
  assert.equal(storage.getItem(PREVIOUS_WORKSPACE_KEY), '{broken');
});

test('commit accepts the loaded revision and rejects stale writes from another instance', async () => {
  const storage = new MemoryStorage();
  const firstRepository = new LocalWorkspaceRepository(storage);
  const secondRepository = new LocalWorkspaceRepository(storage);
  const first = await firstRepository.load();
  const second = await secondRepository.load();
  const candidate = structuredClone(first.workspace);
  candidate.stores[0].name = 'Updated store';
  const saved = await firstRepository.commit({
    workspace: candidate,
    expectedRevision: first.revision,
    operationId: 'save-one',
  });
  assert.equal(saved.workspace.stores[0].name, 'Updated store');
  assert.notEqual(saved.revision, first.revision);

  const stale = structuredClone(second.workspace);
  stale.stores[0].name = 'Stale store';
  await assert.rejects(
    secondRepository.commit({
      workspace: stale,
      expectedRevision: second.revision,
      operationId: 'save-two',
    }),
    WorkspaceRevisionConflict,
  );
  assert.equal((await secondRepository.load()).workspace.stores[0].name, 'Updated store');
});

test('pin toggles persist after reload and a stale tab cannot undo the new state', async () => {
  const storage = new MemoryStorage();
  const firstRepository = new LocalWorkspaceRepository(storage);
  const secondRepository = new LocalWorkspaceRepository(storage);
  const empty = await firstRepository.load();
  const workspace = structuredClone(empty.workspace);
  workspace.posts.push({
    id: 'tracked-post',
    storeId: 'vetra',
    groupId: '',
    product: 'Honey',
    platform: 'facebook',
    publishedAt: '',
    facebookPostId: '',
    url: 'https://example.com/post',
    viewers: 10,
    color: '#263b4b',
  });
  const created = await firstRepository.commit({
    workspace,
    expectedRevision: empty.revision,
    operationId: 'create-post',
  });
  const stale = await secondRepository.load();
  assert.equal(stale.workspace.posts[0].pinned, false);

  const pinned = structuredClone(created.workspace);
  pinned.posts[0].pinned = true;
  await firstRepository.commit({
    workspace: pinned,
    expectedRevision: created.revision,
    operationId: 'pin-post',
  });
  assert.equal(
    (await new LocalWorkspaceRepository(storage).load()).workspace.posts[0].pinned,
    true,
  );
  await assert.rejects(
    secondRepository.commit({
      workspace: stale.workspace,
      expectedRevision: stale.revision,
      operationId: 'stale-unpin',
    }),
    WorkspaceRevisionConflict,
  );
  assert.equal((await secondRepository.load()).workspace.posts[0].pinned, true);
});

test('racing saves through one repository cannot both pass the same revision', async () => {
  const storage = new MemoryStorage();
  const repository = new LocalWorkspaceRepository(storage);
  const baseline = await repository.load();
  const first = structuredClone(baseline.workspace);
  first.stores[0].name = 'First';
  const second = structuredClone(baseline.workspace);
  second.stores[0].name = 'Second';

  const results = await Promise.allSettled([
    repository.commit({
      workspace: first,
      expectedRevision: baseline.revision,
      operationId: 'race-one',
    }),
    repository.commit({
      workspace: second,
      expectedRevision: baseline.revision,
      operationId: 'race-two',
    }),
  ]);
  assert.equal(results.filter((result) => result.status === 'fulfilled').length, 1);
  const rejected = results.find((result) => result.status === 'rejected');
  assert.ok(rejected?.status === 'rejected');
  assert.ok(rejected.reason instanceof WorkspaceRevisionConflict);
  assert.equal((await repository.load()).workspace.stores[0].name, 'First');
});

test('same-instance retries are idempotent, but an operation ID cannot represent different data', async () => {
  const storage = new MemoryStorage();
  const repository = new LocalWorkspaceRepository(storage);
  const baseline = await repository.load();
  const candidate = structuredClone(baseline.workspace);
  candidate.stores[0].name = 'VETRA One';
  const request = {
    workspace: candidate,
    expectedRevision: baseline.revision,
    operationId: 'once',
  };
  const saved = await repository.commit(request);
  assert.deepEqual(await repository.commit(request), saved);
  const changed = structuredClone(candidate);
  changed.stores[0].name = 'VETRA Two';
  await assert.rejects(
    repository.commit({ ...request, workspace: changed }),
    WorkspaceRevisionConflict,
  );
  assert.equal((await repository.load()).workspace.stores[0].name, 'VETRA One');
});

test('invalid candidates and failed writes leave the previous workspace intact', async () => {
  const storage = new MemoryStorage();
  const repository = new LocalWorkspaceRepository(storage);
  const baseline = await repository.load();
  const raw = storage.getItem(WORKSPACE_KEY);
  const invalid = structuredClone(baseline.workspace);
  invalid.stores = [];
  await assert.rejects(
    repository.commit({
      workspace: invalid,
      expectedRevision: baseline.revision,
      operationId: 'invalid',
    }),
  );
  assert.equal(storage.getItem(WORKSPACE_KEY), raw);

  storage.failWrites = true;
  const changed = structuredClone(baseline.workspace);
  changed.stores[0].name = 'New name';
  await assert.rejects(
    repository.commit({
      workspace: changed,
      expectedRevision: baseline.revision,
      operationId: 'failed-write',
    }),
  );
  assert.equal(storage.getItem(WORKSPACE_KEY), raw);
});

test('backup helpers and language preference use only their existing storage keys', async () => {
  const storage = new MemoryStorage();
  const repository = new LocalWorkspaceRepository(storage);
  await repository.load();
  assert.equal(repository.readLocale(), 'th');
  repository.writeLocale('en');
  assert.equal(repository.readLocale(), 'en');
  assert.equal(storage.getItem('vetra-marketing.locale'), 'en');
  storage.setItem(PREVIOUS_WORKSPACE_KEY, 'previous copy');
  storage.setItem(OLDER_WORKSPACE_KEY, 'older copy');
  storage.setItem(V3_WORKSPACE_KEY, 'v3 copy');
  storage.setItem(V2_WORKSPACE_KEY, 'v2 copy');
  storage.setItem(LEGACY_WORKSPACE_KEY, 'legacy copy');
  assert.deepEqual(repository.listOlderBackups(), [
    { key: PREVIOUS_WORKSPACE_KEY, version: 'v5' },
    { key: OLDER_WORKSPACE_KEY, version: 'v4' },
    { key: V3_WORKSPACE_KEY, version: 'v3' },
    { key: V2_WORKSPACE_KEY, version: 'v2' },
    { key: LEGACY_WORKSPACE_KEY, version: 'v1' },
  ]);
  assert.equal(repository.readOlderBackup(PREVIOUS_WORKSPACE_KEY), 'previous copy');
  assert.equal(repository.readOlderBackup(OLDER_WORKSPACE_KEY), 'older copy');
  assert.equal(repository.readOlderBackup(V3_WORKSPACE_KEY), 'v3 copy');
  assert.equal(repository.readOlderBackup(V2_WORKSPACE_KEY), 'v2 copy');
  assert.equal(repository.readOlderBackup(LEGACY_WORKSPACE_KEY), 'legacy copy');
  assert.equal(repository.readOlderBackup('other-site-secret'), null);
});

test('storage subscriptions report validated external changes and can unsubscribe', async () => {
  const storage = new MemoryStorage();
  const events = new FakeStorageEvents();
  const repository = new LocalWorkspaceRepository(storage, events);
  const baseline = await repository.load();
  const changed = structuredClone(baseline.workspace);
  changed.stores[0].name = 'Another tab';
  const nextRaw = JSON.stringify(serializeWorkspace(changed));
  const received = new Promise<unknown>((resolve) => {
    const unsubscribe = repository.subscribe((message) => {
      unsubscribe();
      resolve(message);
    });
  });
  storage.setItem(WORKSPACE_KEY, nextRaw);
  events.emit(WORKSPACE_KEY, nextRaw);
  const message = await received;
  assert.ok(message && typeof message === 'object' && 'workspace' in message);
  assert.equal((message as { workspace: Workspace }).workspace.stores[0].name, 'Another tab');
  assert.equal(events.listeners.size, 0);
});

test('a removed active key blocks subscribers instead of loading an empty workspace', async () => {
  const storage = new MemoryStorage();
  const events = new FakeStorageEvents();
  const repository = new LocalWorkspaceRepository(storage, events);
  await repository.load();
  const messages: Array<unknown> = [];
  const unsubscribe = repository.subscribe((message) => messages.push(message));
  storage.values.delete(WORKSPACE_KEY);
  events.emit(WORKSPACE_KEY, null);
  assert.equal(messages.length, 1);
  assert.ok(messages[0] instanceof WorkspaceRemovedError);
  assert.equal(storage.getItem(WORKSPACE_KEY), null);
  unsubscribe();
});
