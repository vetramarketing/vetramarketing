import assert from 'node:assert/strict';
import test from 'node:test';
import {
  isWorkspaceView,
  viewFromPath,
  workspacePath,
  workspaceViews,
} from '../src/lib/workspace-routes';

test('every workspace section has a direct URL and can be restored from it', () => {
  for (const view of workspaceViews) {
    const path = workspacePath(view);
    assert.equal(viewFromPath(path), view);
    assert.equal(viewFromPath(path === '/' ? path : `${path}/`), view);
    assert.equal(isWorkspaceView(view), true);
  }
});

test('unrecognized and nested paths are not workspace sections', () => {
  assert.equal(viewFromPath('/missing'), null);
  assert.equal(viewFromPath('/posts/123'), null);
  assert.equal(isWorkspaceView('main'), false);
});
