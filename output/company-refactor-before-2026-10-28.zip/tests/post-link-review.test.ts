import assert from 'node:assert/strict';
import test from 'node:test';
import { createEmptyWorkspace } from '../src/lib/data';
import { reviewPostLink } from '../src/lib/post-link-review';
import type { Group, Post, Workspace } from '../src/lib/types';

function group(id: string, facebookId: string): Group {
  return {
    id,
    storeId: 'vetra',
    name: `Group ${facebookId}`,
    facebookId,
    category: '',
    notes: '',
  };
}

function post(overrides: Partial<Post> = {}): Post {
  return {
    id: 'candidate',
    storeId: 'vetra',
    groupId: 'group-123',
    product: 'Coffee Blossom Honey',
    platform: 'facebook',
    publishedAt: '',
    facebookPostId: '',
    url: '',
    viewers: null,
    color: '#263b4b',
    ...overrides,
  };
}

function workspace(groups: Group[], posts: Post[]): Workspace {
  return { ...createEmptyWorkspace(), groups, posts };
}

test('review finds the existing record across Facebook link variants, including Trash', () => {
  const tracked = post({
    id: 'tracked',
    facebookPostId: '456',
    url: 'https://www.facebook.com/groups/123/posts/456/',
    deletedAt: '2026-10-17T00:00:00Z',
  });
  const data = workspace([group('group-123', '123')], [tracked]);

  for (const url of [
    'https://m.facebook.com/groups/123/permalink/456/?fbclid=share',
    'https://www.facebook.com/groups/123/?multi_permalinks=456&ref=share',
  ]) {
    const result = reviewPostLink(data, post({ id: 'new-record', url }));
    assert.equal(result.exactMatch?.id, tracked.id);
    assert.deepEqual(result.possibleMetaRows, []);
  }

  const ownEdit = reviewPostLink(data, { ...tracked, url: tracked.url });
  assert.equal(ownEdit.exactMatch, null);
});

test('same-group linkless Meta rows are suggestions, never an automatic exact match', () => {
  const meta86 = post({
    id: 'provided-meta-row-86',
    publicationStatus: 'pending',
    metaSourceRow: 86,
    metaGroupKey: '123',
  });
  const meta117 = post({
    id: 'provided-meta-row-117',
    publicationStatus: 'pending',
    metaSourceRow: 117,
    metaGroupKey: '123',
  });
  const otherGroup = post({
    id: 'provided-meta-row-95',
    groupId: 'group-999',
    metaSourceRow: 95,
    metaGroupKey: '999',
  });
  const trashed = post({
    id: 'provided-meta-row-96',
    metaSourceRow: 96,
    metaGroupKey: '123',
    deletedAt: '2026-10-17T00:00:00Z',
  });
  const linked = post({
    id: 'linked',
    facebookPostId: '789',
    url: 'https://www.facebook.com/groups/123/posts/789/',
  });
  const data = workspace(
    [group('group-123', '123'), group('group-999', '999')],
    [meta86, meta117, otherGroup, trashed, linked],
  );

  const result = reviewPostLink(
    data,
    post({ id: 'new-record', url: 'https://www.facebook.com/groups/123/posts/456/' }),
  );
  assert.equal(result.exactMatch, null);
  assert.deepEqual(
    result.possibleMetaRows.map((item) => item.id),
    [meta86.id, meta117.id],
  );

  const edit = reviewPostLink(data, {
    ...meta86,
    url: 'https://www.facebook.com/groups/123/posts/456/',
  });
  assert.deepEqual(
    edit.possibleMetaRows.map((item) => item.id),
    [meta117.id],
  );
});

test('pending group context can identify exact and provisional matches before the group is saved', () => {
  const pendingGroup = group('unsaved-group', '123');
  const tracked = post({ id: 'tracked', facebookPostId: '456', url: '' });
  const provisional = post({
    id: 'provided-meta-row-86',
    groupId: '',
    publicationStatus: 'pending',
    metaSourceRow: 86,
    metaGroupKey: '123',
  });
  const data = workspace([group('group-123', '123')], [tracked, provisional]);

  const result = reviewPostLink(
    data,
    post({ id: 'new-record', groupId: pendingGroup.id, facebookPostId: '456' }),
    pendingGroup,
  );
  assert.equal(result.exactMatch?.id, tracked.id);
  assert.deepEqual(
    result.possibleMetaRows.map((item) => item.id),
    [provisional.id],
  );
});

test('a page URL does not suggest the group from a provisional row being edited', () => {
  const provisional = post({
    id: 'provided-meta-row-86',
    metaSourceRow: 86,
    metaGroupKey: '123',
  });
  const data = workspace([group('group-123', '123')], [provisional]);
  const result = reviewPostLink(data, {
    ...provisional,
    groupId: '',
    url: 'https://www.facebook.com/examplepage/posts/789',
  });
  assert.equal(result.exactMatch, null);
  assert.deepEqual(result.possibleMetaRows, []);
});

test('a Facebook group slug link suggests only matching linkless Meta rows', () => {
  const provisional = post({
    id: 'provided-meta-row-90',
    groupId: '',
    metaSourceRow: 90,
    metaGroupKey: 'promoinsider',
  });
  const data = workspace([], [provisional]);
  const result = reviewPostLink(
    data,
    post({
      id: 'new-record',
      groupId: '',
      url: 'https://www.facebook.com/groups/promoinsider/posts/789/',
    }),
  );
  assert.deepEqual(
    result.possibleMetaRows.map((item) => item.id),
    [provisional.id],
  );
});
