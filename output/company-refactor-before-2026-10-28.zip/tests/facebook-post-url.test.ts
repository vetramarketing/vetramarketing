import assert from 'node:assert/strict';
import test from 'node:test';
import { parseFacebookGroupPostUrl } from '../src/lib/facebook-post-url';

const groupId = '878540877111439';
const postId = '1441014217530766';
const expected = { groupId, postId };

test('extracts group and post IDs from Facebook permalink and posts URLs', () => {
  for (const segment of ['permalink', 'posts']) {
    assert.deepEqual(
      parseFacebookGroupPostUrl(`https://www.facebook.com/groups/${groupId}/${segment}/${postId}/`),
      expected,
    );
    assert.deepEqual(
      parseFacebookGroupPostUrl(
        ` https://www.facebook.com/groups/${groupId}/${segment}/${postId}?ref=share#comments `,
      ),
      expected,
    );
  }
});

test('accepts common Facebook host variants and preserves large ID strings', () => {
  for (const host of ['facebook.com', 'www.facebook.com', 'm.facebook.com', 'web.facebook.com']) {
    assert.deepEqual(
      parseFacebookGroupPostUrl(`https://${host}/groups/${groupId}/posts/${postId}`),
      expected,
    );
  }
});

test('accepts the single-post multi_permalinks group share format', () => {
  assert.deepEqual(
    parseFacebookGroupPostUrl(
      `https://www.facebook.com/groups/${groupId}/?multi_permalinks=${postId}&ref=share`,
    ),
    expected,
  );
});

test('accepts 40-digit IDs and rejects 41-digit group or post IDs', () => {
  const fortyDigitId = '1'.repeat(40);
  const longId = '1'.repeat(41);
  assert.deepEqual(
    parseFacebookGroupPostUrl(`https://facebook.com/groups/${fortyDigitId}/posts/${fortyDigitId}`),
    { groupId: fortyDigitId, postId: fortyDigitId },
  );
  assert.equal(
    parseFacebookGroupPostUrl(`https://facebook.com/groups/${longId}/posts/${postId}`),
    null,
  );
  assert.equal(
    parseFacebookGroupPostUrl(`https://facebook.com/groups/${groupId}/permalink/${longId}`),
    null,
  );
  assert.equal(
    parseFacebookGroupPostUrl(`https://facebook.com/groups/${groupId}/?multi_permalinks=${longId}`),
    null,
  );
});

test('rejects URLs that cannot confidently identify one Facebook group post', () => {
  const invalid = [
    '',
    'not a URL',
    `http://www.facebook.com/groups/${groupId}/posts/${postId}`,
    `https://facebook.com.evil.example/groups/${groupId}/posts/${postId}`,
    `https://notfacebook.com/groups/${groupId}/posts/${postId}`,
    `https://user@www.facebook.com/groups/${groupId}/posts/${postId}`,
    `https://www.facebook.com:8443/groups/${groupId}/posts/${postId}`,
    `https://www.facebook.com/groups/example/posts/${postId}`,
    `https://www.facebook.com/groups/${groupId}/posts/example`,
    `https://www.facebook.com/groups/${groupId}/posts/${postId}/comments`,
    `https://www.facebook.com/${groupId}/posts/${postId}`,
    `https://www.facebook.com/groups/${groupId}/`,
    `https://www.facebook.com/groups/${groupId}/?multi_permalinks=invalid`,
    `https://www.facebook.com/groups/${groupId}/?multi_permalinks=${postId}&multi_permalinks=2`,
    `https://www.facebook.com/permalink.php?story_fbid=${postId}&id=${groupId}`,
  ];

  for (const url of invalid) assert.equal(parseFacebookGroupPostUrl(url), null, url);
});
