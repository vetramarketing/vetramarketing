import assert from 'node:assert/strict';
import test from 'node:test';
import {
  readPostListReturnState,
  withPostListReturnState,
  type PostListReturnState,
} from '../src/lib/post-list-navigation';

const list: PostListReturnState = {
  storeId: 'vetra',
  productId: 'eshan-honey',
  search: 'ขนม coffee',
  platform: 'facebook',
  statusFilter: 'normal',
  sort: 'viewers',
  scrollX: 0,
  scrollY: 1452.5,
  tableScrollLeft: 120,
};

test('all seven sort options survive browser history restoration', () => {
  for (const sort of [
    'viewers',
    'viewers-per-day',
    'recent',
    'date-asc',
    'title',
    'group',
    'store',
  ] as const) {
    const selected = { ...list, sort };
    assert.deepEqual(readPostListReturnState(withPostListReturnState(null, selected)), selected);
  }
});

test('return state retains every filter and both scroll positions without changing router history', () => {
  const router = { __NA: true, tree: ['posts'], unrelated: { value: 1 } };
  const before = structuredClone(router);
  const saved = withPostListReturnState(router, list);
  assert.deepEqual(readPostListReturnState(saved), list);
  assert.deepEqual(router, before);
  assert.equal(saved.tree, router.tree);
  assert.equal(saved.unrelated, router.unrelated);
  assert.equal(saved.__NA, true);
});

test('history entries keep independent list positions and replace only their own prior snapshot', () => {
  const first = withPostListReturnState(null, list);
  const later = {
    ...list,
    search: '',
    storeId: 'all',
    productId: 'all',
    scrollY: 0,
    sort: 'recent' as const,
  };
  const second = withPostListReturnState(first, later);
  assert.deepEqual(readPostListReturnState(first), list);
  assert.deepEqual(readPostListReturnState(second), later);
});

test('older post-list history restores its status choice without losing filters', () => {
  const { productId: _productId, statusFilter: _statusFilter, ...oldList } = list;
  assert.deepEqual(readPostListReturnState({ vetraPostList: { version: 1, ...oldList } }), {
    ...list,
    productId: 'all',
    statusFilter: 'normal',
  });
  assert.deepEqual(
    readPostListReturnState({
      vetraPostList: { version: 2, ...oldList, productId: list.productId },
    }),
    list,
  );
  assert.deepEqual(
    readPostListReturnState({
      vetraPostList: { version: 3, ...oldList, productId: list.productId, pendingOnly: true },
    }),
    { ...list, statusFilter: 'pending' },
  );
  assert.deepEqual(
    readPostListReturnState({
      vetraPostList: { version: 4, ...oldList, productId: list.productId, showPending: true },
    }),
    { ...list, statusFilter: 'all' },
  );
});

test('each status filter survives browser history restoration', () => {
  for (const statusFilter of ['normal', 'pending', 'no-link', 'all'] as const) {
    const selected = { ...list, statusFilter };
    assert.deepEqual(readPostListReturnState(withPostListReturnState(null, selected)), selected);
  }
});

test('unknown or malformed browser history is ignored without interrupting navigation', () => {
  for (const state of [null, [], 'old', { vetraPostList: null }, { vetraPostList: {} }])
    assert.equal(readPostListReturnState(state), null);
  for (const change of [
    { version: 6 },
    { platform: 'unknown' },
    { sort: 'growth' },
    { storeId: '' },
    { productId: '' },
    { productId: 17 },
    { statusFilter: 'hidden' },
    { search: null },
    { scrollY: -1 },
    { scrollX: Infinity },
    { tableScrollLeft: '120' },
  ]) {
    assert.equal(
      readPostListReturnState({ vetraPostList: { version: 5, ...list, ...change } }),
      null,
    );
  }
});
