import assert from 'node:assert/strict';
import test from 'node:test';
import { createEmptyWorkspace } from '../src/lib/data';
import { PostConflictError, preparePostSave } from '../src/lib/post-save';
import {
  PostGroupSaveError,
  preparePostSaveWithGroup,
  type PostGroupSaveReason,
} from '../src/lib/post-save-with-group';
import type { Group, Post, Workspace } from '../src/lib/types';

function group(overrides: Partial<Group> = {}): Group {
  return {
    id: 'pending-group',
    storeId: 'vetra',
    name: 'Community',
    facebookId: '878540877111439',
    category: '',
    notes: '',
    ...overrides,
  };
}

function post(overrides: Partial<Post> = {}): Post {
  return {
    id: 'new-post',
    storeId: 'vetra',
    groupId: 'pending-group',
    title: '',
    content: '',
    product: 'Coffee Blossom Honey',
    platform: 'facebook',
    status: 'published',
    scheduledAt: '',
    publishedAt: '2026-10-15T03:00:00Z',
    facebookPostId: '1441014217530766',
    url: 'https://www.facebook.com/groups/878540877111439/posts/1441014217530766/',
    viewers: null,
    color: '#263b4b',
    ...overrides,
  };
}

function workspace(groups: Group[] = [], posts: Post[] = []): Workspace {
  return { ...createEmptyWorkspace(), groups, posts };
}

function groupConflict(reason: PostGroupSaveReason) {
  return (error: unknown) => {
    assert.ok(error instanceof PostGroupSaveError);
    assert.equal(error.code, 'POST_GROUP_SAVE');
    assert.equal(error.reason, reason);
    return true;
  };
}

test('without a pending group, the normal post save behavior is unchanged', () => {
  const latest = workspace();
  const candidate = post({ groupId: '' });
  assert.deepEqual(
    preparePostSaveWithGroup(latest, candidate, null, null),
    preparePostSave(latest, candidate, null),
  );
});

test('a new Facebook group and post are added together without mutating inputs', () => {
  const latest = workspace();
  const pending = group();
  const candidate = post();
  const inputs = structuredClone({ latest, pending, candidate });

  const saved = preparePostSaveWithGroup(latest, candidate, null, pending);

  assert.deepEqual(saved.groups, [pending]);
  assert.deepEqual(saved.posts, [candidate]);
  assert.notEqual(saved.groups[0], pending);
  assert.notEqual(saved.posts[0], candidate);
  assert.deepEqual({ latest, pending, candidate }, inputs);
});

test('an active matching group is reused, remapping the post to its latest ID', () => {
  const existing = group({ id: 'saved-group' });
  const latest = workspace([existing]);
  const pending = group();
  const candidate = post();
  const saved = preparePostSaveWithGroup(latest, candidate, null, pending);

  assert.equal(saved.groups, latest.groups);
  assert.equal(saved.posts[0].groupId, 'saved-group');
  assert.equal(candidate.groupId, 'pending-group');
});

test('groups for another store are not reused', () => {
  const latest = workspace([group({ id: 'other-store-group', storeId: 'another-store' })]);
  const saved = preparePostSaveWithGroup(latest, post(), null, group());

  assert.equal(saved.groups.length, 2);
  assert.equal(saved.posts[0].groupId, 'pending-group');
});

test('a matching group in Trash must be restored before adding a post', () => {
  const latest = workspace([group({ id: 'trashed-group', deletedAt: '2026-10-16T06:00:00Z' })]);
  const input = structuredClone(latest);

  assert.throws(
    () => preparePostSaveWithGroup(latest, post(), null, group()),
    groupConflict('group-in-trash'),
  );
  assert.deepEqual(latest, input);
});

test('invalid pending group links, stores, and IDs are rejected', () => {
  const invalid: [Post, Group][] = [
    [post({ groupId: 'different' }), group()],
    [post(), group({ storeId: 'other-store' })],
    [post(), group({ facebookId: 'not-numeric' })],
    [post(), group({ facebookId: '1'.repeat(41) })],
    [post(), group({ id: '' })],
    [post(), group({ deletedAt: '2026-10-16T06:00:00Z' })],
  ];
  for (const [candidate, pending] of invalid) {
    assert.throws(
      () => preparePostSaveWithGroup(workspace(), candidate, null, pending),
      groupConflict('invalid-group'),
    );
  }
});

test('a concurrent group ID collision never overwrites the existing group', () => {
  const latest = workspace([group({ facebookId: '222' })]);
  const input = structuredClone(latest);

  assert.throws(
    () => preparePostSaveWithGroup(latest, post(), null, group()),
    groupConflict('group-id-collision'),
  );
  assert.deepEqual(latest, input);
});

test('duplicate post checks still reject a save without committing the pending group', () => {
  const tracked = post({ id: 'tracked-post', groupId: '', facebookPostId: '' });
  const latest = workspace([], [tracked]);
  const input = structuredClone(latest);

  assert.throws(
    () => preparePostSaveWithGroup(latest, post(), null, group()),
    (error) => {
      assert.ok(error instanceof PostConflictError);
      assert.equal(error.reason, 'existing-post');
      return true;
    },
  );
  assert.deepEqual(latest, input);
});

test('concurrent edits remain protected while adding a new group', () => {
  const baseline = post({ groupId: '', facebookPostId: '', url: 'https://example.com/post/1' });
  const latest = workspace([], [{ ...baseline, product: 'Edited in another tab' }]);
  const input = structuredClone(latest);
  const edited = { ...baseline, groupId: 'pending-group' };

  assert.throws(
    () => preparePostSaveWithGroup(latest, edited, baseline, group()),
    (error) => {
      assert.ok(error instanceof PostConflictError);
      assert.equal(error.reason, 'changed');
      return true;
    },
  );
  assert.deepEqual(latest, input);
});
