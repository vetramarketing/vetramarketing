# Initial build verification

## Back to top control — 19 October 2026

- Added a compact icon-only `^` control at the lower right of the workspace after vertical scrolling. It scrolls the page smoothly to the top, respects reduced-motion settings, and has Thai/English accessible names. The control stays out of the tab order when hidden and moves focus to the main content when activated.
- Checked the live mobile-width preview on the Post library: the control appeared after scrolling, returned to the top by mouse and keyboard, and hid at the top. It remains below the temporary toast's stacking layer, with extra clearance on narrow screens. All 210 automated tests, the production build, and formatting checks passed.

## Automatic Meta relative dates — 19 October 2026

- **Update Viewers** now interprets “today” as the current Bangkok calendar date and “yesterday” as one calendar day earlier. The visible table date defaults to today, can be changed for an older snapshot, and can be cleared when the snapshot date is unknown.
- The preview records the resolved table date for the save step, so crossing Bangkok midnight cannot change a reviewed match. Automatic matches still require a unique tracked post with the same group and publication date and minute; ambiguous or conflicting rows remain for review.
- All 210 automated tests, the production build including TypeScript, and formatting checks passed. No browser-local post data was changed by verification.

## Reusable Meta Viewers importer — 17 October 2026

- The Post library now has a bilingual **Update Viewers** dialog for pasted Meta table HTML or an HTML/TXT file. A review step lists each matched post's before/after Viewers total and actual publication date, plus skipped rows. Saving re-reads the workspace and requires the previewed revision.
- Matching uses an exact Facebook group post link or a unique group name and known ICT publication minute. Dates without a year require an explicitly entered publication year before an unknown date can be filled. Relative dates such as “today” remain for review without the source capture date. Duplicate, ambiguous, lower-total, conflicting-date, invalid, and unmatched rows are not applied. Other post fields and previously saved dates are preserved.
- On the supplied 1.9 MB Meta table, the parser recognized 71 existing group posts as unchanged and left 51 rows for review, including Page/untracked rows and one relative-date group row. No records were changed during this check. All 169 tests, TypeScript, formatting, and production build passed; the dialog and English/Thai previews were visually checked in the local browser at a narrow width.

## Pinned posts — 17 October 2026

- A pin button at the start of each post row saves a boolean on the post. Pinned posts lead every sort in the library, overview, Performance, and quick search; the chosen order still applies within pinned and unpinned sections. The button is labeled in Thai and English, keyboard accessible, and visually marks pinned rows.
- Existing records without the field load as unpinned. The flag survives normal edits, local storage, JSON backups, CSV import/export, and prepared MongoDB documents. Concurrent pin/edit saves use revision and post-snapshot checks so stale changes cannot silently undo a pin.
- All 146 automated tests, TypeScript, production build, and formatting checks passed. Live browser visual verification remains unavailable under the browser tool's local-URL policy.

## Data structure migration — 17 October 2026

- v7 browser storage adds stable product and publishing-destination links while retaining each post's product-name snapshot. Existing v6 data migrates on load, and the original v6 key remains an untouched recovery copy. Product IDs are backfilled only for unique exact-name matches; expiring a product clears the link without erasing the saved name.
- Active saves, JSON backups, CSV exports, and prepared MongoDB documents omit post title, content, status, and planned date. The legacy decoder still filters unpublished older records. Group destinations mirror the existing group catalog; page/account destinations are derived only from identifiable URLs.
- One normalized post identity rule now covers editor saves, CSV import, and repository commits, including Trash. New duplicate pairs are rejected, while historical duplicate pairs remain editable and recoverable. MongoDB document/index declarations are prepared but no database or Cloudinary connection was made.
- The full automated test suite, TypeScript check, production build, and formatting check passed. Focused cases cover v6 migration, ambiguous products, expired product links, page/account detection, CSV links, Trash conflicts, legacy collisions, and MongoDB document preparation. Live browser visual verification was unavailable because this environment blocks loopback access.

## Two additional published group posts — 17 October 2026

- Added the supplied links for group 984343641981437/post 2809958519419931 and group 3900458250198953/post 4661094270802010. The previously supplied Meta table matches them to 12 October 2026 at 19:18 and 19:08 ICT, with 15 and 9 Viewers respectively. The supplied group directory provides their names; both posts use the ESHAN product.
- A revision-checked, one-time startup update adds missing posts and groups. It detects existing post IDs/URLs and leaves existing edits and totals unchanged. The completion marker survives backups and prevents a later refresh from recreating removed records.
- Focused persistence tests and the production build including TypeScript passed. Refresh the updated app to save the two posts to this browser's workspace. Live browser verification remains unavailable under the browser tool's local-URL policy.

## Latest supplied Viewers totals — 17 October 2026

- Parsed attachment `aaaeceaf-1ba8-45ea-9f04-0f62ad4e51cf`: 122 HTML rows. Used the previously user-confirmed Viewers column (second numeric metric, cell index 4), not views. All 70 supplied published group links match unique published group names in the table and directory; all 26 known publication dates also agree. Page posts, stories, and pending rows are excluded.
- Added a one-time revision-checked startup update after the supplied link import. Only scalar Viewers totals change; unknown dates, product assignments, links, groups, and click counts remain untouched. Saved later edits are protected by the update marker. Absent, ambiguous, trashed, or conflicting records are skipped.
- Examples: กลุ่มชาวลำลูกกา 907; เมนูขายดีตลาดนัด 595. All 123 tests and production build including TypeScript passed, covering all 70 totals, preservation of other fields, backup markers, conflicts, and failed writes. Refresh applies the update to browser storage; live browser verification remains unavailable under the browser tool's local-URL policy.

## Supplied post links and unknown dates — 17 October 2026

- Ingested 77 supplied link lines as 70 unique published links, excluding five duplicate lines and two pending-post links. The one-time, revision-checked startup import adds missing records for ESHAN in VETRA Store (or the first available store), preserving existing posts, totals, edits, and Trash records. Group names come from the supplied directory when known; unmatched handles/IDs receive explicit Facebook group placeholders.
- For new records, 26 dates and latest totals are recoverable from previous user-supplied data; the remaining 44 have unknown dates and null Viewers totals. Existing posts are never overwritten by this import. Pending post IDs 2909933032704543 and 3704155876400919 are excluded.
- As authorized, empty publication dates now mean unknown for published posts in current v6 storage. The editor permits blank dates, the table displays Unknown date in TH/EN, and CSV export/import retains these records. Invalid dates and future dates in the editor/import remain rejected; legacy draft filtering remains unchanged.
- All 120 tests and the production build including TypeScript passed. Import tests cover deduplication by ID/permalink, preserved edits/Trash, unknown date backup and CSV round trips, failed writes, concurrent edits, and one-time application. Refresh the updated app to apply the import to browser storage; live browser verification remains unavailable under the browser tool's local-URL policy.

## Platform selection modal — 17 October 2026

- Platform filtering now opens the same dark selection dialog as sorting, with All platforms, Facebook, Instagram, TikTok, and LinkedIn. Selecting a choice applies the filter immediately and closes the dialog.
- Sort and platform dialogs share focus containment/restoration, Escape/close/backdrop dismissal, active-option highlighting, and responsive styling. Existing filtering and history state are retained.
- Production build including TypeScript passed. Live visual and interaction checks remain unavailable under the browser tool's local-URL policy.

## Six post sort choices — 17 October 2026

- Default post-library sorting is Most Viewers. Modal choices are Most Viewers, Newest, Oldest, Product Name, Group Name, and Store Name, with Thai translations. Returning through browser history still restores the user's selected sort.
- Name sorts use locale-aware alphabetical/numeric ordering and resolved group/store names. Missing names are last; ties preserve input order. All six choices survive history restoration.
- Eleven sorting/navigation tests and the production build including TypeScript passed. Live browser verification remains unavailable under the browser tool's local-URL policy.

## Sort selection modal — 17 October 2026

- Replaced the post sort select with a button opening a compact dark native dialog. The same three options apply immediately; the active option is marked with a check and pressed state. Thai and English labels are retained.
- Native modal focus containment, initial focus on the active choice, Escape/close/backdrop dismissal, body scroll locking, and focus restoration are implemented. The dialog fits narrow screens and scrolls at short viewport heights.
- Production build including TypeScript passed. Live interaction and visual checks remain unavailable under the browser tool's local-URL policy.

## Post table column balance — 17 October 2026

- Desktop Product / Post now occupies 28% of the table; Destination receives the remaining space after the compact metrics, date, and action columns. Removed wider product-title overrides. Destination names wrap fully instead of being truncated at 13rem, with platform icons retaining their size.
- The existing mobile card layout remains in place. Production build including TypeScript passed; live visual verification remains unavailable under the browser tool's local-URL policy.

## Post product headings and images — 17 October 2026

- Post table headings now read the post's product name directly. Thumbnails use the matching active catalog product's image, including the supplied ESHAN asset. Images retain their aspect ratio without cropping; missing or failed images show a package icon. Blank product names have a TH/EN fallback.
- Images use the existing catalog URL validation, lazy loading, async decoding, and no-referrer policy. Post navigation and click tracking are unchanged.
- Production build including TypeScript passed. Live visual verification remains unavailable under the browser tool's local-URL policy.

## Assign existing posts to ESHAN — 17 October 2026

- On the next app load, all saved posts receive the product name น้ำผึ้งดอกกาแฟ ESHAN 320g. IDs, links, publication dates, Viewers totals, stores, groups, and Trash state are preserved. Daily click storage is untouched.
- The assignment is saved atomically with the supplied catalog addition through the revision-checked repository. A separate backup-preserved marker makes this a one-time update; later edits and newly created posts remain user-controlled. Conflicts reload current data before retrying, and failed saves leave existing data available.
- All 115 tests and the production build including TypeScript passed. Added coverage for existing workspaces, preservation of other post fields, backup round trips, later edits, and concurrent Viewers updates. Live browser verification remains unavailable under the browser tool's local-URL policy; refresh the app to apply the update to browser storage.

## Supplied ESHAN product — 17 October 2026

- Added the exact requested name, น้ำผึ้งดอกกาแฟ ESHAN 320g, and the supplied PNG from `public/product/`. Visually inspected the source image: its label reads 380 grams; the requested name and original image are preserved without alteration.
- App initialization adds the product through the revision-checked repository. A backup-preserved update marker prevents repeat additions after renaming or deletion. Existing matching records/custom images and Trash state are retained. Failed writes leave original data available and retry on the next load.
- Catalog validation/rendering/editor accepts the exact allowlisted bundled image path, while other local paths remain rejected. Empty-workspace resets retain the update marker. No Cloudinary upload or other post changes occur.
- All 113 tests and production build including TypeScript passed. Tests cover file existence, exact text, persistence, backup round trips, conflicts, failed writes, duplicate avoidance, and safe image paths. Live app verification remains blocked by the browser tool's local-URL policy; the addition is applied when the updated app loads.

## Reset daily click counts — 17 October 2026

- Added a TH/EN Reset all clicks action beside Export CSV in the Post library. It clears the current Bangkok day's counters for all posts in this browser, including filtered-out posts. It is disabled when counters are already zero and remains available to reset unreadable click data.
- The helper writes only the separate daily-click key. UI counts update only after a successful write; failures keep saved counts intact and display an error. Existing storage-event listeners propagate changes to other tabs. Post records, Viewers totals, filters, and workspace data are unchanged.
- Five click-count tests and the production build including TypeScript passed. The existing action layout wraps on narrow screens; live browser verification remains blocked by the browser tool's local-URL policy.

## Cloudinary preparation — 17 October 2026

- Product `imageAsset` and store `logoAsset` metadata now survive validation, local repository saves, JSON backups, MongoDB document preparation, and Trash retention. Existing URL-only records remain valid. Name/order/owner edits retain matching assets; replacing a URL detaches metadata without remote deletion.
- Added pure upload-plan, target/submission, prepared-file, and provider-response contracts plus server-only environment placeholders and setup guidance. Upload plans isolate workspace/record/submission IDs and disallow overwrite. Metadata parsing checks the canonical URL and supported image limits; it deliberately does not claim authentication or ownership verification.
- v6 storage preserves the v5 catalog and all older recovery keys. Separate storage prevents an older app build from stripping media fields. Entity edit comparisons now handle nested asset values across reloads while still detecting changes.
- All 105 tests and the production build including TypeScript passed. Tests cover v5 migration, metadata round trips, malformed responses/URLs, credential/token exclusion, URL replacement, shared assets in Trash, scoped plans, and existing catalog/post behavior.
- No upload control, signing endpoint, MongoDB/Cloudinary connection, or deletion API is active. Browser image preparation, retry execution, authenticated media staging, transactional saves, and manual cleanup still require the future API integration. No live provider test was performed.

## Product and store catalogs — 17 October 2026

- Added shared products with name, optional image URL, and sort order. Store forms now expose name, optional logo URL, owner name, and sort order. Both use the dark theme, search, stable ordering, image fallbacks, field validation, busy controls, and entity/repository conflict checks. Product deletion and 30-day restoration preserve image URLs and do not change existing posts.
- Product names are suggested in the post editor without replacing existing campaign text. Store ordering applies to the workspace selector, post form, group form, CSV import, and quick search. Global catalog pages do not display a misleading store filter.
- v5 browser storage and JSON backups include the catalogs. v1–v4 migrations retain old keys, existing store branding and IDs, post relationships, and current totals. Backup restore previews now count products. CSV remains post-only.
- Prepared typed MongoDB catalog documents, input/save contracts, scoped indexes, and a validated document mapping helper, plus API/migration guidance. No MongoDB driver, connection, upload, or live API was enabled; that awaits the user's endpoint and authentication details.
- All 94 tests passed, including migration/recovery, catalog validation, persistence/reload, JSON restore, stale writes, sorting, Trash expiry, and migration document isolation. Production build including TypeScript passed. Live browser layout/interaction verification remains unavailable because the browser tool blocks local URLs; no visual QA claim is made.

## Delete from the post editor — 17 October 2026

- Removed post-row delete icons. Existing-post edit modals now contain a labeled Delete post button; new-post forms do not. The footer wraps on narrow screens.
- Deletion uses the saved record and existing 30-day Trash flow, without submitting unsaved edits or new groups. Controls are disabled during the operation; the modal closes only after a successful write and retains edits on failure.
- Production build (including TypeScript), formatting, and 33 relevant domain, persistence, and editor-state tests passed. Live UI verification remains blocked by the browser tool's URL policy.

## Connection warming on hover — 17 October 2026

- Post-link hover and keyboard focus, plus hover over clickable library rows, issue an origin-only HTTPS preconnect hint through React. Repeated origins are deduplicated. Touch pointer entry is excluded; no post content is fetched and click counts are unchanged by warming.
- Production build (including TypeScript), formatting, and six existing click-count/navigation-state tests passed. Live browser checks remain blocked by the browser tool's URL policy, so no measured loading-speed improvement is claimed.

## New-tab post navigation restored — 17 October 2026

- Linked post titles and Post library row clicks open new tabs. The redundant external-link action was removed; titles in overview and performance tables also open their linked posts, with editing retained on the pencil button.
- Row clicks request the new tab before saving the daily click count. The list stays open, retaining its current filters and scroll position; browser-history restoration remains available for other navigation.
- The production build (including TypeScript), formatting, and six click-count/navigation-state tests passed. Facebook loading speed has not been measured; live browser checks remain blocked by the browser tool's URL policy.

## Same-tab post navigation — 17 October 2026

- Post titles and ordinary row clicks open in the same tab. The separate ↗ action keeps new-tab behavior and has a localized accessible name. Native modified title clicks remain available.
- List search, store/platform filters, sort order, and page/table scroll positions are saved on the current browser-history entry. Returning restores the list after workspace data loads, while preserving framework history fields. Daily click counting is unchanged.
- All 87 tests and the production build (including TypeScript) passed. Live navigation verification was blocked by the browser tool's URL policy.

## Current Viewers total — 17 October 2026

- Active v4 storage, JSON backups, and CSV exports keep one nullable Viewers total per post. Editing a total replaces the previous number; dated readings, daily growth, and the growth chart were removed.
- v1/v2/v3 local workspaces migrate to v4 by selecting the latest valid dated reading for each published post. Earlier browser keys remain available as recovery copies.
- The supplied 26-post update replaces earlier totals with the latest user-provided figures where records still match; custom totals remain untouched.
- Validation: 84 tests, TypeScript, and the production build passed. Rendered verification was unavailable: local preview tabs were unreachable and the local HTTP check was blocked by socket permissions.

The entries below document earlier builds and may describe features removed by the current Viewers model.

## Published-post monitor — 17 October 2026

- Replaced draft and board workflows with one responsive list of published posts. Adding or importing now requires an actual publication date and live-post link or resolvable Facebook IDs. New workspaces start empty.
- Active v3 storage retains published records only. Prior v2/v1 browser keys remain available for recovery, and Settings can download their original data. Built-in sample posts without real links are left out of the active monitor.
- The current implementation was checked with tests, typecheck, production build, and source review. The browser URL policy blocked rendered visual inspection of the local preview.

## Publication-only data structure — 17 October 2026

- Active v2 storage and JSON backups omit post title, content, status, and planned date. A one-time migration reads v1 and leaves the original key intact for recovery; previously planned posts become unpublished records.
- CSV export and template omit those four fields. Imports accept old column aliases but discard their removed values. Publication state comes from the actual publication date. The planned lane, calendar, and topbar checklist are gone.
- The current source, tests, typecheck, and production build were checked after this change. Browser visual inspection was blocked by the browser URL policy, so the new screens have not yet received a rendered viewport check.

The older verification entries below describe the previous planning workflow and remain as historical records.

## Navigation drawer — 17 October 2026

- Removed the fixed desktop sidebar and its reserved page margin. One modal drawer now holds the navigation on every screen size, with the menu button exposed in the top bar.
- Kept native modal focus containment, locked page scrolling while open, restored focus on close, and supported Escape, the close button, backdrop clicks, and route selection. Added close motion and reduced-motion handling.
- TypeScript, regression tests, production build, and formatting checks pass. The local server responded with HTTP 200. Browser interaction for this change was blocked by the browser URL policy while existing tabs showed an unreachable-page error, so this drawer change has not received a visual browser check.

## Workflow improvements — 17 October 2026

- Added a responsive Draft / Planned / Published board, retained the table, and verified that view and sort preferences survive reload. Status filters show the matching lane; text/platform filters report their result count and can be cleared.
- Added keyboard workspace search for posts, stores, pages, and creating a post. Verified Ctrl+K, arrow/Enter navigation, opening a matching post, switching stores, Thai/English text, and exclusion of trashed posts.
- Duplicated a published sample into a fresh draft. Publication identity, dates, and readings were cleared; the caption was preserved. Saved and reloaded the copy, then moved only that QA copy into recoverable Trash.
- Verified caption clipboard contents, unsaved-change dismissal, Escape returning to the editor with text preserved, and the confirmation dialog at desktop and 320-pixel mobile sizes. Fixed an oversized native dialog and narrow-screen toolbar clipping found during visual inspection.
- Ran a real two-tab conflict check: the second tab saved an updated QA post, the first tab rejected its stale edit and retained its unsaved text, and the newer saved record remained intact.
- Downloaded a filtered one-post CSV and parsed the actual file through the importer: one post, no errors, and exactly one UTF-8 BOM. Fixed the prior extra BOM added by the download wrapper.
- Verified date sorting across time zones and after changing published posts back to planned. Dates now follow the current status instead of a retained old publication date.
- Checked the new layouts at 320, 390, 768, 1440, 1920, and 3840 CSS pixels, including large-screen typography. Inspected rendered board/search text contrast with no failures below 4.5:1 on checked solid backgrounds; this remains a focused check rather than a full accessibility audit.
- All 42 regression tests, TypeScript, production build, and source formatting checks pass. No new runtime warnings or errors occurred during completed browser workflows; temporary missing-module development errors while new files were being created were resolved before verification.
- Screenshots: `docs/screenshots/workflow-board-desktop.png`, `workflow-board-mobile.png`, and `workflow-search-desktop.png`.

## Dark theme verification — 17 October 2026

- Applied shared dark tokens to all eight workspace sections, post editor, import dialog, mobile drawer, loading state, and a custom bilingual 404 page. Native controls and browser theme metadata also use dark colors.
- Checked Thai and English, calendar and table containment, store/group forms, preview color selection, import tips, disabled controls, and modal Escape/focus restoration. Existing workspace data and stored brand colors were preserved.
- Inspected rendered text contrast on all eight sections and both dialogs, with no failures below 4.5:1 on the checked solid backgrounds. Form-control boundaries measure 3.22–3.94:1 against their adjacent surfaces. This is a focused theme check, not a full accessibility audit.
- Checked responsive layouts at 320, 390, 768, 1440, 1920, and 3840 CSS pixels. All eight sections fit at 320 pixels; both dialogs remain within the viewport. Large-screen font scaling remains intact.
- TypeScript, production build, formatting, and all 20 existing regression tests pass.
- Dark screenshots are saved in `docs/screenshots/dark-overview-desktop.jpg` and `docs/screenshots/dark-overview-mobile.jpg`.

## Initial version

Verified on 16 October 2026 against the local app at `http://127.0.0.1:3100`.

## Automated checks

- TypeScript: `npm.cmd run typecheck`.
- Domain and CSV regression suite: 20 passing tests, covering long IDs, date and status validation, Viewer rates, mixed date precision, retained permalinks, 30-day Trash expiry, formula-safe export, import duplicates, quoted text, and the distinction between Views and Viewers.
- Production compilation: `npm.cmd run build`.

## Browser checks

- Thai and English switching, localized document title, and persisted language.
- Create a bilingual draft, reload and find it, filter the library, move it to Trash, and restore it.
- Import the CSV fixture: one valid draft accepted, one unsafe URL rejected in the preview. Confirmed import appears in the library.
- Create a group with a 20-digit ID and verify every digit in the generated destination URL.
- Filter the workspace by store and verify scoped post/group counts.
- Inspect the monthly calendar, store cards, editor preview, and mobile drawer. Escape dismisses the drawer and restores focus.
- Checked layout containment at 320, 390, 768, 1440, 1920, and 3840 CSS pixels. Fixed the mobile table label overflow and full-screen dialog sizing. Large viewport root font scaling was verified.
- No browser warning or error logs were reported during the tested workflows.

Test posts and the test group were moved to recoverable Trash after verification. Active sample content remains available. Screenshots are in `docs/screenshots/`.

## Remaining integration work

The current version is browser-local. Shared database storage, sign-in and authorization, real account connections, automated metric retrieval, and media uploads are not configured. No live Google Sheet, social account, or production business record was modified. See the README for the storage boundary and setup commands.
