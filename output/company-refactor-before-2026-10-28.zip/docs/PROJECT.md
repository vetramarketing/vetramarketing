# Project

Project: [VETRA Marketing].
Business and audience: [A private social media management app for marketing team for many different store and different product].
Goal: [Organize posts, track performance, and reduce manual work].
Scope: [Monitoring posts across stores, with actual publication dates when known (blank means unknown and the record is treated as Pending), post URLs or Facebook IDs when available, the latest Viewers total per post, spreadsheet import/export, and future support for other social platforms. Meta rows with no post link may be retained as provisional records; pending rows are clearly marked and excluded from published performance totals. No planning workflow].

For provisional Meta rows, retain the source's group and partial date as context, but do not infer a missing year or post ID. A source row number is provenance, not a permanent post identity; reconcile records with a verified permalink when one becomes available.
When a new permalink matches a tracked post, direct the user to that record and reject a duplicate save. Linkless Meta rows in the same group are possible matches for human review only, because one group can contain several posts.
Photo Stories from the supplied Meta table are outside the tracked post list. A published Page row without a public permalink may remain as a provisional record until the team supplies its link.
An undated provisional record appears Pending in the workspace even when Meta marked the source row published; retain Meta's source details for later reconciliation.
Post settings offer Published and Pending, with Published selected for new records. Saving Published requires a confirmed publication date; Pending saves without an actual date and may have no post link. Temporary status changes in the editor retain the entered date until the user saves or discards the edit.

Use the project brief, existing code, and supplied assets to establish the
context. Treat unfilled placeholders as missing information, not facts.
Choose appropriate pages and navigation within the agreed scope.

Preferred starting stack: Next.js App Router, TypeScript, MongoDB for
application data, Cloudinary for media, and Vercel for deployment.
Adapt these choices to the project's needs and existing code, including
whether a database or media service is needed.
