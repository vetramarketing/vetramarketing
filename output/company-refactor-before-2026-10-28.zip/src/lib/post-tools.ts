import type { Locale, Post, Product } from './types';
import { canonicalPostUrl } from './data';
import { productStoreIdMap } from './product-store';

export type PostSort =
  'recent' | 'date-asc' | 'viewers' | 'viewers-per-day' | 'title' | 'group' | 'store';

export type PostStatusFilter = 'normal' | 'pending' | 'no-link' | 'all';

/** A missing actual date keeps the record pending without changing its saved source details. */
export function postPublicationStatus(
  post: Pick<Post, 'publicationStatus' | 'publishedAt'>,
): 'published' | 'pending' {
  return !post.publishedAt || post.publicationStatus === 'pending' ? 'pending' : 'published';
}

/** Use the same link resolution for filtering and opening a row. */
export function publicPostUrl(
  post: Pick<Post, 'url' | 'facebookPostId'>,
  groupFacebookId: string,
): string {
  return post.url || canonicalPostUrl(groupFacebookId, post.facebookPostId);
}

export function matchesPostStatusFilter(
  post: Pick<Post, 'publicationStatus' | 'publishedAt'>,
  hasLink: boolean,
  filter: PostStatusFilter,
): boolean {
  const status = postPublicationStatus(post);
  switch (filter) {
    case 'normal':
      return status === 'published' && hasLink;
    case 'pending':
      return status === 'pending';
    case 'no-link':
      return !hasLink;
    case 'all':
      return true;
  }
}

/** Approximate daily average from the current total and elapsed time; no metric history is stored. */
export function averageViewersPerDay(
  post: Pick<Post, 'publishedAt' | 'viewers'>,
  now: Date = new Date(),
): number | null {
  if (post.viewers === null || !post.publishedAt) return null;
  const published = Date.parse(post.publishedAt);
  const elapsed = now.getTime() - published;
  if (!Number.isFinite(elapsed) || elapsed < 0) return null;
  return post.viewers / Math.max(1, elapsed / 86_400_000);
}

/** Prefer stable catalog IDs; resolve old name-only posts within an unambiguous store. */
export function filterPostsByProduct(
  posts: readonly Post[],
  products: readonly Product[],
  productId: string,
  allPosts: readonly Post[] = posts,
): Post[] {
  if (productId === 'all') return [...posts];
  const selected = products.find((product) => product.id === productId && !product.deletedAt);
  if (!selected) return [];
  const selectedName = selected.name.trim();
  const sameName = products.filter(
    (product) => !product.deletedAt && product.name.trim() === selectedName,
  );
  const productStores = productStoreIdMap(sameName, allPosts);
  const eligibleStoreIds = new Set(productStores.get(selected.id));
  const ambiguousStoreIds = new Set(
    sameName
      .filter((product) => product.id !== selected.id)
      .flatMap((product) => productStores.get(product.id) ?? []),
  );
  return posts.filter(
    (post) =>
      post.productId === productId ||
      (!post.productId &&
        post.product.trim() === selectedName &&
        eligibleStoreIds.has(post.storeId) &&
        !ambiguousStoreIds.has(post.storeId)),
  );
}

function postDate(post: Post): number | null {
  const value = post.publishedAt;
  const timestamp = value ? Date.parse(value) : NaN;
  return Number.isFinite(timestamp) ? timestamp : null;
}

function compareKnown(a: number | null, b: number | null, ascending = false): number {
  if (a === null) return b === null ? 0 : 1;
  if (b === null) return -1;
  return ascending ? a - b : b - a;
}

/** Sort a copy with pinned posts first, keeping unknown values last within each section. */
export function sortPosts(
  posts: readonly Post[],
  sort: PostSort,
  locale: Locale,
  catalog?: {
    groups: readonly { id: string; name: string }[];
    stores: readonly { id: string; name: string }[];
    destinations?: readonly { id: string; name: string }[];
  },
  now: Date = new Date(),
): Post[] {
  const collator = new Intl.Collator(locale, { numeric: true, sensitivity: 'base' });
  const names = new Map(
    (sort === 'group' ? catalog?.groups : sort === 'store' ? catalog?.stores : [])?.map(
      (item) => [item.id, item.name.trim()] as const,
    ),
  );
  const destinationNames =
    sort === 'group'
      ? new Map(catalog?.destinations?.map((item) => [item.id, item.name.trim()] as const))
      : new Map<string, string>();
  const byName = sort === 'title' || sort === 'group' || sort === 'store';
  const name = (post: Post) =>
    sort === 'title'
      ? post.product.trim()
      : sort === 'group'
        ? destinationNames.get(post.destinationId ?? '') || names.get(post.groupId) || ''
        : (names.get(post.storeId) ?? '');
  return posts
    .map((post, index) => ({
      post,
      index,
      value:
        sort === 'viewers'
          ? post.viewers
          : sort === 'viewers-per-day'
            ? averageViewersPerDay(post, now)
            : postDate(post),
      name: byName ? name(post) : '',
    }))
    .sort((a, b) => {
      if (Boolean(a.post.pinned) !== Boolean(b.post.pinned)) return a.post.pinned ? -1 : 1;
      const comparison = byName
        ? a.name && b.name
          ? collator.compare(a.name, b.name)
          : a.name
            ? -1
            : b.name
              ? 1
              : 0
        : compareKnown(a.value, b.value, sort === 'date-asc');
      return comparison || a.index - b.index;
    })
    .map(({ post }) => post);
}
