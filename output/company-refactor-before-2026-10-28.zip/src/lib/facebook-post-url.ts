export type FacebookGroupPostIds = { groupId: string; postId: string };

const FACEBOOK_HOSTS = new Set([
  'facebook.com',
  'www.facebook.com',
  'm.facebook.com',
  'web.facebook.com',
]);
const ID = '[0-9]{1,40}';
const POST_PATH = new RegExp(`^/groups/(${ID})/(?:permalink|posts)/(${ID})/?$`);
const GROUP_PATH = new RegExp(`^/groups/(${ID})/?$`);
const NUMERIC_ID = new RegExp(`^${ID}$`);

/** Extract IDs only when a URL clearly identifies a Facebook group post. */
export function parseFacebookGroupPostUrl(input: string): FacebookGroupPostIds | null {
  let url: URL;
  try {
    url = new URL(input.trim());
  } catch {
    return null;
  }

  if (
    url.protocol !== 'https:' ||
    !FACEBOOK_HOSTS.has(url.hostname) ||
    url.username ||
    url.password ||
    url.port
  ) {
    return null;
  }

  const postPath = POST_PATH.exec(url.pathname);
  if (postPath) return { groupId: postPath[1], postId: postPath[2] };

  // Facebook also shares individual group posts as /groups/{id}/?multi_permalinks={postId}.
  const groupPath = GROUP_PATH.exec(url.pathname);
  if (!groupPath) return null;
  const postIds = url.searchParams.getAll('multi_permalinks');
  if (postIds.length !== 1 || !NUMERIC_ID.test(postIds[0])) return null;
  return { groupId: groupPath[1], postId: postIds[0] };
}
