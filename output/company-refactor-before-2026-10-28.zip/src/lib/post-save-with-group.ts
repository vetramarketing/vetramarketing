import { preparePostSave } from './post-save';
import type { Group, Post, Workspace } from './types';

export type PostGroupSaveReason = 'invalid-group' | 'group-in-trash' | 'group-id-collision';

const messages: Record<PostGroupSaveReason, string> = {
  'invalid-group': 'The Facebook group details do not match this post.',
  'group-in-trash': 'This Facebook group is in Trash. Restore it before saving the post.',
  'group-id-collision': 'This group ID is already used by another group. Try saving again.',
};

export class PostGroupSaveError extends Error {
  readonly code = 'POST_GROUP_SAVE';
  readonly reason: PostGroupSaveReason;

  constructor(reason: PostGroupSaveReason) {
    super(messages[reason]);
    this.name = 'PostGroupSaveError';
    this.reason = reason;
  }
}

/** Save a post and its new Facebook group against one fresh workspace snapshot. */
export function preparePostSaveWithGroup(
  latest: Workspace,
  post: Post,
  baseline: Post | null,
  pendingGroup: Group | null,
): Workspace {
  if (!pendingGroup) return preparePostSave(latest, post, baseline);

  if (
    !pendingGroup.id.trim() ||
    pendingGroup.deletedAt ||
    post.groupId !== pendingGroup.id ||
    post.storeId !== pendingGroup.storeId ||
    !latest.stores.some((store) => store.id === pendingGroup.storeId) ||
    !/^\d{1,40}$/.test(pendingGroup.facebookId)
  ) {
    throw new PostGroupSaveError('invalid-group');
  }

  const matchingGroups = latest.groups.filter(
    (group) =>
      group.storeId === pendingGroup.storeId && group.facebookId === pendingGroup.facebookId,
  );
  const activeGroup = matchingGroups.find((group) => !group.deletedAt);
  if (activeGroup) {
    return preparePostSave(latest, { ...post, groupId: activeGroup.id }, baseline);
  }
  if (matchingGroups.length) throw new PostGroupSaveError('group-in-trash');

  if (latest.groups.some((group) => group.id === pendingGroup.id)) {
    throw new PostGroupSaveError('group-id-collision');
  }

  return preparePostSave(
    { ...latest, groups: [...latest.groups, { ...pendingGroup }] },
    post,
    baseline,
  );
}
