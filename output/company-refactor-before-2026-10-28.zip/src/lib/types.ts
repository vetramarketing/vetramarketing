import type { CloudinaryImage } from './cloudinary-media';

export type Locale = 'th' | 'en';
export type Platform = 'facebook' | 'instagram' | 'tiktok' | 'linkedin';
export type PostStatus = 'draft' | 'planned' | 'published';
export type View =
  'overview' | 'posts' | 'groups' | 'analytics' | 'products' | 'stores' | 'settings' | 'trash';
export interface Store {
  id: string;
  name: string;
  logoImageUrl: string;
  logoAsset?: CloudinaryImage;
  ownerName: string;
  sortOrder: number;
  /** Preserved branding from older workspaces; no longer required in the editor. */
  initials: string;
  color: string;
  description: string;
}
/** Shared catalog with explicit store associations for new products. */
export interface Product {
  id: string;
  name: string;
  imageUrl: string;
  imageAsset?: CloudinaryImage;
  /** Omitted on legacy products until a store is selected. */
  storeIds?: string[];
  sortOrder: number;
  deletedAt?: string;
}
export interface Group {
  id: string;
  storeId: string;
  name: string;
  facebookId: string;
  category: string;
  notes: string;
  deletedAt?: string;
}
/** A stable, store-scoped place where a post was published. */
export interface Destination {
  id: string;
  storeId: string;
  platform: Platform;
  kind: 'group' | 'page' | 'account';
  externalId: string;
  name: string;
  /** Group details remain in the existing group catalog. */
  groupId?: string;
  deletedAt?: string;
}
/** A saved social post or a provisional Meta row awaiting publication confirmation. */
export interface PublishedPost {
  id: string;
  storeId: string;
  groupId: string;
  product: string;
  /** Stable catalog link; product remains the name recorded with the post. */
  productId?: string;
  /** Stable publishing destination, when it can be identified. */
  destinationId?: string;
  platform: Platform;
  /** Actual publication time; empty means unknown and is treated as Pending in the workspace. */
  publishedAt: string;
  /** Original saved status; an empty publishedAt is effectively Pending even for legacy records. */
  publicationStatus?: 'published' | 'pending';
  /** Row number in the supplied Meta table, retained for later reconciliation. */
  metaSourceRow?: number;
  /** Destination snapshot preserved if its group is later removed from the catalog. */
  metaGroupName?: string;
  /** Numeric group ID or stable group slug supplied by the team's group directory. */
  metaGroupKey?: string;
  /** Day/month/time copied from Meta when it omitted the publication year. */
  metaPublishedLabel?: string;
  facebookPostId: string;
  url: string;
  /** Latest known total only; null means the total has not been entered. */
  viewers: number | null;
  /** Pinned posts appear before unpinned posts in every post list. Absent in older data. */
  pinned?: boolean;
  color: string;
  deletedAt?: string;
}
/** Older backup fixtures may still carry retired planning fields. */
export type Post = PublishedPost & {
  title?: string;
  content?: string;
  status?: PostStatus;
  scheduledAt?: string;
};
export interface Workspace {
  version: 1;
  stores: Store[];
  products: Product[];
  groups: Group[];
  /** Normalized on load; optional in legacy in-memory fixtures. */
  destinations?: Destination[];
  posts: Post[];
  sample: boolean;
  /** One-time supplied data additions; retained in backups to respect later edits/deletion. */
  appliedDataUpdates?: string[];
}
export type Translate = (en: string, th: string) => string;
