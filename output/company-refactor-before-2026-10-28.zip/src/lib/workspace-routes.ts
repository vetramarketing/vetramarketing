import type { View } from './types';

export const workspaceViews: readonly View[] = [
  'overview',
  'posts',
  'groups',
  'analytics',
  'products',
  'stores',
  'settings',
  'trash',
];

export function isWorkspaceView(value: string): value is View {
  return workspaceViews.some((view) => view === value);
}

export function workspacePath(view: View): string {
  return view === 'overview' ? '/' : `/${view}`;
}

export function viewFromPath(pathname: string): View | null {
  if (pathname === '/') return 'overview';
  const section = pathname.match(/^\/([^/]+)\/?$/)?.[1];
  return section && isWorkspaceView(section) ? section : null;
}
