import type { Post, Product } from './types';

/** Resolve every product in one pass through the posts for catalog and picker lists. */
export function productStoreIdMap(
  products: readonly Pick<Product, 'id' | 'storeIds'>[],
  posts: readonly Pick<Post, 'productId' | 'storeId'>[],
): Map<string, string[]> {
  const linkedStores = new Map<string, Set<string>>();
  for (const post of posts) {
    if (!post.productId) continue;
    let stores = linkedStores.get(post.productId);
    if (!stores) {
      stores = new Set();
      linkedStores.set(post.productId, stores);
    }
    stores.add(post.storeId);
  }
  return new Map(
    products.map((product) => [
      product.id,
      product.storeIds === undefined
        ? [...(linkedStores.get(product.id) ?? [])]
        : [...product.storeIds],
    ]),
  );
}

/** Explicit store choices take precedence; older products inherit stores from their linked posts. */
export function effectiveProductStoreIds(
  product: Pick<Product, 'id' | 'storeIds'>,
  posts: readonly Pick<Post, 'productId' | 'storeId'>[],
): string[] {
  if (product.storeIds !== undefined) return [...product.storeIds];
  return [
    ...new Set(posts.filter((post) => post.productId === product.id).map((post) => post.storeId)),
  ];
}
