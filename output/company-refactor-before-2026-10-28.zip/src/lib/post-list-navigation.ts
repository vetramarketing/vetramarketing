import type { PostSort, PostStatusFilter } from './post-tools';

const HISTORY_KEY = 'vetraPostList';
const platforms = new Set(['all', 'facebook', 'instagram', 'tiktok', 'linkedin']);
const sorts = new Set<PostSort>([
  'recent',
  'date-asc',
  'viewers',
  'viewers-per-day',
  'title',
  'group',
  'store',
]);
const statusFilters = new Set<PostStatusFilter>(['normal', 'pending', 'no-link', 'all']);

export interface PostListReturnState {
  storeId: string;
  productId: string;
  search: string;
  platform: string;
  statusFilter: PostStatusFilter;
  sort: PostSort;
  scrollX: number;
  scrollY: number;
  tableScrollLeft: number;
}

function record(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

/** Keep list state on its own browser-history entry, without replacing router state. */
export function withPostListReturnState(
  state: unknown,
  list: PostListReturnState,
): Record<string, unknown> {
  return { ...(record(state) ? state : {}), [HISTORY_KEY]: { version: 5, ...list } };
}

export function readPostListReturnState(state: unknown): PostListReturnState | null {
  if (!record(state) || !record(state[HISTORY_KEY])) return null;
  const list = state[HISTORY_KEY];
  if (
    ![1, 2, 3, 4, 5].includes(list.version as number) ||
    typeof list.storeId !== 'string' ||
    !list.storeId ||
    list.storeId.length > 100 ||
    (list.version !== 1 &&
      (typeof list.productId !== 'string' || !list.productId || list.productId.length > 100)) ||
    (list.version === 3 && typeof list.pendingOnly !== 'boolean') ||
    (list.version === 4 && typeof list.showPending !== 'boolean') ||
    (list.version === 5 && !statusFilters.has(list.statusFilter as PostStatusFilter)) ||
    typeof list.search !== 'string' ||
    typeof list.platform !== 'string' ||
    !platforms.has(list.platform) ||
    !sorts.has(list.sort as PostSort) ||
    ![list.scrollX, list.scrollY, list.tableScrollLeft].every(
      (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0,
    )
  )
    return null;
  return {
    storeId: list.storeId,
    productId: list.version === 1 ? 'all' : (list.productId as string),
    search: list.search,
    platform: list.platform,
    statusFilter:
      list.version === 5
        ? (list.statusFilter as PostStatusFilter)
        : list.version === 4 && list.showPending
          ? 'all'
          : list.version === 3 && list.pendingOnly
            ? 'pending'
            : 'normal',
    sort: list.sort as PostSort,
    scrollX: list.scrollX as number,
    scrollY: list.scrollY as number,
    tableScrollLeft: list.tableScrollLeft as number,
  };
}
