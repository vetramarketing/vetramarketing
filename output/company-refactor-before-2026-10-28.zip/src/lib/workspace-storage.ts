import { validDate, validateWorkspace } from './data';
import { resolveFacebookGroupName } from './facebook-group-directory';
import type { PublishedPost, Workspace } from './types';

export const WORKSPACE_KEY = 'vetra-marketing.workspace.v7';
export const V6_WORKSPACE_KEY = 'vetra-marketing.workspace.v6';
export const PREVIOUS_WORKSPACE_KEY = 'vetra-marketing.workspace.v5';
export const OLDER_WORKSPACE_KEY = 'vetra-marketing.workspace.v4';
export const V3_WORKSPACE_KEY = 'vetra-marketing.workspace.v3';
export const V2_WORKSPACE_KEY = 'vetra-marketing.workspace.v2';
export const LEGACY_WORKSPACE_KEY = 'vetra-marketing.workspace.v1';
export const WORKSPACE_BACKUPS = [
  { key: V6_WORKSPACE_KEY, version: 'v6' },
  { key: PREVIOUS_WORKSPACE_KEY, version: 'v5' },
  { key: OLDER_WORKSPACE_KEY, version: 'v4' },
  { key: V3_WORKSPACE_KEY, version: 'v3' },
  { key: V2_WORKSPACE_KEY, version: 'v2' },
  { key: LEGACY_WORKSPACE_KEY, version: 'v1' },
];

type StoredPost = PublishedPost;
export type StoredWorkspaceV7 = Omit<Workspace, 'version' | 'posts'> & {
  version: 7;
  posts: StoredPost[];
};

/** Older backups may contain dated measurements. Keep only their latest valid total. */
export function latestLegacyViewers(value: unknown): number | null {
  if (!Array.isArray(value) || value.length > 2000)
    throw new Error('Legacy post measurements are invalid.');
  const seen = new Set<number>();
  let latest: { date: number; viewers: number } | null = null;
  for (const raw of value) {
    if (!raw || typeof raw !== 'object') throw new Error('Legacy measurement is invalid.');
    const metric = raw as Record<string, unknown>;
    if (typeof metric.date !== 'string' || !validDate(metric.date))
      throw new Error('Legacy measurement date is invalid.');
    if (
      typeof metric.viewers !== 'number' ||
      !Number.isSafeInteger(metric.viewers) ||
      metric.viewers < 0
    )
      throw new Error('Legacy Viewers total is invalid.');
    const time = Date.parse(metric.date);
    if (seen.has(time)) throw new Error('Legacy measurements contain duplicate dates.');
    seen.add(time);
    if (!latest || time > latest.date) latest = { date: time, viewers: metric.viewers };
  }
  return latest?.viewers ?? null;
}

function untouchedBuiltInSample(post: {
  id?: unknown;
  url?: unknown;
  facebookPostId?: unknown;
}): boolean {
  return (
    typeof post.id === 'string' &&
    /^sample-(?:[1-9]|1[0-2])$/.test(post.id) &&
    !post.url &&
    !post.facebookPostId
  );
}

/** The active workspace contains published posts only. Older keys remain as recovery copies. */
export function serializeWorkspace(workspace: Workspace): StoredWorkspaceV7 {
  if (workspace.posts.some((post) => post.status !== undefined && post.status !== 'published'))
    throw new Error('Only published posts can be saved in this workspace.');
  const valid = validateWorkspace(workspace);
  return {
    version: 7,
    sample: false,
    ...(valid.appliedDataUpdates ? { appliedDataUpdates: valid.appliedDataUpdates } : {}),
    stores: valid.stores,
    products: valid.products,
    groups: valid.groups,
    destinations: valid.destinations,
    posts: valid.posts.map((post) => ({
      id: post.id,
      storeId: post.storeId,
      groupId: post.groupId,
      product: post.product,
      ...(post.productId ? { productId: post.productId } : {}),
      ...(post.destinationId ? { destinationId: post.destinationId } : {}),
      platform: post.platform,
      publishedAt: post.publishedAt,
      ...(post.publicationStatus ? { publicationStatus: post.publicationStatus } : {}),
      ...(post.metaSourceRow === undefined ? {} : { metaSourceRow: post.metaSourceRow }),
      ...(post.metaGroupName ? { metaGroupName: post.metaGroupName } : {}),
      ...(post.metaGroupKey ? { metaGroupKey: post.metaGroupKey } : {}),
      ...(post.metaPublishedLabel ? { metaPublishedLabel: post.metaPublishedLabel } : {}),
      facebookPostId: post.facebookPostId,
      url: post.url,
      viewers: post.viewers,
      pinned: post.pinned === true,
      color: post.color,
      ...(post.deletedAt ? { deletedAt: post.deletedAt } : {}),
    })),
  };
}

/** Restore published posts from any supported backup without changing older storage keys. */
export function deserializeWorkspace(input: unknown): Workspace {
  if (!input || typeof input !== 'object') throw new Error('Invalid workspace.');
  const raw = input as Record<string, unknown>;
  if (raw.version === 1) {
    if (!Array.isArray(raw.posts)) throw new Error('Invalid legacy workspace.');
    return deserializeWorkspace({
      ...raw,
      version: 2,
      posts: raw.posts.filter(
        (post) =>
          post &&
          typeof post === 'object' &&
          (post as Record<string, unknown>).status === 'published' &&
          (post as Record<string, unknown>).publishedAt &&
          !(raw.sample === true && untouchedBuiltInSample(post as Record<string, unknown>)),
      ),
    });
  }
  if (![2, 3, 4, 5, 6, 7].includes(raw.version as number) || !Array.isArray(raw.posts))
    throw new Error('This workspace format is not supported.');
  const posts = raw.posts.flatMap((value) => {
    if (!value || typeof value !== 'object') throw new Error('Invalid post.');
    const post = value as Record<string, unknown>;
    if (raw.sample === true && untouchedBuiltInSample(post)) return [];
    // v2 normally has no stored status. Honor it when present rather than promoting a legacy draft.
    if (raw.version === 2 && post.status !== undefined && post.status !== 'published') return [];
    if (
      raw.version !== 2 &&
      ['title', 'content', 'status', 'scheduledAt'].some((key) => key in post)
    )
      throw new Error('This workspace contains removed post fields.');
    const publishedAt = post.publishedAt;
    if (
      raw.version !== 2 &&
      (typeof publishedAt !== 'string' || (![6, 7].includes(raw.version as number) && !publishedAt))
    )
      throw new Error('This workspace contains an unpublished post.');
    if (raw.version === 2 && !publishedAt) return [];
    if ([4, 5, 6, 7].includes(raw.version as number) && 'metrics' in post)
      throw new Error('This workspace contains removed Viewers history.');
    const group = Array.isArray(raw.groups)
      ? (raw.groups.find(
          (item) =>
            item &&
            typeof item === 'object' &&
            (item as Record<string, unknown>).id === post.groupId,
        ) as Record<string, unknown> | undefined)
      : undefined;
    const label =
      typeof post.product === 'string' && post.product.trim()
        ? post.product.trim()
        : typeof group?.name === 'string' && group.name.trim()
          ? group.name.trim()
          : `${typeof post.platform === 'string' ? post.platform : 'Social'} post`;
    const matchingProducts = Array.isArray(raw.products)
      ? raw.products.filter(
          (item) =>
            item &&
            typeof item === 'object' &&
            (item as Record<string, unknown>).name === post.product,
        )
      : [];
    const backfilledProductId =
      raw.version !== 7 && matchingProducts.length === 1
        ? (matchingProducts[0] as Record<string, unknown>).id
        : undefined;
    const { metrics: _oldMetrics, ...currentPost } = post;
    return [
      {
        ...currentPost,
        title: label,
        content: '',
        status: 'published',
        scheduledAt: '',
        ...(backfilledProductId ? { productId: backfilledProductId } : {}),
        viewers: [4, 5, 6, 7].includes(raw.version as number)
          ? post.viewers
          : latestLegacyViewers(post.metrics),
      },
    ];
  });
  // New catalog fields are defaulted only for older formats. A malformed v5/v6
  // backup must fail validation instead of silently losing catalog records.
  const stores =
    [5, 6, 7].includes(raw.version as number) || !Array.isArray(raw.stores)
      ? raw.stores
      : raw.stores.map((value, index) => {
          if (!value || typeof value !== 'object') throw new Error('Invalid store.');
          return { ...value, logoImageUrl: '', ownerName: '', sortOrder: index };
        });
  const workspace = validateWorkspace({
    ...raw,
    stores,
    products: [5, 6, 7].includes(raw.version as number) ? raw.products : [],
    version: 1,
    sample: false,
    posts,
  });
  return validateWorkspace({
    ...workspace,
    groups: workspace.groups.map((group) => ({
      ...group,
      name: resolveFacebookGroupName(group.facebookId, group.name),
    })),
  });
}
