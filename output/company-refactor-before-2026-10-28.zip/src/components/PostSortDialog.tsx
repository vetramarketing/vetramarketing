'use client';

import type { PostSort } from '@/lib/post-tools';
import type { Translate } from '@/lib/types';
import { SelectionControl, type SelectionTrigger } from './SelectionDialog';

export const postSortOptions = [
  { value: 'viewers', en: 'Most Viewers', th: 'ผู้ชมมากที่สุด' },
  { value: 'viewers-per-day', en: 'Most Viewers / Day', th: 'ผู้ชมต่อวันมากที่สุด' },
  { value: 'recent', en: 'Newest', th: 'ใหม่ที่สุด' },
  { value: 'date-asc', en: 'Oldest', th: 'เก่าที่สุด' },
  { value: 'title', en: 'Product Name', th: 'ชื่อสินค้า' },
  { value: 'group', en: 'Group Name', th: 'ชื่อกลุ่ม' },
  { value: 'store', en: 'Store Name', th: 'ชื่อร้านค้า' },
] as const;

export default function PostSortDialog(props: {
  value: PostSort;
  t: Translate;
  onSelect: (value: PostSort) => void;
  trigger: SelectionTrigger;
}) {
  return (
    <SelectionControl
      {...props}
      title={props.t('Sort posts', 'เรียงลำดับโพสต์')}
      options={postSortOptions}
    />
  );
}
