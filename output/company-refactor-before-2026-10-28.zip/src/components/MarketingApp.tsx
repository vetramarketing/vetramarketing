'use client';

import { useDeferredValue, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { preconnect } from 'react-dom';
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  ClipboardList,
  Clock3,
  Eye,
  FileText,
  Globe2,
  LayoutDashboard,
  ListFilter,
  Menu,
  MousePointerClick,
  Package,
  Pencil,
  Pin,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Store as StoreIcon,
  Trash2,
  TrendingUp,
  Upload,
  Users,
  X,
} from 'lucide-react';
import type { Group, Locale, Post, Translate, View, Workspace } from '@/lib/types';
import { isWorkspaceView, viewFromPath, workspacePath } from '@/lib/workspace-routes';
import { createEmptyWorkspace, latestViewers, safeCatalogImageUrl } from '@/lib/data';
import { sortCatalog } from '@/lib/catalog';
import { productStoreIdMap } from '@/lib/product-store';
import { exportPostsCsv, previewPostsCsv } from '@/lib/csv';
import { providedSamplePosts, providedSamplePostsCsv } from '@/lib/provided-sample-posts';
import { addProvidedLatestReadings } from '@/lib/provided-latest-readings';
import { ensureProvidedProducts } from '@/lib/provided-products';
import { ensureProvidedPostLinks } from '@/lib/provided-post-links';
import { ensureProvidedViewerUpdates } from '@/lib/provided-viewers-update';
import { ensureProvidedMissingPosts } from '@/lib/provided-missing-posts';
import { ensureProvidedMetaUnmatchedPosts } from '@/lib/provided-meta-unmatched-posts';
import { ensureProvidedMetaRemaining } from '@/lib/provided-meta-remaining';
import { ensureProvidedMetaUpdate } from '@/lib/provided-meta-update';
import {
  applyMetaViewersUpdate,
  previewMetaViewersUpdate,
  type MetaUpdateOptions,
} from '@/lib/meta-viewers-import';
import { ensureVetraStoreName } from '@/lib/store-name-update';
import {
  averageViewersPerDay,
  filterPostsByProduct,
  matchesPostStatusFilter,
  postPublicationStatus,
  publicPostUrl,
  sortPosts,
  type PostSort,
  type PostStatusFilter,
} from '@/lib/post-tools';
import {
  readPostListReturnState,
  withPostListReturnState,
  type PostListReturnState,
} from '@/lib/post-list-navigation';
import {
  bangkokToday,
  millisecondsUntilTomorrow,
  POST_CLICKS_KEY,
  readDailyPostClicks,
  resetDailyPostClicks,
  recordPostClick,
  type DailyPostClicks,
} from '@/lib/post-clicks';
import { PostConflictError } from '@/lib/post-save';
import { preparePostSaveWithGroup, PostGroupSaveError } from '@/lib/post-save-with-group';
import { createBrowserWorkspaceRepository } from '@/lib/remote-workspace-repository';
import {
  WorkspaceIdentityConflict,
  WorkspaceRemovedError,
  WorkspaceRevisionConflict,
  WorkspaceStorageError,
  WorkspaceUnreadableError,
  type WorkspaceRepository,
  type WorkspaceSnapshot,
} from '@/lib/workspace-repository';
import PostEditorControl, { type PostEditorControlHandle } from './PostEditorControl';
import QuickSearchControl, { type QuickSearchControlHandle } from './QuickSearchControl';
import ImportControl from './ImportControl';
import MetaUpdateControl from './MetaUpdateControl';
import ToastControl, { type ToastControlHandle } from './ToastControl';
import { GroupsPanel, SettingsPanel, TrashPanel } from './WorkspacePanels';
import CatalogPanel from './CatalogPanel';
import PostSortDialog, { postSortOptions } from './PostSortDialog';
import PostPlatformDialog, { postPlatformOptions } from './PostPlatformDialog';
import PostStatusDialog, { postStatusOptions } from './PostStatusDialog';
import { SelectionControl } from './SelectionDialog';
import s from './MarketingApp.module.css';

const navItems: { id: View; en: string; th: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', en: 'Overview', th: 'ภาพรวม', icon: LayoutDashboard },
  { id: 'posts', en: 'Post library', th: 'คลังโพสต์', icon: ClipboardList },
  { id: 'groups', en: 'Facebook groups', th: 'กลุ่ม Facebook', icon: Users },
  { id: 'analytics', en: 'Performance', th: 'ผลลัพธ์', icon: BarChart3 },
  { id: 'products', en: 'Products', th: 'สินค้า', icon: Package },
  { id: 'stores', en: 'Stores & brands', th: 'ร้านค้าและแบรนด์', icon: StoreIcon },
  { id: 'settings', en: 'Workspace settings', th: 'ตั้งค่าพื้นที่ทำงาน', icon: Settings2 },
  { id: 'trash', en: 'Trash', th: 'ถังขยะ', icon: Trash2 },
];
function download(text: string, name: string, type = 'text/csv;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Warm only the destination origin on user intent, without requesting the post itself. */
function warmPostConnection(value: string) {
  try {
    const url = new URL(value);
    if (
      url.protocol !== 'https:' ||
      url.username ||
      url.password ||
      url.origin === window.location.origin
    )
      return;
    // React deduplicates repeated hints for posts hosted on the same origin.
    preconnect(url.origin);
  } catch {
    // A speculative hint must never interrupt navigation or editing.
  }
}
const dateKey = (value: Date | string) =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Bangkok',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(value));
function Mark() {
  return (
    <span className={s.mark} aria-hidden="true">
      <svg viewBox="0 0 42 40">
        <path d="M3 5h9l12 28-5 8zm25 0h9L25 33l-5-12z" fill="currentColor" />
      </svg>
    </span>
  );
}
function BackToTop({ t }: { t: Translate }) {
  const button = useRef<HTMLButtonElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setVisible(window.scrollY > 320 || document.activeElement === button.current);
    };
    const scheduleUpdate = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', scheduleUpdate, { passive: true });
    window.addEventListener('resize', scheduleUpdate);
    return () => {
      window.removeEventListener('scroll', scheduleUpdate);
      window.removeEventListener('resize', scheduleUpdate);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  function goToTop() {
    document.getElementById('main')?.focus({ preventScroll: true });
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    });
  }

  return (
    <button
      ref={button}
      type="button"
      className={`${s.backToTop} ${visible ? s.backToTopVisible : ''}`}
      aria-label={t('Go to top', 'กลับขึ้นด้านบน')}
      aria-hidden={visible ? undefined : true}
      tabIndex={visible ? 0 : -1}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(window.scrollY > 320)}
      onClick={goToTop}
    >
      <ChevronUp size={23} strokeWidth={2.5} aria-hidden="true" />
    </button>
  );
}
function displayStoreName(name: string) {
  return name === 'VETRA Store' ? 'VETRA STORE' : name;
}
function PlatformBadge({ platform = 'facebook' }: { platform?: string }) {
  return (
    <span className={`${s.platform} ${s[platform] || ''}`} title={platform} aria-label={platform}>
      {platform === 'facebook' ? (
        <img src="/icons/Facebook.png" alt="" width={22} height={22} loading="lazy" />
      ) : platform === 'instagram' ? (
        '◎'
      ) : platform === 'linkedin' ? (
        'in'
      ) : (
        '♪'
      )}
    </span>
  );
}

function PostTableHead({ t }: { t: Translate }) {
  return (
    <thead>
      <tr>
        <th scope="col">
          <span className={s.tableHeaderLabel}>
            <span aria-hidden="true">🛍️</span>
            <span>{t('PRODUCT', 'สินค้า')}</span>
            <span>/</span>
            <span aria-hidden="true">🏬</span>
            <span>{t('STORE', 'ร้านค้า')}</span>
          </span>
        </th>
        <th scope="col">
          <span className={s.tableHeaderLabel}>
            <span aria-hidden="true">🌐</span>
            <span>{t('DESTINATION', 'ปลายทาง')}</span>
          </span>
        </th>
        <th scope="col" title={t('Viewers', 'ผู้ชม')}>
          <Eye size={19} aria-hidden="true" />
          <span className={s.srOnly}>{t('Viewers', 'ผู้ชม')}</span>
        </th>
        <th
          scope="col"
          title={t(
            'Approximate average: current Viewers total divided by days since publication (minimum one day)',
            'ค่าเฉลี่ยโดยประมาณ: ยอดผู้ชมล่าสุดหารด้วยจำนวนวันตั้งแต่เผยแพร่ (อย่างน้อยหนึ่งวัน)',
          )}
        >
          <span className={s.tableHeaderLabel} aria-hidden="true">
            <Eye size={19} />
            <span>/ {t('Day', 'วัน')}</span>
          </span>
          <span className={s.srOnly}>{t('Viewers per day', 'ผู้ชมต่อวัน')}</span>
        </th>
        <th scope="col" title={t('Published on', 'วันที่เผยแพร่')}>
          <CalendarDays size={19} aria-hidden="true" />
          <span className={s.srOnly}>{t('Published on', 'วันที่เผยแพร่')}</span>
        </th>
        <th scope="col">
          <span className={s.srOnly}>{t('Actions', 'การดำเนินการ')}</span>
        </th>
      </tr>
    </thead>
  );
}

function PostListSkeleton({ t }: { t: Translate }) {
  return (
    <div className={s.postListSkeleton}>
      <div className={s.skeletonStatus} role="status">
        <span className={s.skeletonStatusDot} aria-hidden="true" />
        {t('Loading posts…', 'กำลังโหลดโพสต์…')}
      </div>
      <div className={s.tableScroll} aria-busy="true">
        <table className={`${s.table} ${s.skeletonTable}`} aria-hidden="true">
          <PostTableHead t={t} />
          <tbody>
            {Array.from({ length: 5 }, (_, index) => (
              <tr key={index}>
                <td>
                  <div className={s.skeletonProduct}>
                    <span className={`${s.skeletonBlock} ${s.skeletonPin}`} />
                    <span className={`${s.skeletonBlock} ${s.skeletonThumbnail}`} />
                    <span className={s.skeletonProductText}>
                      <span className={`${s.skeletonBlock} ${s.skeletonTitle}`} />
                      <span className={`${s.skeletonBlock} ${s.skeletonMeta}`} />
                    </span>
                  </div>
                </td>
                <td>
                  <div className={s.skeletonDestination}>
                    <span className={`${s.skeletonBlock} ${s.skeletonPlatform}`} />
                    <span className={`${s.skeletonBlock} ${s.skeletonDestinationText}`} />
                  </div>
                </td>
                <td data-label={t('Viewers', 'ผู้ชม')}>
                  <span className={`${s.skeletonBlock} ${s.skeletonNumber}`} />
                </td>
                <td data-label={t('Viewer/day', 'ผู้ชม/วัน')}>
                  <span className={`${s.skeletonBlock} ${s.skeletonNumber}`} />
                </td>
                <td data-label={t('Published', 'เผยแพร่เมื่อ')}>
                  <span className={`${s.skeletonBlock} ${s.skeletonDate}`} />
                </td>
                <td>
                  <div className={s.rowActions}>
                    <span className={`${s.skeletonBlock} ${s.skeletonAction}`} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function MarketingApp({ initialView = 'overview' }: { initialView?: View }) {
  const [data, setData] = useState<Workspace | null>(null),
    [revision, setRevision] = useState(''),
    [locale, setLocale] = useState<Locale>('th'),
    [view, setView] = useState<View>(initialView),
    [storeId, setStoreId] = useState('all'),
    [productId, setProductId] = useState('all'),
    [search, setSearch] = useState(''),
    [platform, setPlatform] = useState('all'),
    [statusFilter, setStatusFilter] = useState<PostStatusFilter>('normal'),
    [sampleImporting, setSampleImporting] = useState(false),
    [latestReadingsImporting, setLatestReadingsImporting] = useState(false),
    [storageError, setStorageError] = useState(''),
    [sort, setSort] = useState<PostSort>('viewers'),
    [pinSavingId, setPinSavingId] = useState<string | null>(null),
    [postClicks, setPostClicks] = useState<DailyPostClicks>({ day: '', counts: {} }),
    [clickTrackingError, setClickTrackingError] = useState(false);
  const navDialog = useRef<HTMLDialogElement>(null),
    menuButton = useRef<HTMLButtonElement>(null),
    // Toggling the drawer must not re-render the entire post table.
    navOpen = useRef(false),
    editorControl = useRef<PostEditorControlHandle>(null),
    quickSearchControl = useRef<QuickSearchControlHandle>(null),
    toastControl = useRef<ToastControlHandle>(null),
    pendingToast = useRef(''),
    repository = useRef<WorkspaceRepository | null>(null),
    navCloseTimer = useRef<ReturnType<typeof setTimeout> | null>(null),
    navOpener = useRef<HTMLElement | null>(null),
    previousBodyOverflow = useRef('');
  const sampleImportBusy = useRef(false);
  const pinSaveBusy = useRef(false);
  const pinScrollPosition = useRef<{ left: number; top: number } | null>(null);
  const postListViewport = useRef<HTMLDivElement>(null);
  const postListHeight = useRef(0);
  const [postListRestore, setPostListRestore] = useState<PostListReturnState | null>(null);
  const productStoresById = useMemo(
    () => productStoreIdMap(data?.products ?? [], data?.posts ?? []),
    [data?.products, data?.posts],
  );
  const t: Translate = (en, th) => (locale === 'th' ? th : en);
  function notify(message: string) {
    if (toastControl.current) toastControl.current.show(message);
    else pendingToast.current = message;
  }
  useEffect(() => {
    if (!data || !pendingToast.current || !toastControl.current) return;
    toastControl.current.show(pendingToast.current);
    pendingToast.current = '';
  }, [data]);
  function openNavigation() {
    const dialog = navDialog.current;
    if (!dialog) return;
    if (navCloseTimer.current) {
      clearTimeout(navCloseTimer.current);
      navCloseTimer.current = null;
    }
    if (!dialog.open) {
      navOpener.current = document.activeElement as HTMLElement | null;
      previousBodyOverflow.current = document.body.style.overflow;
      dialog.showModal();
      document.body.style.overflow = 'hidden';
    }
    dialog.classList.remove(s.navClosing);
    dialog.querySelector<HTMLElement>(`.${s.closeNav}`)?.focus({ preventScroll: true });
    navOpen.current = true;
    menuButton.current?.setAttribute('aria-expanded', 'true');
  }
  function closeNavigation() {
    const dialog = navDialog.current;
    if (!dialog?.open || navCloseTimer.current) return;
    dialog.classList.add(s.navClosing);
    navOpen.current = false;
    menuButton.current?.setAttribute('aria-expanded', 'false');
    const finish = () => {
      dialog.close();
      dialog.classList.remove(s.navClosing);
      document.body.style.overflow = previousBodyOverflow.current;
      navOpener.current?.focus({ preventScroll: true });
      navCloseTimer.current = null;
    };
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) finish();
    else navCloseTimer.current = setTimeout(finish, 150);
  }
  function applySnapshot(snapshot: WorkspaceSnapshot) {
    setData(snapshot.workspace);
    setRevision(snapshot.revision);
    setStorageError('');
  }
  function noteRepositoryFailure(error: unknown) {
    if (
      error instanceof WorkspaceUnreadableError ||
      error instanceof WorkspaceRemovedError ||
      error instanceof WorkspaceStorageError
    )
      setStorageError(
        'Saved data could not be read or written. It has been preserved. Export or restore a backup in Settings before continuing. / ไม่สามารถอ่านหรือบันทึกข้อมูลเดิมได้ ข้อมูลเดิมยังคงอยู่',
      );
  }
  async function applyMetaUpdates(
    source: string,
    previewRevision: string,
    options: MetaUpdateOptions,
  ) {
    const store = repository.current;
    if (!store || storageError)
      throw new Error(
        t(
          'Restore a backup in Settings before updating posts.',
          'กรุณากู้คืนไฟล์สำรองในการตั้งค่าก่อนอัปเดตโพสต์',
        ),
      );
    let latest: WorkspaceSnapshot;
    try {
      latest = await store.load();
    } catch (error) {
      noteRepositoryFailure(error);
      throw error;
    }
    if (latest.revision !== previewRevision) {
      applySnapshot(latest);
      throw new Error(
        t(
          'The workspace changed. Review a fresh preview before applying updates.',
          'พื้นที่ทำงานเปลี่ยนไป กรุณาตรวจสอบตัวอย่างล่าสุดก่อนอัปเดต',
        ),
      );
    }
    const freshPreview = previewMetaViewersUpdate(source, latest.workspace, options);
    if (!freshPreview.changes.length)
      throw new Error(
        t('No safe changes are ready to apply.', 'ไม่มีข้อมูลที่อัปเดตได้อย่างปลอดภัย'),
      );
    try {
      applySnapshot(
        await store.commit({
          workspace: applyMetaViewersUpdate(latest.workspace, freshPreview),
          expectedRevision: latest.revision,
          operationId: crypto.randomUUID(),
        }),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceRevisionConflict) {
        applySnapshot(await store.load());
        throw new Error(
          t(
            'The workspace changed while saving. Review a fresh preview and try again.',
            'พื้นที่ทำงานเปลี่ยนระหว่างบันทึก กรุณาตรวจสอบตัวอย่างล่าสุดแล้วลองใหม่',
          ),
        );
      }
      throw error;
    }
    notify(
      t(
        `Updated ${freshPreview.changes.length} ${freshPreview.changes.length === 1 ? 'post' : 'posts'}${freshPreview.issues.length ? `; ${freshPreview.issues.length} ${freshPreview.issues.length === 1 ? 'row needs' : 'rows need'} review` : ''}.`,
        `อัปเดต ${freshPreview.changes.length} โพสต์${freshPreview.issues.length ? `; มี ${freshPreview.issues.length} แถวที่ต้องตรวจสอบ` : ''}`,
      ),
    );
  }
  async function applyCsvImport(source: string, destination: string, previewRevision: string) {
    const store = repository.current;
    if (!store || storageError)
      throw new Error(
        t(
          'Restore a backup in Settings before importing.',
          'กรุณากู้คืนไฟล์สำรองในการตั้งค่าก่อนนำเข้า',
        ),
      );
    let latest: WorkspaceSnapshot;
    try {
      latest = await store.load();
    } catch (error) {
      noteRepositoryFailure(error);
      throw error;
    }
    if (latest.revision !== previewRevision) {
      applySnapshot(latest);
      throw new Error(
        t(
          'The workspace changed. Review the updated import preview, then try again.',
          'พื้นที่ทำงานมีการเปลี่ยนแปลง กรุณาตรวจสอบตัวอย่างนำเข้าที่อัปเดตแล้วลองอีกครั้ง',
        ),
      );
    }
    const freshPreview = previewPostsCsv(source, latest.workspace, destination);
    if (!freshPreview.posts.length)
      throw new Error(t('No posts are ready to import.', 'ไม่มีโพสต์ที่พร้อมนำเข้า'));
    try {
      applySnapshot(
        await store.commit({
          workspace: {
            ...latest.workspace,
            posts: [...freshPreview.posts, ...latest.workspace.posts],
            groups: [...latest.workspace.groups, ...freshPreview.groups],
          },
          expectedRevision: latest.revision,
          operationId: crypto.randomUUID(),
        }),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceRevisionConflict) {
        applySnapshot(await store.load());
        throw new Error(
          t(
            'The workspace changed while importing. Review the updated preview, then try again.',
            'พื้นที่ทำงานเปลี่ยนแปลงระหว่างนำเข้า กรุณาตรวจสอบตัวอย่างที่อัปเดตแล้วลองอีกครั้ง',
          ),
        );
      }
      throw error;
    }
    notify(
      t(
        `${freshPreview.posts.length} posts imported.`,
        `นำเข้า ${freshPreview.posts.length} โพสต์แล้ว`,
      ),
    );
  }
  useEffect(() => {
    const store = createBrowserWorkspaceRepository();
    repository.current = store;
    let active = true;
    try {
      setLocale(store.readLocale());
    } catch {
      setLocale('th');
    }
    void store.load().then(
      async (snapshot) => {
        if (!active) return;
        try {
          const named = await ensureVetraStoreName(store, snapshot);
          const catalog = await ensureProvidedProducts(store, named);
          const posts = await ensureProvidedPostLinks(store, catalog);
          const viewers = await ensureProvidedViewerUpdates(store, posts);
          const updated = await ensureProvidedMissingPosts(store, viewers);
          const recent = await ensureProvidedMetaUpdate(store, updated);
          const unmatched = await ensureProvidedMetaUnmatchedPosts(store, recent);
          const remaining = await ensureProvidedMetaRemaining(store, unmatched);
          if (active) applySnapshot(remaining);
        } catch {
          const latest = await store.load().catch(() => snapshot);
          if (!active) return;
          applySnapshot(latest);
          notify(
            t(
              'Workspace updates could not be saved. Your existing data is available; reload to retry.',
              'บันทึกการอัปเดตพื้นที่ทำงานไม่สำเร็จ ข้อมูลเดิมยังใช้งานได้ โหลดหน้าใหม่เพื่อลองอีกครั้ง',
            ),
          );
        }
      },
      () => {
        if (!active) return;
        setStorageError(
          'Saved data could not be loaded. It has been preserved. Export or restore a backup in Settings before continuing. / ไม่สามารถโหลดข้อมูลที่บันทึกไว้ได้ ข้อมูลเดิมยังคงอยู่',
        );
        setData(createEmptyWorkspace());
      },
    );
    const unsubscribe = store.subscribe((result) => {
      if (!active) return;
      if (result instanceof Error) {
        setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
      } else {
        applySnapshot(result);
      }
    });
    return () => {
      active = false;
      unsubscribe();
      repository.current = null;
    };
  }, []);
  useEffect(() => {
    let midnightTimer: ReturnType<typeof setTimeout>;
    const refresh = () => {
      const day = bangkokToday();
      try {
        setPostClicks(readDailyPostClicks(window.localStorage, day));
        setClickTrackingError(false);
      } catch {
        setPostClicks({ day, counts: {} });
        setClickTrackingError(true);
      }
    };
    const scheduleMidnight = () => {
      clearTimeout(midnightTimer);
      midnightTimer = setTimeout(() => {
        refresh();
        scheduleMidnight();
      }, millisecondsUntilTomorrow() + 20);
    };
    const onStorage = (event: StorageEvent) => {
      if (event.key === POST_CLICKS_KEY || event.key === null) refresh();
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        refresh();
        scheduleMidnight();
      }
    };
    refresh();
    scheduleMidnight();
    window.addEventListener('storage', onStorage);
    window.addEventListener('focus', onVisibility);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      clearTimeout(midnightTimer);
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('focus', onVisibility);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);
  useEffect(() => {
    if (data && storeId !== 'all' && !data.stores.some((store) => store.id === storeId)) {
      setStoreId('all');
    }
  }, [data, storeId]);
  useEffect(() => {
    if (
      data &&
      productId !== 'all' &&
      !data.products.some(
        (product) =>
          product.id === productId &&
          !product.deletedAt &&
          (storeId === 'all' || productStoresById.get(product.id)?.includes(storeId)),
      )
    ) {
      setProductId('all');
    }
  }, [data, productId, storeId, productStoresById]);
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);
  useEffect(() => {
    function handleSearchShortcut(event: KeyboardEvent) {
      if (event.repeat || event.isComposing) return;
      if ((event.ctrlKey || event.metaKey) && !event.altKey && event.key.toLowerCase() === 'k') {
        if (quickSearchControl.current?.isOpen()) {
          event.preventDefault();
          quickSearchControl.current.toggle();
          return;
        }
        if (
          editorControl.current?.currentPost() !== undefined ||
          document.querySelector('dialog[open]')
        )
          return;
        event.preventDefault();
        quickSearchControl.current?.open();
      }
    }
    window.addEventListener('keydown', handleSearchShortcut);
    return () => window.removeEventListener('keydown', handleSearchShortcut);
  }, []);
  useEffect(() => {
    const syncView = () => {
      const legacyHash = window.location.hash.slice(1);
      const legacyView = isWorkspaceView(legacyHash) ? legacyHash : null;
      if (legacyView) {
        window.history.replaceState(
          window.history.state,
          '',
          `${workspacePath(legacyView)}${window.location.search}`,
        );
      }
      const next = legacyView ?? viewFromPath(window.location.pathname) ?? 'overview';
      setView(next);
      const saved = next === 'posts' ? readPostListReturnState(window.history.state) : null;
      setPostListRestore(saved);
      if (saved) {
        window.history.scrollRestoration = 'manual';
        setStoreId(saved.storeId);
        setProductId(saved.productId);
        setSearch(saved.search);
        setPlatform(saved.platform);
        setStatusFilter(saved.statusFilter);
        setSort(saved.sort);
      }
    };
    syncView();
    window.addEventListener('hashchange', syncView);
    window.addEventListener('popstate', syncView);
    return () => {
      window.removeEventListener('hashchange', syncView);
      window.removeEventListener('popstate', syncView);
    };
  }, []);
  useEffect(() => {
    // Also cover browser reloads and navigation from the address bar, without an unload handler.
    const onPageHide = () => rememberPostList();
    window.addEventListener('pagehide', onPageHide);
    return () => window.removeEventListener('pagehide', onPageHide);
  }, [view, storeId, productId, search, platform, statusFilter, sort]);
  useEffect(
    () => () => {
      if (navCloseTimer.current) clearTimeout(navCloseTimer.current);
      if (navDialog.current?.open) {
        navDialog.current.close();
        document.body.style.overflow = previousBodyOverflow.current;
      }
    },
    [],
  );
  useLayoutEffect(() => {
    // Keep ARIA correct if an unrelated workspace update renders while the drawer is open.
    menuButton.current?.setAttribute('aria-expanded', String(navOpen.current));
  });
  async function update(next: Workspace, allowRecovery = false): Promise<boolean> {
    if (storageError && !allowRecovery) {
      notify(
        t(
          'Restore a backup in Settings before changing this workspace.',
          'กรุณากู้คืนไฟล์สำรองในการตั้งค่าก่อนแก้ไขข้อมูล',
        ),
      );
      return false;
    }
    try {
      const store = repository.current;
      if (!store) throw new Error('Workspace storage is not ready.');
      const saved =
        storageError && allowRecovery
          ? await store.recover(next)
          : await store.commit({
              workspace: next,
              expectedRevision: revision,
              operationId: crypto.randomUUID(),
            });
      applySnapshot(saved);
      return true;
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceIdentityConflict) {
        notify(
          t(
            'This post is already tracked or in Trash. Open or restore the existing record instead.',
            'โพสต์นี้ถูกติดตามอยู่แล้วหรืออยู่ในถังขยะ กรุณาเปิดหรือกู้คืนรายการเดิมแทน',
          ),
        );
        return false;
      }
      if (error instanceof WorkspaceRevisionConflict) {
        try {
          const latest = await repository.current?.load();
          if (latest) applySnapshot(latest);
        } catch {
          setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
        }
        notify(
          t(
            'This workspace changed in another tab. Review the latest data, then try again.',
            'พื้นที่ทำงานถูกแก้ไขในแท็บอื่น กรุณาตรวจสอบข้อมูลล่าสุดแล้วลองอีกครั้ง',
          ),
        );
        return false;
      }
      notify(
        error instanceof Error
          ? error.message
          : t(
              'Could not save changes. Your previous data is intact.',
              'ไม่สามารถบันทึกได้ ข้อมูลเดิมยังคงอยู่',
            ),
      );
      return false;
    }
  }
  async function togglePostPin(post: Post) {
    if (pinSaveBusy.current || storageError || !repository.current || !data || !revision) return;
    pinSaveBusy.current = true;
    setPinSavingId(post.id);
    try {
      const store = repository.current;
      const current = data.posts.find((item) => item.id === post.id);
      if (!current || current.deletedAt || Boolean(current.pinned) !== Boolean(post.pinned)) {
        notify(
          t(
            'This post changed. Review the latest version and try again.',
            'โพสต์นี้มีการเปลี่ยนแปลง กรุณาตรวจสอบข้อมูลล่าสุดแล้วลองอีกครั้ง',
          ),
        );
        return;
      }
      const next = {
        ...data,
        posts: data.posts.map((item) =>
          item.id === post.id ? { ...item, pinned: !Boolean(current.pinned) } : item,
        ),
      };
      const saved = await store.commit({
        workspace: next,
        expectedRevision: revision,
        operationId: crypto.randomUUID(),
      });
      pinScrollPosition.current = { left: window.scrollX, top: window.scrollY };
      applySnapshot(saved);
      notify(
        current.pinned
          ? t('Post unpinned.', 'เลิกปักหมุดโพสต์แล้ว')
          : t('Post pinned to the top.', 'ปักหมุดโพสต์ไว้ด้านบนแล้ว'),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceRevisionConflict) {
        try {
          const latest = await repository.current?.load();
          if (latest) applySnapshot(latest);
        } catch {
          setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
        }
        notify(
          t(
            'This workspace changed while pinning. Review the latest posts and try again.',
            'พื้นที่ทำงานเปลี่ยนไประหว่างปักหมุด กรุณาตรวจสอบโพสต์ล่าสุดแล้วลองอีกครั้ง',
          ),
        );
      } else {
        notify(
          error instanceof Error
            ? error.message
            : t(
                'Could not save the pin. Your previous data is intact.',
                'บันทึกหมุดไม่สำเร็จ ข้อมูลเดิมยังคงอยู่',
              ),
        );
      }
    } finally {
      pinSaveBusy.current = false;
      setPinSavingId(null);
    }
  }
  function changeLocale(value: Locale) {
    setLocale(value);
    try {
      if (!repository.current) throw new Error('Workspace storage is not ready.');
      repository.current.writeLocale(value);
    } catch {
      notify(t('Language could not be saved.', 'ไม่สามารถบันทึกภาษาได้'));
    }
  }
  async function importProvidedSamples() {
    if (sampleImportBusy.current) return;
    sampleImportBusy.current = true;
    setSampleImporting(true);
    try {
      if (storageError || !repository.current)
        throw new Error(
          t('Restore your workspace before importing.', 'กรุณากู้คืนพื้นที่ทำงานก่อนนำเข้า'),
        );
      const latest = await repository.current.load();
      const existingPostIds = new Set(latest.workspace.posts.map((post) => post.facebookPostId));
      if (providedSamplePosts.every((sample) => existingPostIds.has(sample.postId))) {
        applySnapshot(latest);
        notify(t('All sample posts are already here.', 'มีโพสต์ตัวอย่างทั้งหมดแล้ว'));
        return;
      }
      const destination = storeId === 'all' ? sortCatalog(latest.workspace.stores)[0]?.id : storeId;
      const preview = previewPostsCsv(
        providedSamplePostsCsv(existingPostIds),
        latest.workspace,
        destination,
      );
      if (preview.errors.length) throw new Error(preview.errors[0]);
      if (!preview.posts.length) {
        applySnapshot(latest);
        notify(t('All sample posts are already here.', 'มีโพสต์ตัวอย่างทั้งหมดแล้ว'));
        return;
      }
      const withReadings = addProvidedLatestReadings({
        ...latest.workspace,
        posts: [...preview.posts, ...latest.workspace.posts],
        groups: [...latest.workspace.groups, ...preview.groups],
      });
      const saved = await repository.current.commit({
        workspace: withReadings.workspace,
        expectedRevision: latest.revision,
        operationId: crypto.randomUUID(),
      });
      applySnapshot(saved);
      setStoreId(destination);
      navigate('posts');
      clearLibraryFilters();
      notify(
        t(
          `${preview.posts.length} sample posts added.`,
          `เพิ่มโพสต์ตัวอย่าง ${preview.posts.length} รายการแล้ว`,
        ),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceRevisionConflict) {
        try {
          const latest = await repository.current?.load();
          if (latest) applySnapshot(latest);
        } catch {
          setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
        }
        notify(
          t(
            'Workspace changed. Review the latest posts and try again.',
            'พื้นที่ทำงานเปลี่ยนไป กรุณาตรวจสอบโพสต์ล่าสุดแล้วลองใหม่',
          ),
        );
      } else {
        notify(
          error instanceof Error
            ? error.message
            : t('Could not add sample posts.', 'ไม่สามารถเพิ่มโพสต์ตัวอย่างได้'),
        );
      }
    } finally {
      sampleImportBusy.current = false;
      setSampleImporting(false);
    }
  }
  async function importProvidedLatestReadings() {
    if (sampleImportBusy.current) return;
    sampleImportBusy.current = true;
    setLatestReadingsImporting(true);
    try {
      if (storageError || !repository.current)
        throw new Error(
          t(
            'Restore your workspace before updating Viewers.',
            'กรุณากู้คืนพื้นที่ทำงานก่อนอัปเดตยอดผู้ชม',
          ),
        );
      const latest = await repository.current.load();
      const result = addProvidedLatestReadings(latest.workspace);
      if (!result.added) {
        applySnapshot(latest);
        notify(
          result.conflicts
            ? t(
                'Some posts have a different current total. Those totals were left unchanged.',
                'บางโพสต์มียอดผู้ชมล่าสุดต่างกัน ระบบจึงคงยอดเดิมไว้',
              )
            : t('Latest totals are already saved.', 'บันทึกยอดผู้ชมล่าสุดแล้ว'),
        );
        return;
      }
      const saved = await repository.current.commit({
        workspace: result.workspace,
        expectedRevision: latest.revision,
        operationId: crypto.randomUUID(),
      });
      applySnapshot(saved);
      notify(
        result.conflicts
          ? t(
              `${result.added} Viewers totals updated; ${result.conflicts} different totals kept unchanged.`,
              `อัปเดตยอดผู้ชม ${result.added} รายการ และคงยอดเดิม ${result.conflicts} รายการ`,
            )
          : t(
              `${result.added} Viewers totals updated.`,
              `อัปเดตยอดผู้ชม ${result.added} รายการแล้ว`,
            ),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceRevisionConflict) {
        try {
          const latest = await repository.current?.load();
          if (latest) applySnapshot(latest);
        } catch {
          setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
        }
        notify(
          t(
            'Workspace changed. Review the latest posts and try again.',
            'พื้นที่ทำงานเปลี่ยนไป กรุณาตรวจสอบโพสต์ล่าสุดแล้วลองใหม่',
          ),
        );
      } else {
        notify(
          error instanceof Error
            ? error.message
            : t('Could not update Viewers totals.', 'ไม่สามารถอัปเดตยอดผู้ชมได้'),
        );
      }
    } finally {
      sampleImportBusy.current = false;
      setLatestReadingsImporting(false);
    }
  }
  const storeScoped = useMemo(
    () =>
      data?.posts.filter((p) => !p.deletedAt && (storeId === 'all' || p.storeId === storeId)) ?? [],
    [data, storeId],
  );
  const scoped = useMemo(
    () => filterPostsByProduct(storeScoped, data?.products ?? [], productId, data?.posts ?? []),
    [storeScoped, data, productId],
  );
  const storesById = useMemo(
    () => new Map((data?.stores ?? []).map((item) => [item.id, item])),
    [data?.stores],
  );
  const groupsById = useMemo(
    () => new Map((data?.groups ?? []).map((item) => [item.id, item])),
    [data?.groups],
  );
  const destinationsById = useMemo(
    () => new Map((data?.destinations ?? []).map((item) => [item.id, item])),
    [data?.destinations],
  );
  const productsById = useMemo(
    () =>
      new Map(
        (data?.products ?? []).filter((item) => !item.deletedAt).map((item) => [item.id, item]),
      ),
    [data?.products],
  );
  const uniqueProductsByName = useMemo(() => {
    const index = new Map<string, Workspace['products'][number] | undefined>();
    for (const product of data?.products ?? []) {
      if (product.deletedAt) continue;
      const name = product.name.trim();
      index.set(name, index.has(name) ? undefined : product);
    }
    return index;
  }, [data?.products]);
  const missingSampleCount = providedSamplePosts.filter(
    (sample) => !data?.posts.some((post) => post.facebookPostId === sample.postId),
  ).length;
  const pendingLatestReadings = useMemo(
    () => (data ? addProvidedLatestReadings(data).added : 0),
    [data],
  );
  const published = scoped.filter((post) => postPublicationStatus(post) === 'published');
  const groups =
    data?.groups.filter((g) => !g.deletedAt && (storeId === 'all' || g.storeId === storeId)) ?? [];
  const total = published.reduce((n, p) => n + latestViewers(p), 0);
  const rateFormatter = useMemo(
    () =>
      new Intl.NumberFormat(locale === 'th' ? 'th-TH' : 'en-US', {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      }),
    [locale],
  );
  const numberFormatter = useMemo(
    () => new Intl.NumberFormat(locale === 'th' ? 'th-TH' : 'en-US', { maximumFractionDigits: 0 }),
    [locale],
  );
  const compactFormatter = useMemo(
    () => new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }),
    [],
  );
  const dateFormatter = useMemo(
    () =>
      new Intl.DateTimeFormat(locale === 'th' ? 'th-TH' : 'en-GB', {
        day: 'numeric',
        month: 'short',
        timeZone: 'Asia/Bangkok',
      }),
    [locale],
  );
  const fullDateFormatter = useMemo(
    () =>
      new Intl.DateTimeFormat(locale === 'th' ? 'th-TH' : 'en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        timeZone: 'Asia/Bangkok',
      }),
    [locale],
  );
  const fmt = (n: number) => numberFormatter.format(n);
  const short = (n: number) => compactFormatter.format(n);
  const formatDate = (date: string, includeYear = false) =>
    date ? (includeYear ? fullDateFormatter : dateFormatter).format(new Date(date)) : '—';
  const chosenStore = data?.stores.find((st) => st.id === storeId);
  function navigate(next: View) {
    closeNavigation();
    rememberPostList();
    setPostListRestore(null);
    if (window.location.pathname !== workspacePath(next) || window.location.hash)
      window.history.pushState(null, '', workspacePath(next));
    window.scrollTo({ top: 0, behavior: 'instant' });
    setView(next);
    setSearch('');
    setPlatform('all');
    setStatusFilter('normal');
  }
  function newPost() {
    editorControl.current?.open(null);
  }
  async function savePost(post: Post, pendingGroup: Group | null): Promise<void> {
    const store = repository.current;
    if (!data || !store || storageError)
      throw new Error(
        t(
          'Restore a backup in Settings before changing this workspace.',
          'กรุณากู้คืนไฟล์สำรองในการตั้งค่าก่อนแก้ไขข้อมูล',
        ),
      );
    let latest: WorkspaceSnapshot;
    try {
      latest = await store.load();
    } catch (error) {
      noteRepositoryFailure(error);
      throw new Error(
        t(
          'Your saved workspace could not be read. Your edits remain here. Download a backup before reloading.',
          'ไม่สามารถอ่านพื้นที่ทำงานที่บันทึกไว้ได้ การแก้ไขยังอยู่ที่นี่ กรุณาดาวน์โหลดไฟล์สำรองก่อนโหลดหน้าใหม่',
        ),
      );
    }
    let next: Workspace;
    try {
      next = preparePostSaveWithGroup(
        latest.workspace,
        post,
        editorControl.current?.currentPost() ?? null,
        pendingGroup,
      );
    } catch (error) {
      if (error instanceof PostGroupSaveError) {
        applySnapshot(latest);
        if (error.reason === 'group-in-trash')
          throw new Error(
            t(
              'This Facebook group is in Trash. Restore it before saving this post.',
              'กลุ่ม Facebook นี้อยู่ในถังขยะ กรุณากู้คืนก่อนบันทึกโพสต์',
            ),
          );
        if (error.reason === 'group-id-collision')
          throw new Error(
            t(
              'The new group could not be saved. Close and reopen the form, then try again.',
              'บันทึกกลุ่มใหม่ไม่สำเร็จ กรุณาปิดและเปิดแบบฟอร์มอีกครั้ง แล้วลองใหม่',
            ),
          );
        throw new Error(
          t(
            'The group extracted from the link is no longer valid. Paste the link again.',
            'ข้อมูลกลุ่มที่อ่านจากลิงก์ไม่ถูกต้องแล้ว กรุณาวางลิงก์อีกครั้ง',
          ),
        );
      }
      if (!(error instanceof PostConflictError)) throw error;
      applySnapshot(latest);
      if (error.reason === 'existing-post')
        throw new Error(
          t(
            'This post is already tracked or in Trash. Open or restore the existing record instead.',
            'โพสต์นี้ถูกติดตามอยู่แล้วหรืออยู่ในถังขยะ กรุณาเปิดหรือกู้คืนรายการเดิมแทน',
          ),
        );
      throw new Error(
        t(
          'This post changed in another tab or is no longer available. Your edits remain here. Copy anything you want to keep, then close and reopen the latest version.',
          'โพสต์นี้ถูกแก้ไขในแท็บอื่นหรือไม่พร้อมใช้งานแล้ว การแก้ไขของคุณยังอยู่ที่นี่ คัดลอกสิ่งที่ต้องการเก็บไว้ แล้วปิดและเปิดโพสต์เวอร์ชันล่าสุดอีกครั้ง',
        ),
      );
    }
    try {
      applySnapshot(
        await store.commit({
          workspace: next,
          expectedRevision: latest.revision,
          operationId: crypto.randomUUID(),
        }),
      );
    } catch (error) {
      noteRepositoryFailure(error);
      if (error instanceof WorkspaceIdentityConflict)
        throw new Error(
          t(
            'This post is already tracked or in Trash. Open or restore the existing record instead.',
            'โพสต์นี้ถูกติดตามอยู่แล้วหรืออยู่ในถังขยะ กรุณาเปิดหรือกู้คืนรายการเดิมแทน',
          ),
        );
      if (error instanceof WorkspaceRevisionConflict) {
        try {
          applySnapshot(await store.load());
        } catch {
          setStorageError('Updated workspace could not be read. / ไม่สามารถอ่านข้อมูลที่อัปเดตได้');
        }
        throw new Error(
          t(
            'This workspace changed while saving. Your edits remain here; review the latest post and try again.',
            'พื้นที่ทำงานถูกแก้ไขระหว่างบันทึก การแก้ไขของคุณยังอยู่ที่นี่ กรุณาตรวจสอบโพสต์ล่าสุดแล้วลองอีกครั้ง',
          ),
        );
      }
      throw new Error(
        error instanceof Error
          ? error.message
          : t(
              'Could not save this post. Your changes remain here; try again.',
              'บันทึกโพสต์ไม่สำเร็จ การแก้ไขของคุณยังอยู่ที่นี่ กรุณาลองอีกครั้ง',
            ),
      );
    }
    editorControl.current?.close();
    notify(t('Post saved to your workspace.', 'บันทึกโพสต์แล้ว'));
  }
  async function trashPost(post: Post): Promise<boolean> {
    if (!data || !data.posts.some((item) => item.id === post.id && !item.deletedAt)) return false;
    const deletedAt = new Date().toISOString();
    const saved = await update({
      ...data,
      posts: data.posts.map((item) => (item.id === post.id ? { ...item, deletedAt } : item)),
    });
    if (!saved) return false;
    notify(
      t(
        'Moved to Trash. You can restore it for 30 days.',
        'ย้ายไปถังขยะแล้ว กู้คืนได้ภายใน 30 วัน',
      ),
    );
    return true;
  }
  function exportCsv(posts?: Post[]) {
    if (data) {
      download(
        exportPostsCsv(posts ? { ...data, posts } : data, storeId === 'all' ? undefined : storeId),
        `vetra-posts-${dateKey(new Date())}.csv`,
      );
      notify(t('Your CSV export is ready.', 'ส่งออก CSV แล้ว'));
    }
  }
  // Defer only filter controls. A saved pin changes workspace data, and should
  // reorder the existing rows directly instead of flashing a loading skeleton.
  const listControls = useMemo(
    () => ({ search, platform, statusFilter, sort, locale, storeId, productId }),
    [search, platform, statusFilter, sort, locale, storeId, productId],
  );
  const deferredListControls = useDeferredValue(listControls);
  const postListPending = listControls !== deferredListControls;
  const filtered = useMemo(() => {
    const { search, platform, statusFilter, sort, locale } = deferredListControls;
    const needle = search.trim().toLowerCase();
    const storeNames = new Map(data?.stores.map((item) => [item.id, item.name]));
    const groupNames = new Map(data?.groups.map((item) => [item.id, item.name]));
    const destinationNames = new Map(data?.destinations?.map((item) => [item.id, item.name]));
    return sortPosts(
      scoped.filter(
        (post) =>
          matchesPostStatusFilter(
            post,
            Boolean(publicPostUrl(post, groupsById.get(post.groupId)?.facebookId ?? '')),
            statusFilter,
          ) &&
          (platform === 'all' || post.platform === platform) &&
          [
            post.product,
            storeNames.get(post.storeId),
            groupNames.get(post.groupId),
            groupsById.get(post.groupId)?.facebookId,
            destinationNames.get(post.destinationId ?? ''),
            destinationsById.get(post.destinationId ?? '')?.externalId,
            post.metaGroupName,
            post.metaGroupKey,
            post.facebookPostId,
            post.url,
          ]
            .join(' ')
            .toLowerCase()
            .includes(needle),
      ),
      sort,
      locale,
      data ?? undefined,
    );
  }, [data, scoped, deferredListControls, groupsById, destinationsById]);
  useLayoutEffect(() => {
    const position = pinScrollPosition.current;
    if (!position) return;
    pinScrollPosition.current = null;
    window.scrollTo({ ...position, behavior: 'instant' });
  }, [data]);
  useLayoutEffect(() => {
    if (view === 'posts' && !postListPending && postListViewport.current)
      postListHeight.current = postListViewport.current.offsetHeight;
  }, [view, postListPending, filtered]);
  useLayoutEffect(() => {
    const saved = postListRestore;
    if (!data || view !== 'posts' || !saved || postListPending) return;
    if (storeId !== 'all' && !data.stores.some((store) => store.id === storeId)) return;
    if (
      productId !== 'all' &&
      !data.products.some((product) => product.id === productId && !product.deletedAt)
    )
      return;
    // Restore only after the final filtered rows replace the loading skeleton.
    setPostListRestore(null);
    if (postListViewport.current) postListViewport.current.scrollLeft = saved.tableScrollLeft;
    window.scrollTo({ left: saved.scrollX, top: saved.scrollY, behavior: 'instant' });
  }, [data, view, storeId, productId, postListRestore, postListPending]);
  const hasLibraryFilters =
    !!search.trim() || platform !== 'all' || productId !== 'all' || statusFilter !== 'normal';
  const canLoadSuppliedPosts =
    view === 'posts' &&
    !hasLibraryFilters &&
    data?.posts.length === 0 &&
    missingSampleCount === providedSamplePosts.length;
  function clearLibraryFilters() {
    setSearch('');
    setPlatform('all');
    setProductId('all');
    setStatusFilter('normal');
  }
  function clearVisiblePostFilters() {
    clearLibraryFilters();
    setStoreId('all');
  }

  function navContent() {
    return (
      <>
        <div className={s.workspaceLabel}>{t('YOUR WORKSPACE', 'พื้นที่ทำงานของคุณ')}</div>
        <nav aria-label={t('Main navigation', 'เมนูหลัก')}>
          {navItems.slice(0, 6).map((item) => (
            <button
              key={item.id}
              className={`${s.navItem} ${view === item.id ? s.navActive : ''}`}
              onClick={() => navigate(item.id)}
              aria-current={view === item.id ? 'page' : undefined}
            >
              <item.icon size={19} />
              <span>{t(item.en, item.th)}</span>
              {item.id === 'posts' && <b>{scoped.length}</b>}
              {view === item.id && <i />}
            </button>
          ))}
        </nav>
        <div className={s.navDivider} />
        <div className={s.workspaceLabel}>{t('MANAGE', 'จัดการ')}</div>
        <nav aria-label={t('Workspace management', 'จัดการพื้นที่ทำงาน')}>
          {navItems.slice(6).map((item) => (
            <button
              key={item.id}
              className={`${s.navItem} ${view === item.id ? s.navActive : ''}`}
              onClick={() => navigate(item.id)}
              aria-current={view === item.id ? 'page' : undefined}
            >
              <item.icon size={19} />
              <span>{t(item.en, item.th)}</span>
            </button>
          ))}
        </nav>
        <div className={s.sidebarBottom}>
          <div className={s.sidebarNote}>
            <span className={s.tinySpark}>✦</span>
            <strong>{t('A space for every brand.', 'พื้นที่ของทุกแบรนด์')}</strong>
            <p>
              {t(
                'Keep every published post and its results in one place.',
                'เก็บโพสต์ที่เผยแพร่แล้วและผลลัพธ์ไว้ในที่เดียว',
              )}
            </p>
            <button onClick={() => navigate('stores')}>
              {t('Manage your stores', 'จัดการร้านค้า')}
              <ArrowUpRight size={17} />
            </button>
          </div>
          <div className={s.profile}>
            <span className={s.avatar}>V</span>
            <div>
              <strong>{t('My workspace', 'พื้นที่ทำงานของฉัน')}</strong>
              <span>
                <i />
                {t('Saved in this browser', 'บันทึกในเบราว์เซอร์นี้')}
              </span>
            </div>
          </div>
        </div>
      </>
    );
  }

  function rememberPostList() {
    if (view !== 'posts') return;
    try {
      window.history.replaceState(
        withPostListReturnState(window.history.state, {
          storeId,
          productId,
          search,
          platform,
          statusFilter,
          sort,
          scrollX: window.scrollX,
          scrollY: window.scrollY,
          tableScrollLeft: postListViewport.current?.scrollLeft ?? 0,
        }),
        '',
      );
      window.history.scrollRestoration = 'manual';
    } catch {
      // Browser history restrictions must not stop the user from opening a post.
    }
  }

  function resetClickCounts() {
    try {
      setPostClicks(resetDailyPostClicks(window.localStorage));
      setClickTrackingError(false);
      notify(
        t(
          'Today’s click counts reset for all posts in this browser.',
          'รีเซ็ตจำนวนคลิกวันนี้ของทุกโพสต์ในเบราว์เซอร์นี้แล้ว',
        ),
      );
    } catch {
      notify(
        t(
          'Could not reset click counts. Your saved counts have not changed.',
          'รีเซ็ตจำนวนคลิกไม่สำเร็จ จำนวนคลิกที่บันทึกไว้ยังคงเดิม',
        ),
      );
    }
  }

  function trackPostOpen(postId: string) {
    try {
      setPostClicks(recordPostClick(window.localStorage, postId));
      setClickTrackingError(false);
    } catch {
      setClickTrackingError(true);
      notify(
        t(
          'The post opened, but today’s click could not be saved in this browser.',
          'เปิดโพสต์แล้ว แต่บันทึกจำนวนคลิกวันนี้ในเบราว์เซอร์ไม่สำเร็จ',
        ),
      );
    }
  }

  function postTable(posts: Post[]) {
    const rateNow = new Date();
    const clicksTodayByPost = postClicks.day === bangkokToday() ? postClicks.counts : null;
    const onlyHiddenStatuses =
      view === 'posts' &&
      statusFilter === 'normal' &&
      !search.trim() &&
      platform === 'all' &&
      scoped.length > 0 &&
      posts.length === 0;
    const emptyBecauseFiltered =
      onlyHiddenStatuses || (view === 'posts' && (hasLibraryFilters || storeId !== 'all'));
    return posts.length ? (
      <div className={s.tableScroll} ref={view === 'posts' ? postListViewport : undefined}>
        <table className={s.table}>
          <PostTableHead t={t} />
          <tbody>
            {posts.map((p) => {
              const st = storesById.get(p.storeId),
                group = groupsById.get(p.groupId),
                destination = destinationsById.get(p.destinationId ?? ''),
                url = publicPostUrl(p, group?.facebookId ?? '');
              const clicksToday = clicksTodayByPost?.[p.id] ?? 0;
              const productName = p.product.trim();
              const product = p.productId
                ? productsById.get(p.productId)
                : uniqueProductsByName.get(productName);
              const destinationName =
                destination?.name ||
                (p.platform === 'facebook' && group?.name) ||
                p.metaGroupName ||
                (p.platform === 'facebook' && p.metaSourceRow && !p.metaGroupKey
                  ? t('Facebook Page', 'เพจ Facebook')
                  : '') ||
                {
                  facebook: 'Facebook',
                  instagram: 'Instagram',
                  tiktok: 'TikTok',
                  linkedin: 'LinkedIn',
                }[p.platform];
              const postIdentity = p.facebookPostId
                ? `${t('post ID', 'รหัสโพสต์')} ${p.facebookPostId}`
                : p.metaSourceRow
                  ? t(`Meta row ${p.metaSourceRow}`, `แถว Meta ${p.metaSourceRow}`)
                  : `${t('record ID', 'รหัสรายการ')} ${p.id}`;
              const pending = postPublicationStatus(p) === 'pending';
              const postAccessibleName = `${product?.name || productName || 'Null'} — ${destinationName} — ${pending ? t('Pending', 'รอดำเนินการ') : t('Published', 'เผยแพร่แล้ว')} — ${postIdentity}`;
              const clickCountLabel = clickTrackingError
                ? t('Today’s click count unavailable', 'ไม่สามารถแสดงจำนวนคลิกวันนี้ได้')
                : t(`${fmt(clicksToday)} clicks today`, `คลิกวันนี้ ${fmt(clicksToday)} ครั้ง`);
              const viewersPerDay = pending ? null : averageViewersPerDay(p, rateNow);
              const titleContents = (
                <>
                  <PostProductThumbnail url={product?.imageUrl ?? ''} />
                  <span className={s.postTitleCopy}>
                    <span className={s.postTitleHeading}>
                      <strong>{product?.name || productName || 'Null'}</strong>
                    </span>
                    <span className={s.postMeta}>
                      <small>{st?.name || 'Null'}</small>
                      {p.metaSourceRow && !url && (
                        <small className={s.sourceRow}>
                          {t(`Meta row ${p.metaSourceRow}`, `แถว Meta ${p.metaSourceRow}`)}
                        </small>
                      )}
                      {pending && (
                        <span className={s.pendingPostBadge}>
                          <Clock3 size={14} aria-hidden="true" />
                          {t('Pending', 'รอดำเนินการ')}
                        </span>
                      )}
                      {view === 'posts' &&
                        (url ? (
                          <span
                            className={s.todayClicks}
                            data-click-level={
                              clickTrackingError ? 'unavailable' : Math.min(clicksToday, 7)
                            }
                            title={clickCountLabel}
                          >
                            <MousePointerClick size={13} aria-hidden="true" />
                            <span aria-hidden="true">
                              {clickTrackingError ? '—' : fmt(clicksToday)}
                            </span>
                            <span className={s.srOnly}>{clickCountLabel}</span>
                          </span>
                        ) : (
                          <span className={s.missingLink}>{t('Link: Null', 'ลิงก์: Null')}</span>
                        ))}
                    </span>
                  </span>
                </>
              );
              return (
                <tr
                  key={p.id}
                  className={`${view === 'posts' && url ? s.clickablePostRow : ''} ${p.pinned ? s.pinnedPostRow : ''} ${pending ? s.pendingPostRow : ''}`}
                  onPointerEnter={(event) => {
                    if (view === 'posts' && url && event.pointerType !== 'touch')
                      warmPostConnection(url);
                  }}
                  onClick={(event) => {
                    if (view !== 'posts' || !url || event.defaultPrevented || event.button !== 0)
                      return;
                    if (
                      event.target instanceof Element &&
                      event.target.closest(`a, button, .${s.rowActions}`)
                    )
                      return;
                    if (window.getSelection()?.toString()) return;
                    window.open(url, '_blank', 'noopener,noreferrer');
                    trackPostOpen(p.id);
                  }}
                >
                  <td data-label={t('Post', 'โพสต์')}>
                    <div className={s.postCellContent}>
                      <button
                        className={`${s.iconButton} ${s.pinButton} ${p.pinned ? s.pinActive : ''}`}
                        type="button"
                        onClick={(event) => {
                          // Pointer focus can pull the viewport to a row after it moves.
                          // Keep keyboard focus for people using Tab/Enter/Space.
                          if (event.detail > 0) event.currentTarget.blur();
                          void togglePostPin(p);
                        }}
                        disabled={pinSavingId !== null || Boolean(storageError)}
                        aria-busy={pinSavingId === p.id}
                        aria-pressed={p.pinned === true}
                        aria-label={`${p.pinned ? t('Unpin post', 'เลิกปักหมุดโพสต์') : t('Pin post', 'ปักหมุดโพสต์')} ${postAccessibleName}`}
                        title={
                          p.pinned
                            ? t('Unpin post', 'เลิกปักหมุดโพสต์')
                            : t('Pin post to top', 'ปักหมุดโพสต์ไว้ด้านบน')
                        }
                      >
                        <Pin
                          size={20}
                          strokeWidth={2.2}
                          fill={p.pinned ? 'currentColor' : 'none'}
                          aria-hidden="true"
                        />
                      </button>
                      {url ? (
                        <a
                          className={s.postTitle}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          title={t(
                            'Open published post in a new tab',
                            'เปิดโพสต์ที่เผยแพร่แล้วในแท็บใหม่',
                          )}
                          aria-label={`${t('Open post', 'เปิดโพสต์')} ${postAccessibleName} — ${clickCountLabel}`}
                          onPointerEnter={(event) => {
                            if (event.pointerType !== 'touch') warmPostConnection(url);
                          }}
                          onFocus={() => warmPostConnection(url)}
                          onClick={() => trackPostOpen(p.id)}
                          onAuxClick={(event) => {
                            if (event.button === 1) trackPostOpen(p.id);
                          }}
                        >
                          {titleContents}
                        </a>
                      ) : (
                        <button
                          className={s.postTitle}
                          title={t(
                            'Edit this post to add its link',
                            'แก้ไขโพสต์นี้เพื่อเพิ่มลิงก์',
                          )}
                          onClick={() => editorControl.current?.open(p)}
                        >
                          {titleContents}
                        </button>
                      )}
                    </div>
                  </td>
                  <td data-label={t('Destination', 'ปลายทาง')}>
                    <div className={s.destination}>
                      <PlatformBadge platform={p.platform} />
                      <span>{destinationName}</span>
                    </div>
                  </td>
                  <td data-label={t('Viewers', 'ผู้ชม')}>
                    <span className={s.viewerNumber}>
                      {p.viewers === null ? 'Null' : fmt(p.viewers)}
                    </span>
                    {pending && p.viewers !== null && (
                      <small className={s.pendingMetricNote}>
                        {p.metaSourceRow
                          ? t('Meta · pending', 'Meta · รอดำเนินการ')
                          : t('Pending · excluded', 'รอดำเนินการ · ไม่นับรวม')}
                      </small>
                    )}
                  </td>
                  <td data-label={t('Viewer/day', 'ผู้ชม/วัน')}>
                    <span className={s.viewerNumber}>
                      {viewersPerDay === null ? 'Null' : rateFormatter.format(viewersPerDay)}
                    </span>
                  </td>
                  <td className={s.dateCell} data-label={t('Published', 'เผยแพร่เมื่อ')}>
                    {p.publishedAt ? formatDate(p.publishedAt) : 'Null'}
                    {!p.publishedAt && p.metaPublishedLabel && (
                      <small
                        className={s.metaDateHint}
                        title={t(
                          'Date as shown by Meta; year unknown',
                          'วันที่ตามที่ Meta แสดง โดยไม่ทราบปี',
                        )}
                      >
                        {t('Meta:', 'Meta:')} {p.metaPublishedLabel}
                      </small>
                    )}
                  </td>
                  <td>
                    <div className={s.rowActions}>
                      <button
                        className={s.iconButton}
                        onClick={() => editorControl.current?.open(p)}
                        aria-label={`${t('Edit', 'แก้ไข')} ${postAccessibleName}`}
                      >
                        <Pencil size={17} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    ) : (
      <div className={s.empty}>
        <FileText size={30} />
        <h3>
          {onlyHiddenStatuses
            ? t('No normal posts yet', 'ยังไม่มีโพสต์ปกติ')
            : emptyBecauseFiltered || productId !== 'all'
              ? t('No matching posts', 'ไม่พบโพสต์ที่ตรงกัน')
              : canLoadSuppliedPosts
                ? t('Your 26 supplied posts are ready', 'โพสต์ที่คุณให้มา 26 รายการพร้อมเพิ่ม')
                : t('Track your first post', 'ติดตามโพสต์รายการแรก')}
        </h3>
        <p>
          {onlyHiddenStatuses
            ? t(
                'Your posts are in Pending or No link. Choose another status to see them.',
                'โพสต์ของคุณอยู่ในสถานะรอดำเนินการหรือไม่มีลิงก์ เลือกสถานะอื่นเพื่อดู',
              )
            : emptyBecauseFiltered || productId !== 'all'
              ? t('Try another keyword or clear your filters.', 'ลองคำค้นอื่นหรือล้างตัวกรอง')
              : canLoadSuppliedPosts
                ? t(
                    'This browser has no posts yet. Add the supplied posts with their latest Viewers totals.',
                    'เบราว์เซอร์นี้ยังไม่มีโพสต์ เพิ่มโพสต์ที่คุณให้มาพร้อมยอดผู้ชมล่าสุด',
                  )
                : t(
                    'Add a link to a post that is already live, or import existing records.',
                    'เพิ่มลิงก์โพสต์ที่เผยแพร่แล้ว หรือนำเข้ารายการเดิม',
                  )}
        </p>
        <button
          className={s.primary}
          disabled={canLoadSuppliedPosts && (sampleImporting || Boolean(storageError))}
          onClick={() =>
            onlyHiddenStatuses
              ? setStatusFilter('all')
              : emptyBecauseFiltered || productId !== 'all'
                ? clearVisiblePostFilters()
                : canLoadSuppliedPosts
                  ? void importProvidedSamples()
                  : newPost()
          }
        >
          {onlyHiddenStatuses
            ? t('Show all posts', 'แสดงโพสต์ทั้งหมด')
            : emptyBecauseFiltered || productId !== 'all'
              ? t('Clear filters', 'ล้างตัวกรอง')
              : canLoadSuppliedPosts
                ? sampleImporting
                  ? t('Adding…', 'กำลังเพิ่ม…')
                  : t('Add 26 supplied posts', 'เพิ่มโพสต์ที่ให้มา 26 รายการ')
                : t('Add post', 'เพิ่มโพสต์')}
        </button>
      </div>
    );
  }

  function stats() {
    return (
      <div className={s.stats}>
        <Stat
          title={t('Published posts', 'โพสต์ที่เผยแพร่')}
          value={fmt(published.length)}
          note={t(
            `${published.filter((p) => p.viewers !== null).length} with Viewers totals`,
            `${published.filter((p) => p.viewers !== null).length} โพสต์ที่มียอดผู้ชม`,
          )}
          icon={<FileText size={19} />}
          color="blue"
        />
        <Stat
          title={t('Post viewers', 'ผู้ชมของแต่ละโพสต์')}
          value={published.some((post) => post.viewers !== null) ? short(total) : '—'}
          note={t('Sum of current totals across posts', 'ผลรวมยอดล่าสุดของทุกโพสต์')}
          icon={<Users size={19} />}
          color="purple"
        />
        <Stat
          title={t('Active groups', 'กลุ่มที่ใช้งาน')}
          value={fmt(groups.length)}
          note={t(
            `${data!.stores.length} stores, one workspace`,
            `${data!.stores.length} ร้านค้า ในพื้นที่เดียว`,
          )}
          icon={<Globe2 size={19} />}
          color="orange"
        />
      </div>
    );
  }
  if (!data && view === 'posts')
    return (
      <div className={s.app}>
        <header className={s.topbar}>
          <span className={s.loadingBrand}>
            <Mark /> VETRA Marketing
          </span>
        </header>
        <main className={s.main}>
          <div className={s.workspaceBar} aria-hidden="true">
            <span className={`${s.skeletonBlock} ${s.loadingWorkspacePill}`} />
          </div>
          <section className={s.panel}>
            <div className={s.postTools}>
              <h1>{t('Tracked posts', 'โพสต์ที่ติดตาม')} · …</h1>
              <div className={s.loadingActions} aria-hidden="true">
                <span className={`${s.skeletonBlock} ${s.loadingAction}`} />
                <span className={`${s.skeletonBlock} ${s.loadingAction}`} />
              </div>
            </div>
            <div className={s.filterBar} aria-hidden="true">
              <span className={`${s.skeletonBlock} ${s.loadingSearch}`} />
              <span className={`${s.skeletonBlock} ${s.loadingFilter}`} />
            </div>
            <PostListSkeleton t={t} />
            <div className={s.tableFooter}>{t('Loading posts…', 'กำลังโหลดโพสต์…')}</div>
          </section>
        </main>
      </div>
    );
  if (!data)
    return (
      <div className={s.loading}>
        <Mark />
        <strong>VETRA Marketing</strong>
        <span>{t('Opening your workspace…', 'กำลังเปิดพื้นที่ทำงาน…')}</span>
      </div>
    );
  const selectedStoreName =
    storeId === 'all'
      ? t('All', 'ทั้งหมด')
      : displayStoreName(
          data.stores.find((store) => store.id === storeId)?.name || t('All', 'ทั้งหมด'),
        );
  const selectedProductName =
    productId === 'all'
      ? t('All products', 'ทุกสินค้า')
      : data.products.find((product) => product.id === productId && !product.deletedAt)?.name ||
        t('All products', 'ทุกสินค้า');
  const heading: { [key in View]: [string, string, string, string] } = {
    overview: [
      'Your marketing, in focus.',
      'มองการตลาดได้ชัดขึ้น',
      'Every store. Every story. One clear picture.',
      'ทุกร้าน ทุกเรื่องราว เห็นภาพรวมในที่เดียว',
    ],
    posts: [
      'Every published post, in one place.',
      'รวมโพสต์ที่เผยแพร่แล้วไว้ในที่เดียว',
      'Open a live post, or use Edit to update its current Viewers total.',
      'เปิดโพสต์ที่เผยแพร่แล้ว หรือกดแก้ไขเพื่ออัปเดตยอดผู้ชมล่าสุด',
    ],
    groups: [
      'Find your people.',
      'เข้าถึงกลุ่มคนที่ใช่',
      'Keep your communities and posting notes together.',
      'รวมกลุ่มเป้าหมายและบันทึกการโพสต์ไว้ด้วยกัน',
    ],
    analytics: [
      'Your posts, at a glance.',
      'ดูผลลัพธ์ของโพสต์ได้ทันที',
      'Compare current Viewers totals across published posts.',
      'เปรียบเทียบยอดผู้ชมล่าสุดของโพสต์ที่เผยแพร่แล้ว',
    ],
    products: [
      'Your product catalog.',
      'จัดการสินค้าของคุณ',
      'Keep product names, images, and display order together.',
      'รวมชื่อสินค้า รูปภาพ และลำดับการแสดงผลไว้ด้วยกัน',
    ],
    stores: [
      'Different brands. One place.',
      'หลายแบรนด์ ในพื้นที่เดียว',
      'Give every store a space of its own.',
      'ให้ทุกร้านมีพื้นที่ของตัวเอง',
    ],
    settings: [
      'Make yourself at home.',
      'จัดพื้นที่ให้เป็นแบบคุณ',
      'Your workspace, data, and preferences.',
      'จัดการพื้นที่ทำงาน ข้อมูล และการตั้งค่า',
    ],
    trash: [
      'Room to change your mind.',
      'เปลี่ยนใจได้เสมอ',
      'Deleted items can be restored for 30 days.',
      'รายการที่ลบสามารถกู้คืนได้ภายใน 30 วัน',
    ],
  };
  return (
    <div className={s.app}>
      <title>
        {t('VETRA Marketing — Your marketing, in focus', 'VETRA Marketing — พื้นที่ทำงานการตลาด')}
      </title>
      <a className="skip-link" href="#main">
        {t('Skip to content', 'ข้ามไปยังเนื้อหา')}
      </a>
      <dialog
        id="workspace-navigation"
        ref={navDialog}
        className={s.navDialog}
        aria-label={t('Navigation', 'เมนูนำทาง')}
        onCancel={(event) => {
          event.preventDefault();
          closeNavigation();
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget) closeNavigation();
        }}
      >
        <div className={s.mobileNav}>
          <button
            className={s.closeNav}
            onClick={closeNavigation}
            aria-label={t('Close navigation', 'ปิดเมนู')}
          >
            <X size={22} />
          </button>
          {navContent()}
        </div>
      </dialog>
      <div className={s.mainShell}>
        <header className={s.topbar}>
          <div className={s.topLeft}>
            <button
              ref={menuButton}
              className={`${s.iconButton} ${s.menuButton}`}
              aria-label={t('Open navigation', 'เปิดเมนู')}
              aria-controls="workspace-navigation"
              aria-expanded={false}
              onClick={openNavigation}
            >
              <Menu size={22} />
            </button>
            <span className={s.headerBrand} aria-hidden="true">
              <Mark /> VETRA<span>.</span>
            </span>
            <span className={s.breadcrumb}>
              {t('Workspace', 'พื้นที่ทำงาน')}
              <ChevronRight size={14} />
              <strong>
                {t(
                  navItems.find((n) => n.id === view)!.en,
                  navItems.find((n) => n.id === view)!.th,
                )}
              </strong>
            </span>
          </div>
          <div className={s.topRight}>
            <QuickSearchControl
              ref={quickSearchControl}
              data={data}
              locale={locale}
              t={t}
              className={s.topSearch}
              onNavigate={navigate}
              onOpenPost={(post) => {
                setStoreId(post.storeId);
                setProductId('all');
                navigate('posts');
                editorControl.current?.open(post);
              }}
              onSelectStore={(id) => {
                setStoreId(id);
                setProductId('all');
                navigate('posts');
              }}
              onCreatePost={newPost}
            />
            <div className={s.language}>
              <button
                type="button"
                className={s.languageSwitch}
                aria-label={
                  locale === 'th' ? 'ภาษาไทย · เปลี่ยนเป็นภาษาอังกฤษ' : 'English · Switch to Thai'
                }
                title={locale === 'th' ? 'เปลี่ยนเป็นภาษาอังกฤษ' : 'Switch to Thai'}
                onClick={() => changeLocale(locale === 'th' ? 'en' : 'th')}
              >
                {locale === 'th' ? 'TH' : 'EN'}
              </button>
            </div>
            <span className={s.topAvatar}>V</span>
          </div>
        </header>
        <main id="main" className={s.main} tabIndex={-1}>
          <div className={s.workspaceBar}>
            {!['stores', 'settings'].includes(view) && (
              <div className={s.workspaceFilters}>
                <SelectionControl
                  title={t('Select store', 'เลือกร้านค้า')}
                  options={[
                    { value: 'all', en: 'All', th: 'ทั้งหมด' },
                    ...sortCatalog(data.stores).map((store) => ({
                      value: store.id,
                      en: displayStoreName(store.name),
                      th: displayStoreName(store.name),
                    })),
                  ]}
                  value={storeId}
                  t={t}
                  onSelect={(id) => {
                    setStoreId(id);
                    setProductId('all');
                  }}
                  trigger={(open, openDialog) => (
                    <button
                      type="button"
                      className={s.storeSelect}
                      aria-haspopup="dialog"
                      aria-expanded={open}
                      aria-label={`${t('Select store', 'เลือกร้านค้า')}: ${selectedStoreName}`}
                      onClick={openDialog}
                    >
                      <span className={s.storeSelectIcon}>
                        <StoreIcon size={17} aria-hidden="true" />
                      </span>
                      <span className={s.storeSelectName} title={selectedStoreName}>
                        {selectedStoreName}
                      </span>
                      <ChevronDown size={15} aria-hidden="true" />
                    </button>
                  )}
                />
                {['overview', 'posts', 'analytics'].includes(view) && (
                  <SelectionControl
                    title={t('Select product', 'เลือกสินค้า')}
                    options={[
                      { value: 'all', en: 'All products', th: 'ทุกสินค้า' },
                      ...sortCatalog(
                        data.products.filter(
                          (product) =>
                            !product.deletedAt &&
                            (storeId === 'all' ||
                              productStoresById.get(product.id)?.includes(storeId)),
                        ),
                      ).map((product) => ({
                        value: product.id,
                        en: product.name,
                        th: product.name,
                      })),
                    ]}
                    value={productId}
                    t={t}
                    onSelect={setProductId}
                    trigger={(open, openDialog) => (
                      <button
                        type="button"
                        className={s.storeSelect}
                        aria-haspopup="dialog"
                        aria-expanded={open}
                        aria-label={`${t('Select product', 'เลือกสินค้า')}: ${selectedProductName}`}
                        onClick={openDialog}
                      >
                        <span className={s.storeSelectIcon}>
                          <Package size={17} aria-hidden="true" />
                        </span>
                        <span className={s.storeSelectName} title={selectedProductName}>
                          {selectedProductName}
                        </span>
                        <ChevronDown size={15} aria-hidden="true" />
                      </button>
                    )}
                  />
                )}
              </div>
            )}
            <div className={s.workspaceMeta}>
              {data.sample && (
                <span className={s.sampleTag}>
                  <span />
                  {t('Sample workspace', 'พื้นที่ทำงานตัวอย่าง')}
                </span>
              )}
              <span className={s.currentDate}>
                <CalendarDays size={15} />
                {formatDate(new Date().toISOString(), true)}
              </span>
            </div>
          </div>
          {storageError && (
            <div role="alert" className={s.errorBanner}>
              {storageError}
              <button
                onClick={() => {
                  try {
                    const raw = repository.current?.readPreservedRaw();
                    if (raw) download(raw, 'vetra-preserved-workspace.json', 'application/json');
                  } catch {
                    notify(
                      t('Browser storage is unavailable.', 'ไม่สามารถเข้าถึงพื้นที่จัดเก็บได้'),
                    );
                  }
                }}
              >
                {t('Download preserved data', 'ดาวน์โหลดข้อมูลเดิม')}
              </button>
              <button onClick={() => navigate('settings')}>
                {t('Open settings', 'เปิดการตั้งค่า')}
              </button>
            </div>
          )}
          <div className={`${s.pageHeading} ${view === 'posts' ? s.pageHeadingActionsOnly : ''}`}>
            {view !== 'posts' && (
              <div>
                <span className={s.eyebrow}>
                  {view === 'overview'
                    ? t('A LITTLE MORE CLARITY', 'เห็นภาพชัดขึ้นอีกนิด')
                    : (!['products', 'stores', 'settings'].includes(view) &&
                        chosenStore?.name.toUpperCase()) ||
                      t('YOUR MARKETING WORKSPACE', 'พื้นที่ทำงานการตลาดของคุณ')}
                </span>
                <h1>{t(heading[view][0], heading[view][1])}</h1>
                <p>{t(heading[view][2], heading[view][3])}</p>
              </div>
            )}
            {['overview', 'posts', 'analytics'].includes(view) && (
              <div className={s.headingActions}>
                <ImportControl
                  data={data}
                  revision={revision}
                  storeId={storeId}
                  t={t}
                  className={s.secondary}
                  onImport={applyCsvImport}
                />
                <button className={s.primary} onClick={() => newPost()}>
                  <Plus size={19} />
                  {t('Add post', 'เพิ่มโพสต์')}
                </button>
              </div>
            )}
          </div>
          {view === 'overview' && (
            <>
              {stats()}
              <section className={s.panel}>
                <div className={s.panelHead}>
                  <div>
                    <h2>{t('Pinned & recently published', 'โพสต์ที่ปักหมุดและเผยแพร่ล่าสุด')}</h2>
                    <p>
                      {t(
                        'Use Edit to update a post’s details or Viewers.',
                        'กดแก้ไขเพื่ออัปเดตข้อมูลโพสต์หรือยอดผู้ชม',
                      )}
                    </p>
                  </div>
                  <button className={s.textButton} onClick={() => navigate('posts')}>
                    {t('View all posts', 'ดูโพสต์ทั้งหมด')}
                    <ArrowRight size={16} />
                  </button>
                </div>
                {postTable(sortPosts(published, 'recent', locale).slice(0, 5))}
              </section>
              <div className={s.bottomNote}>
                <ShieldCheck size={16} />
                {t(
                  'Your workspace stays in this browser. Export a backup to keep it safe.',
                  'ข้อมูลเก็บอยู่ในเบราว์เซอร์นี้ ส่งออกไฟล์สำรองเพื่อเก็บรักษาข้อมูล',
                )}
                <button onClick={() => navigate('settings')}>
                  {t('Manage data', 'จัดการข้อมูล')}
                  <ArrowUpRight size={14} />
                </button>
              </div>
            </>
          )}
          {view === 'posts' && (
            <section className={s.panel}>
              <div className={s.postTools}>
                <h1>
                  {t('Tracked posts', 'โพสต์ที่ติดตาม')} ·{' '}
                  {postListPending ? '…' : fmt(filtered.length)}
                </h1>
                <div className={s.libraryActions}>
                  <button
                    className={s.textButton}
                    onClick={resetClickCounts}
                    disabled={
                      !clickTrackingError &&
                      (postClicks.day !== bangkokToday() ||
                        !Object.values(postClicks.counts).some((count) => count > 0))
                    }
                    title={t(
                      'Reset today’s clicks for all posts in this browser, including filtered-out posts.',
                      'รีเซ็ตจำนวนคลิกวันนี้ของทุกโพสต์ในเบราว์เซอร์นี้ รวมโพสต์ที่ตัวกรองซ่อนอยู่',
                    )}
                  >
                    <RotateCcw size={16} />
                    {t('Reset clicks', 'รีเซ็ตคลิก')}
                  </button>
                  {missingSampleCount > 0 && !canLoadSuppliedPosts && (
                    <button
                      className={s.textButton}
                      onClick={importProvidedSamples}
                      disabled={sampleImporting || latestReadingsImporting || Boolean(storageError)}
                    >
                      <Upload size={16} />
                      {sampleImporting
                        ? t('Adding…', 'กำลังเพิ่ม…')
                        : t(
                            `Add ${missingSampleCount} supplied posts`,
                            `เพิ่มโพสต์ที่ให้มา ${missingSampleCount} รายการ`,
                          )}
                    </button>
                  )}
                  {pendingLatestReadings > 0 && (
                    <button
                      className={s.textButton}
                      onClick={importProvidedLatestReadings}
                      disabled={sampleImporting || latestReadingsImporting || Boolean(storageError)}
                    >
                      <TrendingUp size={16} />
                      {latestReadingsImporting
                        ? t('Saving…', 'กำลังบันทึก…')
                        : t(
                            `Update ${pendingLatestReadings} Viewers totals`,
                            `อัปเดตยอดผู้ชม ${pendingLatestReadings} รายการ`,
                          )}
                    </button>
                  )}
                  <MetaUpdateControl
                    data={data}
                    revision={revision}
                    t={t}
                    className={s.textButton}
                    disabled={Boolean(storageError)}
                    onApply={applyMetaUpdates}
                  />
                  <button
                    className={s.textButton}
                    onClick={() => exportCsv(filtered)}
                    disabled={postListPending || !filtered.length}
                  >
                    <ArrowDownToLine size={16} />
                    {t('Export CSV', 'ส่งออก CSV')}
                  </button>
                </div>
              </div>
              {clickTrackingError && (
                <p className={s.clickTrackingNote} role="status">
                  {t(
                    'Today’s click counts are unavailable in this browser. Posts still open normally; saved click data has not been changed.',
                    'จำนวนคลิกวันนี้ไม่พร้อมใช้งานในเบราว์เซอร์นี้ แต่ยังเปิดโพสต์ได้ตามปกติ และข้อมูลคลิกเดิมไม่ได้ถูกเปลี่ยน',
                  )}
                </p>
              )}
              <div className={s.filterBar}>
                <label className={s.searchField}>
                  <Search size={18} />
                  <input
                    placeholder={t(
                      'Search products, stores, groups, or IDs…',
                      'ค้นหาสินค้า ร้านค้า กลุ่ม หรือรหัส…',
                    )}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    aria-label={t('Filter posts', 'กรองโพสต์')}
                  />
                </label>
                <div className={s.filterControls}>
                  <PostStatusDialog
                    value={statusFilter}
                    t={t}
                    onSelect={setStatusFilter}
                    trigger={(open, openDialog) => (
                      <button
                        type="button"
                        className={s.statusFilter}
                        data-status={statusFilter}
                        aria-haspopup="dialog"
                        aria-expanded={open}
                        aria-label={t('Filter post status', 'กรองสถานะโพสต์')}
                        onClick={openDialog}
                      >
                        <ListFilter size={16} aria-hidden="true" />
                        <span>
                          {postStatusOptions.map((option) =>
                            option.value === statusFilter ? t(option.en, option.th) : null,
                          )}
                        </span>
                        <ChevronDown size={16} aria-hidden="true" />
                      </button>
                    )}
                  />
                  <PostPlatformDialog
                    value={platform}
                    t={t}
                    onSelect={setPlatform}
                    trigger={(open, openDialog) => (
                      <button
                        type="button"
                        className={s.platformFilter}
                        aria-haspopup="dialog"
                        aria-expanded={open}
                        aria-label={t('Filter platform', 'กรองแพลตฟอร์ม')}
                        onClick={openDialog}
                      >
                        <SlidersHorizontal size={16} aria-hidden="true" />
                        <span>
                          {postPlatformOptions.map((option) =>
                            option.value === platform ? t(option.en, option.th) : null,
                          )}
                        </span>
                        <ChevronDown size={16} aria-hidden="true" />
                      </button>
                    )}
                  />
                  <PostSortDialog
                    value={sort}
                    t={t}
                    onSelect={setSort}
                    trigger={(open, openDialog) => (
                      <button
                        type="button"
                        className={s.sortField}
                        aria-haspopup="dialog"
                        aria-expanded={open}
                        aria-label={t('Sort posts', 'เรียงลำดับโพสต์')}
                        onClick={openDialog}
                      >
                        <span>{t('Sort', 'เรียง')}</span>
                        <span>
                          {postSortOptions.map((option) =>
                            option.value === sort ? t(option.en, option.th) : null,
                          )}
                        </span>
                        <ChevronDown size={16} aria-hidden="true" />
                      </button>
                    )}
                  />
                </div>
              </div>
              <div
                style={
                  postListPending && postListHeight.current
                    ? { minHeight: postListHeight.current }
                    : undefined
                }
              >
                {postListPending ? <PostListSkeleton t={t} /> : postTable(filtered)}
              </div>
              <div className={s.tableFooter}>
                {postListPending
                  ? t('Loading posts…', 'กำลังโหลดโพสต์…')
                  : t(
                      `${filtered.length} ${filtered.length === 1 ? 'post' : 'posts'} in this view`,
                      `${filtered.length} โพสต์ในมุมมองนี้`,
                    )}
                <span>
                  {t(
                    'Daily clicks reset at midnight ICT · Saved in this browser',
                    'จำนวนคลิกรีเซ็ตเที่ยงคืนเวลาไทย · บันทึกในเบราว์เซอร์นี้',
                  )}
                </span>
              </div>
            </section>
          )}
          {view === 'analytics' && (
            <>
              {stats()}
              <section className={s.panel}>
                <div className={s.panelHead}>
                  <div>
                    <h2>{t('Stories that connect', 'โพสต์ที่เข้าถึงผู้คน')}</h2>
                    <p>
                      {t(
                        'Pinned posts first, then ranked by current Viewers total. Edit a post to replace its total.',
                        'โพสต์ที่ปักหมุดอยู่ด้านบน จากนั้นเรียงตามยอดผู้ชมล่าสุด กดแก้ไขโพสต์เพื่อเปลี่ยนยอด',
                      )}
                    </p>
                  </div>
                  <button className={s.textButton} onClick={() => exportCsv(published)}>
                    <ArrowDownToLine size={16} />
                    {t('Export', 'ส่งออก')}
                  </button>
                </div>
                {postTable(sortPosts(published, 'viewers', locale, data ?? undefined))}
              </section>
              <div className={s.metricNote}>
                <TrendingUp size={20} />
                <p>
                  <strong>
                    {t('A clearer picture of your numbers.', 'เข้าใจตัวเลขของคุณให้ชัดขึ้น')}
                  </strong>
                  {t(
                    'Each post keeps only its current Viewers total. Totals across posts may include the same people more than once.',
                    'แต่ละโพสต์เก็บเฉพาะยอดผู้ชมล่าสุด ผลรวมหลายโพสต์อาจนับคนเดิมซ้ำกัน',
                  )}
                </p>
              </div>
            </>
          )}
          {view === 'groups' && (
            <GroupsPanel data={data} storeId={storeId} update={update} t={t} notify={notify} />
          )}
          {(view === 'stores' || view === 'products') && (
            <CatalogPanel
              key={view}
              kind={view}
              data={data}
              storeId={storeId}
              update={update}
              t={t}
              notify={notify}
            />
          )}
          {view === 'settings' && (
            <SettingsPanel
              data={data}
              revision={revision}
              storeId={storeId}
              repository={repository.current!}
              update={async (next) => {
                const saved = await update(next, true);
                if (saved) setStoreId('all');
                return saved;
              }}
              t={t}
              notify={notify}
            />
          )}
          {view === 'trash' && (
            <TrashPanel data={data} storeId={storeId} update={update} t={t} notify={notify} />
          )}
          <footer className={s.footer}>
            <span>
              VETRA <span>MARKETING</span>
            </span>
            <p>
              {t(
                'A little more organized. A lot more possibility.',
                'จัดการได้ดีขึ้น เปิดโอกาสได้มากขึ้น',
              )}
            </p>
          </footer>
        </main>
      </div>
      <BackToTop t={t} />
      <PostEditorControl
        ref={editorControl}
        data={data}
        storeId={storeId}
        t={t}
        onSave={savePost}
        onDelete={trashPost}
      />
      <ToastControl ref={toastControl} t={t} />
    </div>
  );
}
function PostProductThumbnail({ url }: { url: string }) {
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  return (
    <span className={s.thumbnail} aria-hidden="true">
      {url && safeCatalogImageUrl(url) && failedUrl !== url ? (
        <img
          src={url}
          alt=""
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailedUrl(url)}
        />
      ) : (
        <Package size={22} />
      )}
    </span>
  );
}

function Stat({
  title,
  value,
  note,
  icon,
  color,
}: {
  title: string;
  value: string;
  note: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <section className={s.stat}>
      <div className={s.statLabel}>
        {title}
        <span className={`${s.statIcon} ${s[color]}`}>{icon}</span>
      </div>
      <strong className={s.statValue}>{value}</strong>
      <p>{note}</p>
      <span className={`${s.statAccent} ${s[color]}`} />
    </section>
  );
}
