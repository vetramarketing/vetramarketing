'use client';

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
} from 'react';
import {
  ArchiveRestore,
  ArrowDownToLine,
  ArrowUpFromLine,
  Check,
  ChevronRight,
  CircleHelp,
  ExternalLink,
  FileJson,
  FolderOpen,
  Globe2,
  Layers3,
  LockKeyhole,
  Package,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  UsersRound,
  X,
} from 'lucide-react';
import { createEmptyWorkspace } from '@/lib/data';
import { sortCatalog } from '@/lib/catalog';
import { entityEditIsCurrent } from '@/lib/entity-edit';
import { knownFacebookGroupName } from '@/lib/facebook-group-directory';
import { productStoreIdMap } from '@/lib/product-store';
import type { WorkspaceRepository } from '@/lib/workspace-repository';
import { deserializeWorkspace, serializeWorkspace } from '@/lib/workspace-storage';
import type { Group, Translate, Workspace } from '@/lib/types';
import styles from './WorkspacePanels.module.css';

interface PanelProps {
  data: Workspace;
  storeId: string;
  update: (next: Workspace) => Promise<boolean>;
  t: Translate;
  notify: (message: string) => void;
}
const palette = ['#4169E1', '#8B6EAD', '#38947D', '#C78843', '#BB6381', '#627D98'];
const visibleInStore = (item: { storeId: string }, storeId: string) =>
  storeId === 'all' || item.storeId === storeId;
const newId = () => crypto.randomUUID();

function EmptyState({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children?: React.ReactNode;
}) {
  return (
    <div className={styles.empty}>
      <span className={styles.emptyIcon}>
        <FolderOpen size={28} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {children}
    </div>
  );
}

export function GroupsPanel({ data, storeId, update, t, notify }: PanelProps) {
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Group | null>(null);
  const [editingBaseline, setEditingBaseline] = useState<Group | null>(null);
  const [error, setError] = useState('');
  const editorRef = useRef<HTMLFormElement>(null);
  const addButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const linkedPosts = editing ? data.posts.some((post) => post.groupId === editing.id) : false;
  const originalGroup = editing ? data.groups.find((group) => group.id === editing.id) : undefined;
  const facebookIdLocked = Boolean(
    originalGroup?.facebookId.trim() &&
    data.posts.some((post) => post.groupId === originalGroup.id && post.facebookPostId.trim()),
  );
  const groups = useMemo(() => {
    const term = search.toLocaleLowerCase();
    return data.groups.filter(
      (group) =>
        !group.deletedAt &&
        visibleInStore(group, storeId) &&
        `${group.name} ${group.category} ${group.facebookId}`.toLocaleLowerCase().includes(term),
    );
  }, [data.groups, storeId, search]);
  const postCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const post of data.posts) {
      if (!post.deletedAt && post.groupId)
        counts.set(post.groupId, (counts.get(post.groupId) ?? 0) + 1);
    }
    return counts;
  }, [data.posts]);
  const storesById = useMemo(
    () => new Map(data.stores.map((store) => [store.id, store])),
    [data.stores],
  );
  const begin = useCallback(
    (group?: Group) => {
      previousFocus.current = document.activeElement as HTMLElement | null;
      setEditingBaseline(group ? { ...group } : null);
      setEditing(
        group
          ? { ...group }
          : {
              id: newId(),
              storeId: storeId !== 'all' ? storeId : sortCatalog(data.stores)[0]?.id || '',
              name: '',
              facebookId: '',
              category: '',
              notes: '',
            },
      );
      setError('');
      requestAnimationFrame(() => {
        editorRef.current?.scrollIntoView({ behavior: 'auto', block: 'start' });
        editorRef.current?.querySelector<HTMLInputElement>('input')?.focus({ preventScroll: true });
      });
    },
    [data.stores, storeId],
  );
  const closeEditor = useCallback(() => {
    setEditing(null);
    requestAnimationFrame(() => {
      const target = previousFocus.current;
      if (target?.isConnected) target.focus({ preventScroll: true });
      else addButtonRef.current?.focus({ preventScroll: true });
    });
  }, []);
  const moveToTrash = useCallback(
    async (group: Group) => {
      if (
        !(await update({
          ...data,
          groups: data.groups.map((item) =>
            item.id === group.id ? { ...item, deletedAt: new Date().toISOString() } : item,
          ),
        }))
      )
        return;
      notify(
        t(
          'Group moved to Trash. You can restore it within 30 days.',
          'ย้ายกลุ่มไปถังขยะแล้ว กู้คืนได้ภายใน 30 วัน',
        ),
      );
    },
    [data, update, notify, t],
  );
  const groupCards = useMemo(
    () =>
      groups.map((group) => {
        const store = storesById.get(group.storeId);
        return (
          <article className={styles.groupCard} key={group.id}>
            <div className={styles.cardTop}>
              <span className={styles.communityIcon}>
                <UsersRound size={25} />
              </span>
              <div className={styles.cardActions}>
                <button
                  className={styles.iconButton}
                  aria-label={`${t('Edit', 'แก้ไข')} ${group.name}`}
                  onClick={() => begin(group)}
                >
                  <Pencil size={17} />
                </button>
                <button
                  className={styles.iconButton}
                  aria-label={`${t('Move to Trash', 'ย้ายไปถังขยะ')} ${group.name}`}
                  onClick={() => void moveToTrash(group)}
                >
                  <Trash2 size={17} />
                </button>
              </div>
            </div>
            <span className={styles.category}>
              {group.category || t('Facebook group', 'กลุ่ม Facebook')}
            </span>
            <h3>{group.name}</h3>
            <p className={styles.groupNotes}>
              {group.notes ||
                t(
                  'Add posting notes to keep your team on the same page.',
                  'เพิ่มหมายเหตุการโพสต์เพื่อให้ทีมทำงานได้ตรงกัน',
                )}
            </p>
            <div className={styles.groupMeta}>
              <span>
                <span
                  className={styles.storeDot}
                  style={{ background: store?.color || palette[0] }}
                />
                {store?.name || t('Unknown store', 'ไม่พบร้านค้า')}
              </span>
              <span>
                {postCounts.get(group.id) ?? 0} {t('posts', 'โพสต์')}
              </span>
            </div>
            <div className={styles.cardFooter}>
              {/^\d+$/.test(group.facebookId) ? (
                <a
                  className={styles.textLink}
                  href={`https://www.facebook.com/groups/${group.facebookId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {t('Open group', 'เปิดกลุ่ม')}
                  <ExternalLink size={16} />
                </a>
              ) : (
                <span className={styles.muted}>
                  {t(
                    'Add a valid Facebook ID to open',
                    'เพิ่มรหัส Facebook ที่ถูกต้องเพื่อเปิดกลุ่ม',
                  )}
                </span>
              )}
              <span className={styles.facebookLabel}>facebook</span>
            </div>
          </article>
        );
      }),
    [groups, storesById, postCounts, t, begin, moveToTrash],
  );
  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing) return;
    if (
      !entityEditIsCurrent(
        editingBaseline,
        data.groups.find((group) => group.id === editing.id),
      )
    ) {
      setError(
        t(
          'This group changed in another tab. Your edits are still here. Copy them before reopening the latest group.',
          'กลุ่มนี้ถูกแก้ไขในแท็บอื่น การแก้ไขของคุณยังอยู่ที่นี่ คัดลอกข้อมูลที่ต้องการเก็บไว้ก่อนเปิดกลุ่มเวอร์ชันล่าสุด',
        ),
      );
      return;
    }
    const name = editing.name.trim();
    const facebookId = editing.facebookId.trim();
    if (facebookIdLocked && facebookId !== originalGroup?.facebookId) {
      setError(
        t(
          'This group ID cannot change because existing Post IDs depend on it, including posts in Trash.',
          'เปลี่ยนรหัสกลุ่มนี้ไม่ได้ เพราะ Post ID ที่บันทึกไว้เชื่อมกับรหัสนี้ รวมถึงโพสต์ในถังขยะ',
        ),
      );
      return;
    }
    if (
      !name ||
      !/^\d+$/.test(facebookId) ||
      !data.stores.some((store) => store.id === editing.storeId)
    ) {
      setError(
        t(
          'Add a group name, numeric Facebook group ID, and store.',
          'กรุณากรอกชื่อกลุ่ม รหัสกลุ่ม Facebook ที่เป็นตัวเลข และเลือกร้านค้า',
        ),
      );
      return;
    }
    if (
      data.groups.some(
        (group) =>
          group.id !== editing.id &&
          !group.deletedAt &&
          group.facebookId === facebookId &&
          group.storeId === editing.storeId,
      )
    ) {
      setError(
        t(
          'This Facebook group is already saved for this store.',
          'บันทึกกลุ่ม Facebook นี้สำหรับร้านค้านี้แล้ว',
        ),
      );
      return;
    }
    const item = {
      ...editing,
      name,
      facebookId,
      category: editing.category.trim(),
      notes: editing.notes.trim(),
    };
    if (
      !(await update({
        ...data,
        groups: data.groups.some((group) => group.id === item.id)
          ? data.groups.map((group) => (group.id === item.id ? item : group))
          : [...data.groups, item],
      }))
    )
      return;
    closeEditor();
    notify(t('Group saved.', 'บันทึกกลุ่มแล้ว'));
  };
  return (
    <div className={styles.stack}>
      <div className={styles.toolbar}>
        <div>
          <h2>{t('Your communities', 'ชุมชนของคุณ')}</h2>
          <p>
            {t(
              'Keep the right groups close to every store.',
              'จัดกลุ่มเป้าหมายให้พร้อมสำหรับแต่ละร้านค้า',
            )}
          </p>
        </div>
        <button
          ref={addButtonRef}
          className={styles.primaryButton}
          onClick={() => begin()}
          disabled={!data.stores.length}
        >
          <Plus size={19} />
          {t('Add group', 'เพิ่มกลุ่ม')}
        </button>
      </div>
      <div className={styles.search}>
        <Search size={19} />
        <input
          aria-label={t('Search groups', 'ค้นหากลุ่ม')}
          placeholder={t('Search groups, categories, or IDs…', 'ค้นหากลุ่ม หมวดหมู่ หรือรหัส…')}
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
        <span>{groups.length}</span>
      </div>
      {editing && (
        <form className={`${styles.editor} ${styles.groupEditor}`} onSubmit={save} ref={editorRef}>
          <div className={styles.sectionHeading}>
            <div>
              <span className={styles.eyebrow}>{t('GROUP DETAILS', 'รายละเอียดกลุ่ม')}</span>
              <h3>
                {data.groups.some((group) => group.id === editing.id)
                  ? t('Edit group', 'แก้ไขกลุ่ม')
                  : t('A new place to connect', 'เพิ่มพื้นที่เข้าถึงลูกค้า')}
              </h3>
            </div>
            <button
              type="button"
              className={styles.iconButton}
              aria-label={t('Close group editor', 'ปิดการแก้ไขกลุ่ม')}
              onClick={closeEditor}
            >
              <X size={20} />
            </button>
          </div>
          <div className={styles.formGrid}>
            <label>
              {t('Group name', 'ชื่อกลุ่ม')}
              <input
                required
                maxLength={160}
                value={editing.name}
                onChange={(event) => setEditing({ ...editing, name: event.target.value })}
                placeholder={t('e.g. Coffee lovers Thailand', 'เช่น คนรักกาแฟประเทศไทย')}
              />
            </label>
            <label>
              {t('Store', 'ร้านค้า')}
              <select
                required
                disabled={linkedPosts}
                value={editing.storeId}
                onChange={(event) => setEditing({ ...editing, storeId: event.target.value })}
              >
                {sortCatalog(data.stores).map((store) => (
                  <option key={store.id} value={store.id}>
                    {store.name}
                  </option>
                ))}
              </select>
              {linkedPosts && (
                <small>
                  {t(
                    'This group stays with its store because it has linked posts.',
                    'กลุ่มนี้มีโพสต์ที่เชื่อมอยู่ จึงไม่สามารถเปลี่ยนร้านค้าได้',
                  )}
                </small>
              )}
            </label>
            <label>
              {t('Facebook group ID', 'รหัสกลุ่ม Facebook')}
              <input
                required
                inputMode="numeric"
                pattern="[0-9]+"
                maxLength={40}
                readOnly={facebookIdLocked}
                value={editing.facebookId}
                onChange={(event) => {
                  const facebookId = event.target.value;
                  const previousKnownName = knownFacebookGroupName(editing.facebookId);
                  const isAutomaticName =
                    !editing.name.trim() ||
                    editing.name === `Facebook group ${editing.facebookId}` ||
                    (!!previousKnownName && editing.name === previousKnownName);
                  setEditing({
                    ...editing,
                    facebookId,
                    name: isAutomaticName ? knownFacebookGroupName(facebookId) || '' : editing.name,
                  });
                }}
                placeholder="123456789012345"
              />
              <small>
                {facebookIdLocked
                  ? t(
                      'Locked to preserve links for existing Post IDs, including posts in Trash.',
                      'ล็อกรหัสนี้เพื่อรักษาลิงก์ของ Post ID ที่บันทึกไว้ รวมถึงโพสต์ในถังขยะ',
                    )
                  : t(
                      'The numbers after /groups/ in the group URL. Known IDs fill the group name.',
                      'ตัวเลขหลัง /groups/ ในลิงก์กลุ่ม หากมีในรายการ ระบบจะกรอกชื่อกลุ่มให้',
                    )}
              </small>
            </label>
            <label>
              {t('Category', 'หมวดหมู่')}
              <input
                maxLength={80}
                value={editing.category}
                onChange={(event) => setEditing({ ...editing, category: event.target.value })}
                placeholder={t('e.g. Food & drink', 'เช่น อาหารและเครื่องดื่ม')}
              />
            </label>
            <label className={styles.fullWidth}>
              {t('Posting notes', 'หมายเหตุการโพสต์')}
              <textarea
                rows={3}
                maxLength={2000}
                value={editing.notes}
                onChange={(event) => setEditing({ ...editing, notes: event.target.value })}
                placeholder={t(
                  'Group rules, best posting times, or useful context…',
                  'กฎของกลุ่ม ช่วงเวลาที่เหมาะกับการโพสต์ หรือข้อมูลที่ควรทราบ…',
                )}
              />
            </label>
          </div>
          {error && (
            <p className={styles.error} role="alert">
              {error}
            </p>
          )}
          <div className={styles.formActions}>
            <button type="button" className={styles.secondaryButton} onClick={closeEditor}>
              {t('Cancel', 'ยกเลิก')}
            </button>
            <button className={styles.primaryButton} type="submit">
              <Check size={18} />
              {t('Save group', 'บันทึกกลุ่ม')}
            </button>
          </div>
        </form>
      )}
      {groups.length ? (
        <div className={styles.cardGrid}>{groupCards}</div>
      ) : (
        <EmptyState
          title={
            search
              ? t('No groups match your search', 'ไม่พบกลุ่มที่ค้นหา')
              : t('Make room for your communities', 'เริ่มรวบรวมชุมชนของคุณ')
          }
          description={
            search
              ? t(
                  'Try another name, category, or Facebook ID.',
                  'ลองค้นหาชื่อ หมวดหมู่ หรือรหัส Facebook อื่น',
                )
              : t(
                  'Add a Facebook group to organize posts and keep its rules handy.',
                  'เพิ่มกลุ่ม Facebook เพื่อจัดการโพสต์และบันทึกกฎของกลุ่ม',
                )
          }
        />
      )}
    </div>
  );
}

export function SettingsPanel({
  data,
  update,
  t,
  notify,
  repository,
  revision,
}: PanelProps & { repository: WorkspaceRepository; revision: string }) {
  const [pending, setPending] = useState<Workspace | null>(null);
  const [pendingRevision, setPendingRevision] = useState<string | null>(null);
  const [restoreName, setRestoreName] = useState('');
  const [error, setError] = useState('');
  const [resetOpen, setResetOpen] = useState(false);
  const [resetRevision, setResetRevision] = useState<string | null>(null);
  const [olderBackups, setOlderBackups] = useState<Array<{ key: string; version: string }>>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    try {
      setOlderBackups(repository.listOlderBackups());
    } catch {
      // The active workspace can still be used if browser storage is unavailable.
    }
  }, []);
  const downloadJson = (content: string, filename: string) => {
    const url = URL.createObjectURL(new Blob([content], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const download = () => {
    downloadJson(
      JSON.stringify(serializeWorkspace(data), null, 2),
      `vetra-workspace-${new Date().toISOString().slice(0, 10)}.json`,
    );
    notify(t('Backup downloaded.', 'ดาวน์โหลดไฟล์สำรองแล้ว'));
  };
  const downloadOlderBackup = (key: string, version: string) => {
    try {
      const content = repository.readOlderBackup(key);
      if (!content) throw new Error('missing backup');
      downloadJson(
        content,
        `vetra-previous-workspace-${version}-${new Date().toISOString().slice(0, 10)}.json`,
      );
      notify(t('Previous backup downloaded.', 'ดาวน์โหลดไฟล์สำรองก่อนหน้าแล้ว'));
    } catch {
      setError(
        t(
          'This previous backup is no longer available in this browser.',
          'ไม่พบไฟล์สำรองก่อนหน้านี้ในเบราว์เซอร์แล้ว',
        ),
      );
    }
  };
  const readBackup = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const selectedRevision = revision;
    setError('');
    setPending(null);
    setPendingRevision(null);
    setResetOpen(false);
    try {
      if (file.size > 10 * 1024 * 1024) throw new Error('size');
      const parsed = deserializeWorkspace(JSON.parse((await file.text()).replace(/^\uFEFF/, '')));
      if (!parsed) throw new Error('invalid');
      setPending(parsed);
      setPendingRevision(selectedRevision);
      setRestoreName(file.name);
    } catch {
      setError(
        t(
          'This backup could not be read. Choose a valid VETRA JSON backup smaller than 10 MB.',
          'อ่านไฟล์สำรองนี้ไม่ได้ กรุณาเลือกไฟล์สำรอง JSON ของ VETRA ที่ถูกต้องและมีขนาดไม่เกิน 10 MB',
        ),
      );
    }
    event.target.value = '';
  };
  return (
    <div className={styles.stack}>
      <div className={styles.toolbar}>
        <div>
          <h2>{t('Make this space yours', 'จัดการพื้นที่ทำงานของคุณ')}</h2>
          <p>
            {t('Your workspace, your data, your way of working.', 'ข้อมูลและการทำงานในแบบของคุณ')}
          </p>
        </div>
        <span className={styles.localBadge}>
          <LockKeyhole size={16} />
          {t('On this browser', 'ในเบราว์เซอร์นี้')}
        </span>
      </div>
      <div className={styles.settingsGrid}>
        <section className={styles.settingsCard}>
          <span className={styles.settingsIcon}>
            <ShieldCheck size={25} />
          </span>
          <h3>{t('A local workspace', 'พื้นที่ทำงานในเบราว์เซอร์')}</h3>
          <p>
            {t(
              'Your products, stores, posts, and Viewers totals are saved in this browser on this device.',
              'สินค้า ร้านค้า โพสต์ และยอดผู้ชมถูกบันทึกในเบราว์เซอร์นี้บนอุปกรณ์นี้',
            )}
          </p>
          <div className={styles.infoNote}>
            <CircleHelp size={20} />
            <p>
              {t(
                'There is no cloud sync or shared team login yet. Clearing browser data can remove your workspace. Download regular backups and keep them somewhere safe.',
                'ยังไม่มีการซิงก์บนคลาวด์หรือบัญชีทีมร่วมกัน การล้างข้อมูลเบราว์เซอร์อาจทำให้ข้อมูลหาย โปรดดาวน์โหลดไฟล์สำรองและเก็บไว้ในที่ปลอดภัย',
              )}
            </p>
          </div>
          <div className={styles.featureLine}>
            <Check size={18} />
            {t('Track published posts and viewers', 'ติดตามโพสต์ที่เผยแพร่แล้วและยอดผู้ชม')}
          </div>
          <div className={styles.featureLine}>
            <Check size={18} />
            {t('No social account credentials stored', 'ไม่เก็บข้อมูลเข้าสู่ระบบโซเชียลมีเดีย')}
          </div>
        </section>
        <section className={styles.settingsCard}>
          <span className={styles.settingsIcon}>
            <FileJson size={25} />
          </span>
          <h3>{t('Keep a copy of your work', 'เก็บสำเนางานของคุณ')}</h3>
          <p>
            {t(
              'Download a JSON backup of your products, stores, groups, published posts, current Viewers totals, and Trash.',
              'ดาวน์โหลดไฟล์สำรอง JSON ของสินค้า ร้านค้า กลุ่ม โพสต์ที่เผยแพร่แล้ว ยอดผู้ชมล่าสุด และถังขยะ',
            )}
          </p>
          <div className={styles.backupButtons}>
            <button className={styles.primaryButton} onClick={download}>
              <ArrowDownToLine size={18} />
              {t('Download backup', 'ดาวน์โหลดไฟล์สำรอง')}
            </button>
            <button className={styles.secondaryButton} onClick={() => fileRef.current?.click()}>
              <ArrowUpFromLine size={18} />
              {t('Restore backup', 'กู้คืนไฟล์สำรอง')}
            </button>
            <input
              ref={fileRef}
              className={styles.hiddenInput}
              aria-label={t('Choose JSON backup', 'เลือกไฟล์สำรอง JSON')}
              type="file"
              accept=".json,application/json"
              onChange={readBackup}
            />
          </div>
          <p className={styles.smallText}>
            {t(
              'Restore shows a preview before replacing this workspace. Older backups bring back published posts only.',
              'การกู้คืนจะแสดงตัวอย่างก่อนแทนที่พื้นที่ทำงานนี้ ไฟล์สำรองรุ่นก่อนจะกู้คืนเฉพาะโพสต์ที่เผยแพร่แล้ว',
            )}
          </p>
          {olderBackups.length > 0 && (
            <details className={styles.smallText}>
              <summary>{t('Previous local data', 'ข้อมูลเดิมในเบราว์เซอร์')}</summary>
              <p>
                {t(
                  'Your older workspace is still saved in this browser. Download a copy if you need records excluded from the current monitor.',
                  'ข้อมูลพื้นที่ทำงานรุ่นก่อนยังอยู่ในเบราว์เซอร์นี้ ดาวน์โหลดสำเนาหากต้องการรายการที่ไม่แสดงในหน้าติดตามปัจจุบัน',
                )}
              </p>
              <div className={styles.backupButtons}>
                {olderBackups.map(({ key, version }) => (
                  <button
                    className={styles.secondaryButton}
                    key={key}
                    onClick={() => downloadOlderBackup(key, version)}
                  >
                    <ArrowDownToLine size={17} />
                    {t(`Download ${version} copy`, `ดาวน์โหลดสำเนา ${version}`)}
                  </button>
                ))}
              </div>
            </details>
          )}
          {error && (
            <p className={styles.error} role="alert">
              {error}
            </p>
          )}
        </section>
      </div>
      {pending && (
        <section
          className={styles.confirmPanel}
          aria-label={t('Review backup restore', 'ตรวจสอบการกู้คืนไฟล์สำรอง')}
        >
          <div className={styles.sectionHeading}>
            <div>
              <span className={styles.eyebrow}>
                {t('REVIEW BEFORE RESTORING', 'ตรวจสอบก่อนกู้คืน')}
              </span>
              <h3>{restoreName}</h3>
            </div>
            <button
              className={styles.iconButton}
              aria-label={t('Cancel restore', 'ยกเลิกการกู้คืน')}
              onClick={() => {
                setPending(null);
                setPendingRevision(null);
              }}
            >
              <X size={20} />
            </button>
          </div>
          <div className={styles.restoreStats}>
            <span>
              <strong>{pending.products.length}</strong>
              {t('products', 'สินค้า')}
            </span>
            <span>
              <strong>{pending.stores.length}</strong>
              {t('stores', 'ร้านค้า')}
            </span>
            <span>
              <strong>{pending.groups.length}</strong>
              {t('groups', 'กลุ่ม')}
            </span>
            <span>
              <strong>{pending.posts.length}</strong>
              {t('published posts', 'โพสต์ที่เผยแพร่แล้ว')}
            </span>
          </div>
          <p>
            {t(
              'Restoring replaces all data in the current workspace. Download a backup of your current work first if you want to keep it.',
              'การกู้คืนจะแทนที่ข้อมูลทั้งหมดในพื้นที่ทำงานปัจจุบัน หากต้องการเก็บข้อมูลเดิม โปรดดาวน์โหลดไฟล์สำรองก่อน',
            )}
          </p>
          {pendingRevision !== revision && (
            <p className={styles.error} role="alert">
              {t(
                'This workspace changed while you reviewed the backup. Check the latest data and select the backup again before replacing it.',
                'พื้นที่ทำงานมีการเปลี่ยนแปลงระหว่างตรวจสอบไฟล์สำรอง กรุณาตรวจสอบข้อมูลล่าสุดและเลือกไฟล์สำรองอีกครั้งก่อนแทนที่',
              )}
            </p>
          )}
          <div className={styles.formActions}>
            <button className={styles.secondaryButton} onClick={download}>
              {t('Back up current data', 'สำรองข้อมูลปัจจุบัน')}
            </button>
            <button
              className={styles.dangerButton}
              onClick={async () => {
                if (pendingRevision !== revision) return;
                if (!(await update(pending))) return;
                setPending(null);
                setPendingRevision(null);
                notify(t('Backup restored.', 'กู้คืนไฟล์สำรองแล้ว'));
              }}
            >
              {t('Confirm replacement', 'ยืนยันการแทนที่ข้อมูล')}
            </button>
          </div>
        </section>
      )}
      <section className={styles.settingsCard}>
        <div className={styles.sectionHeading}>
          <div>
            <span className={styles.eyebrow}>{t('YOUR CHANNELS', 'ช่องทางของคุณ')}</span>
            <h3>{t('Built around your workflow', 'พร้อมสำหรับขั้นตอนการทำงานของคุณ')}</h3>
          </div>
          <Globe2 size={24} className={styles.muted} />
        </div>
        <div className={styles.platformGrid}>
          <div className={styles.platform}>
            <span className={styles.platformSymbol}>f</span>
            <div>
              <strong>Facebook</strong>
              <span>{t('Manual tracking', 'ติดตามด้วยตนเอง')}</span>
            </div>
            <span className={styles.available}>
              <Check size={15} />
              {t('Available', 'พร้อมใช้งาน')}
            </span>
          </div>
          {['Instagram', 'TikTok', 'LinkedIn'].map((name) => (
            <div className={styles.platform} key={name}>
              <span className={styles.futureSymbol}>
                <Layers3 size={20} />
              </span>
              <div>
                <strong>{name}</strong>
                <span>{t('Future integration', 'การเชื่อมต่อในอนาคต')}</span>
              </div>
            </div>
          ))}
        </div>
        <p className={styles.smallText}>
          {t(
            'Add posts that already exist, with their actual publication date and link or Facebook IDs. Record viewer counts as they change. Live analytics is not connected.',
            'เพิ่มโพสต์ที่เผยแพร่แล้วพร้อมวันที่เผยแพร่จริงและลิงก์หรือรหัส Facebook จากนั้นบันทึกยอดผู้ชมเมื่อมีการเปลี่ยนแปลง ยังไม่มีการเชื่อมต่อข้อมูลวิเคราะห์แบบสด',
          )}
        </p>
      </section>
      {data.sample && (
        <section className={styles.resetCard}>
          <div>
            <h3>
              {t('Ready for your own workspace?', 'พร้อมเริ่มพื้นที่ทำงานของคุณแล้วหรือยัง?')}
            </h3>
            <p>
              {t(
                'Start fresh when you have finished exploring the demo.',
                'เริ่มใหม่เมื่อทดลองใช้ข้อมูลตัวอย่างเรียบร้อยแล้ว',
              )}
            </p>
          </div>
          <button
            className={styles.secondaryButton}
            onClick={() => {
              setResetOpen(true);
              setResetRevision(revision);
              setPending(null);
              setPendingRevision(null);
            }}
          >
            {t('Start with empty workspace', 'เริ่มด้วยพื้นที่ทำงานว่าง')}
          </button>
          {resetOpen && (
            <div className={styles.resetConfirm}>
              <p>
                {t(
                  'This replaces the current workspace with a single VETRA STORE and no products, posts, or groups. Download a backup first to keep your work.',
                  'พื้นที่ทำงานปัจจุบันจะถูกแทนที่ด้วย VETRA STORE หนึ่งร้าน โดยไม่มีสินค้า กลุ่ม หรือโพสต์ โปรดดาวน์โหลดไฟล์สำรองก่อนเพื่อเก็บข้อมูลไว้',
                )}
              </p>
              {resetRevision !== revision && (
                <p className={styles.error} role="alert">
                  {t(
                    'This workspace changed while you reviewed the reset. Check the latest data and open this confirmation again.',
                    'พื้นที่ทำงานมีการเปลี่ยนแปลงระหว่างตรวจสอบการเริ่มใหม่ กรุณาตรวจสอบข้อมูลล่าสุดและเปิดหน้าต่างยืนยันนี้อีกครั้ง',
                  )}
                </p>
              )}
              <div className={styles.formActions}>
                <button className={styles.secondaryButton} onClick={() => setResetOpen(false)}>
                  {t('Cancel', 'ยกเลิก')}
                </button>
                <button className={styles.secondaryButton} onClick={download}>
                  {t('Download backup', 'ดาวน์โหลดไฟล์สำรอง')}
                </button>
                <button
                  className={styles.dangerButton}
                  onClick={async () => {
                    if (resetRevision !== revision) return;
                    if (
                      !(await update({
                        ...createEmptyWorkspace(),
                        appliedDataUpdates: data.appliedDataUpdates,
                      }))
                    )
                      return;
                    setResetOpen(false);
                    setResetRevision(null);
                    notify(
                      t(
                        'Your workspace is ready. Add your first published post to begin.',
                        'พื้นที่ทำงานพร้อมแล้ว เริ่มด้วยการเพิ่มโพสต์ที่เผยแพร่แล้วรายการแรก',
                      ),
                    );
                  }}
                >
                  {t('Confirm and start fresh', 'ยืนยันและเริ่มใหม่')}
                </button>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

export function TrashPanel({ data, storeId, update, t, notify }: PanelProps) {
  const now = Date.now();
  const retention = 30 * 24 * 60 * 60 * 1000;
  const productStoresById = useMemo(
    () => productStoreIdMap(data.products, data.posts),
    [data.products, data.posts],
  );
  const entries = [
    ...data.products
      .filter(
        (item) =>
          item.deletedAt &&
          (storeId === 'all' || productStoresById.get(item.id)?.includes(storeId)),
      )
      .map((item) => ({ ...item, storeId: '', type: 'product' as const })),
    ...data.posts
      .filter((item) => item.deletedAt && visibleInStore(item, storeId))
      .map((item) => ({
        ...item,
        type: 'post' as const,
        name: item.product || item.title || 'Post',
      })),
    ...data.groups
      .filter((item) => item.deletedAt && visibleInStore(item, storeId))
      .map((item) => ({ ...item, type: 'group' as const })),
  ]
    .filter((item) => now - new Date(item.deletedAt!).getTime() < retention)
    .sort((a, b) => new Date(b.deletedAt!).getTime() - new Date(a.deletedAt!).getTime());
  const restore = async (id: string, type: 'post' | 'group' | 'product') => {
    let next: Workspace;
    if (type === 'product') {
      next = {
        ...data,
        products: data.products.map((item) =>
          item.id === id ? { ...item, deletedAt: undefined } : item,
        ),
      };
    } else if (type === 'group') {
      next = {
        ...data,
        groups: data.groups.map((item) =>
          item.id === id ? { ...item, deletedAt: undefined } : item,
        ),
      };
    } else {
      const post = data.posts.find((item) => item.id === id);
      next = {
        ...data,
        posts: data.posts.map((item) =>
          item.id === id ? { ...item, deletedAt: undefined } : item,
        ),
        groups: data.groups.map((item) =>
          item.id === post?.groupId &&
          item.deletedAt &&
          now - new Date(item.deletedAt).getTime() < retention
            ? { ...item, deletedAt: undefined }
            : item,
        ),
      };
    }
    if (await update(next))
      notify(t('Restored to your workspace.', 'กู้คืนกลับสู่พื้นที่ทำงานแล้ว'));
  };
  return (
    <div className={styles.stack}>
      <div className={styles.toolbar}>
        <div>
          <h2>{t('A little room to undo', 'ยังมีเวลากู้คืน')}</h2>
          <p>
            {t(
              'Deleted products, posts, and groups stay here for 30 days.',
              'สินค้า โพสต์ และกลุ่มที่ลบจะถูกเก็บไว้ที่นี่ 30 วัน',
            )}
          </p>
        </div>
        <span className={styles.localBadge}>
          <Trash2 size={16} />
          {entries.length} {t(entries.length === 1 ? 'item' : 'items', 'รายการ')}
        </span>
      </div>
      <div className={styles.infoNote}>
        <ArchiveRestore size={21} />
        <p>
          {t(
            'Restore an item before its 30-day retention ends. Expired items are removed automatically when the workspace is loaded.',
            'กู้คืนรายการก่อนครบ 30 วัน รายการที่หมดอายุจะถูกลบอัตโนมัติเมื่อเปิดพื้นที่ทำงาน',
          )}
        </p>
      </div>
      {entries.length ? (
        <div className={styles.trashList}>
          {entries.map((entry) => {
            const store = data.stores.find((item) => item.id === entry.storeId);
            const productStoreNames =
              entry.type === 'product'
                ? (productStoresById.get(entry.id) ?? [])
                    .map((id) => data.stores.find((item) => item.id === id)?.name)
                    .filter(Boolean)
                    .join(', ')
                : '';
            const days = Math.max(
              1,
              Math.ceil((retention - (now - new Date(entry.deletedAt!).getTime())) / 86400000),
            );
            return (
              <article className={styles.trashRow} key={`${entry.type}-${entry.id}`}>
                <span className={styles.trashIcon}>
                  {entry.type === 'product' ? (
                    <Package size={22} />
                  ) : entry.type === 'group' ? (
                    <UsersRound size={22} />
                  ) : (
                    <FileJson size={22} />
                  )}
                </span>
                <div className={styles.trashInfo}>
                  <h3>{entry.name}</h3>
                  <p>
                    {entry.type === 'product'
                      ? t('Product', 'สินค้า')
                      : entry.type === 'group'
                        ? t('Group', 'กลุ่ม')
                        : t('Post', 'โพสต์')}
                    <span>·</span>
                    {entry.type === 'product'
                      ? productStoreNames || t('Store not assigned', 'ยังไม่ได้กำหนดร้านค้า')
                      : store?.name}
                    <span>·</span>
                    {t('Deleted', 'ลบเมื่อ')}{' '}
                    {new Date(entry.deletedAt!).toLocaleDateString(t('en-GB', 'th-TH'), {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </p>
                </div>
                <span className={styles.daysLeft}>
                  {days} {t('days left', 'วันเหลือ')}
                </span>
                <button
                  className={styles.secondaryButton}
                  onClick={() => restore(entry.id, entry.type)}
                >
                  <ArchiveRestore size={17} />
                  {t('Restore', 'กู้คืน')}
                </button>
              </article>
            );
          })}
        </div>
      ) : (
        <EmptyState
          title={t('Nothing in the bin', 'ถังขยะว่างอยู่')}
          description={t(
            'Deleted products, posts, and groups will appear here, ready to restore.',
            'สินค้า โพสต์ และกลุ่มที่ลบจะแสดงที่นี่ เพื่อให้คุณกู้คืนได้',
          )}
        />
      )}
    </div>
  );
}
