'use client';

import { useEffect, useLayoutEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { ArrowUpRight, CalendarDays, Check, Eye, Link2, TriangleAlert, X } from 'lucide-react';
import type { Group, Post, Platform, Translate, Workspace } from '@/lib/types';
import { canonicalPostUrl } from '@/lib/data';
import { sortCatalog } from '@/lib/catalog';
import { knownFacebookGroupName, resolveFacebookGroupName } from '@/lib/facebook-group-directory';
import { parseFacebookGroupPostUrl } from '@/lib/facebook-post-url';
import { postEditorSnapshot } from '@/lib/post-editor-snapshot';
import { postPublicationStatus } from '@/lib/post-tools';
import { productStoreIdMap } from '@/lib/product-store';
import { reviewPostLink } from '@/lib/post-link-review';
import styles from './PostEditor.module.css';

type Props = {
  post: Post | null;
  initialUrl?: string;
  data: Workspace;
  storeId: string;
  t: Translate;
  onSave: (post: Post, pendingGroup: Group | null) => Promise<void>;
  onDelete: (post: Post) => Promise<boolean>;
  onClose: () => void;
  onOpenPost: (post: Post, initialUrl?: string) => void;
};
type FacebookPostType = 'group' | 'page';

function bangkokDateTime(value: string) {
  if (!value || !Number.isFinite(new Date(value).getTime())) return '';
  const pieces = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Bangkok',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date(value));
  const part = (name: string) => pieces.find((item) => item.type === name)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}T${part('hour')}:${part('minute')}`;
}

function toIso(value: string) {
  if (!value) return '';
  const date = new Date(`${value}:00+07:00`);
  return Number.isFinite(date.getTime()) && bangkokDateTime(date.toISOString()) === value
    ? date.toISOString()
    : '';
}

function safeUrl(value: string) {
  try {
    const url = new URL(value);
    return (
      url.protocol === 'https:' &&
      !url.username &&
      !url.password &&
      !!url.hostname &&
      !/[\u0000-\u0020\u007f]/.test(value)
    );
  } catch {
    return false;
  }
}

export default function PostEditor({
  post,
  initialUrl,
  data,
  storeId,
  t,
  onSave,
  onDelete,
  onClose,
  onOpenPost,
}: Props) {
  const startingUrl = initialUrl ?? post?.url ?? '';
  const startingIds = parseFacebookGroupPostUrl(startingUrl);
  const dialog = useRef<HTMLDialogElement>(null);
  const form = useRef<HTMLFormElement>(null);
  const productInput = useRef<HTMLInputElement>(null);
  const linkInput = useRef<HTMLInputElement>(null);
  const keepEditingButton = useRef<HTMLButtonElement>(null);
  const discardButton = useRef<HTMLButtonElement>(null);
  const lastEditingFocus = useRef<HTMLElement | null>(null);
  const shouldRestoreEditingFocus = useRef(false);
  const savingRef = useRef(false);
  const [selectedStore, setSelectedStore] = useState(
    post?.storeId || (storeId !== 'all' ? storeId : '') || sortCatalog(data.stores)[0]?.id || '',
  );
  const [product, setProduct] = useState(
    (post?.productId &&
      data.products.find((item) => item.id === post.productId && !item.deletedAt)?.name) ||
      post?.product ||
      '',
  );
  const [initialGroupSelection] = useState(() => {
    const linkedGroup = data.groups.find((item) => item.id === post?.groupId && !item.deletedAt);
    const ids = post?.platform === 'facebook' ? startingIds : null;
    if (linkedGroup) {
      return {
        groupId: linkedGroup.id,
        facebookGroupId: linkedGroup.facebookId,
        pendingGroup: null,
      };
    }
    const savedGroup = ids
      ? data.groups.find(
          (item) =>
            item.storeId === selectedStore && !item.deletedAt && item.facebookId === ids.groupId,
        )
      : null;
    if (savedGroup) {
      return { groupId: savedGroup.id, facebookGroupId: ids!.groupId, pendingGroup: null };
    }
    if (ids) {
      const pendingGroup: Group = {
        id: crypto.randomUUID(),
        storeId: selectedStore,
        name: resolveFacebookGroupName(ids.groupId),
        facebookId: ids.groupId,
        category: '',
        notes: '',
      };
      return { groupId: pendingGroup.id, facebookGroupId: ids.groupId, pendingGroup };
    }
    return { groupId: post?.groupId ?? '', facebookGroupId: '', pendingGroup: null };
  });
  const [groupId, setGroupId] = useState(initialGroupSelection.groupId);
  const [pendingGroup, setPendingGroup] = useState<Group | null>(
    initialGroupSelection.pendingGroup,
  );
  const [facebookGroupId, setFacebookGroupId] = useState(initialGroupSelection.facebookGroupId);
  const [platform, setPlatform] = useState<Platform>(post?.platform ?? 'facebook');
  const [postType, setPostType] = useState<FacebookPostType>(
    post?.groupId || (post?.platform === 'facebook' && startingIds)
      ? 'group'
      : post
        ? 'page'
        : 'group',
  );
  const [initialPostType] = useState(postType);
  const [publicationStatus, setPublicationStatus] = useState<'published' | 'pending'>(
    post ? postPublicationStatus(post) : 'published',
  );
  const [publishedAt, setPublishedAt] = useState(bangkokDateTime(post?.publishedAt ?? ''));
  const [facebookPostId, setFacebookPostId] = useState(
    startingIds?.postId ?? post?.facebookPostId ?? '',
  );
  const [url, setUrl] = useState(startingUrl);
  const [autoExtracted, setAutoExtracted] = useState<{
    groupId: string;
    postId: string;
    selectedGroupId: string;
  } | null>(
    startingIds ? { ...startingIds, selectedGroupId: initialGroupSelection.groupId } : null,
  );
  const [linkNotice, setLinkNotice] = useState('');
  const color = post?.color ?? '#4969d7';
  const [viewersInput, setViewersInput] = useState(
    post?.viewers === null || !post ? '' : String(post.viewers),
  );
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmingDiscard, setConfirmingDiscard] = useState(false);
  const [reviewTarget, setReviewTarget] = useState<{ post: Post; initialUrl?: string } | null>(
    null,
  );
  const currentSnapshot = postEditorSnapshot({
    storeId: selectedStore,
    product,
    groupId,
    facebookGroupId,
    platform,
    postType,
    publicationStatus,
    publishedAt,
    facebookPostId,
    url,
    color,
    viewers: viewersInput,
  });
  const [initialSnapshot] = useState(() =>
    postEditorSnapshot({
      storeId: selectedStore,
      product,
      groupId,
      facebookGroupId,
      platform,
      postType,
      publicationStatus,
      publishedAt,
      facebookPostId: post?.facebookPostId ?? '',
      url: post?.url ?? '',
      color,
      viewers: viewersInput,
    }),
  );
  const dirty = currentSnapshot !== initialSnapshot;
  const productStores = productStoreIdMap(data.products, data.posts);
  const storeProducts = data.products.filter(
    (item) => !item.deletedAt && productStores.get(item.id)?.includes(selectedStore),
  );
  const matchingProducts = storeProducts.filter((item) => item.name.trim() === product.trim());
  const linkedProduct = post?.productId
    ? data.products.find((item) => item.id === post.productId)
    : undefined;
  const preserveProductId =
    post?.productId &&
    post.storeId === selectedStore &&
    product.trim() === (linkedProduct?.name ?? post.product).trim();
  const groups = data.groups.filter((item) => item.storeId === selectedStore && !item.deletedAt);
  const group =
    pendingGroup?.id === groupId ? pendingGroup : groups.find((item) => item.id === groupId);
  const matchedGroupName = pendingGroup && knownFacebookGroupName(pendingGroup.facebookId);
  const idsInUrl =
    platform === 'facebook' && postType === 'group' ? parseFacebookGroupPostUrl(url) : null;
  const candidatePublishedAt =
    publicationStatus === 'pending'
      ? ''
      : post?.publishedAt && bangkokDateTime(post.publishedAt) === publishedAt
        ? post.publishedAt
        : toIso(publishedAt);
  const candidate: Post = {
    id: post?.id || '',
    storeId: selectedStore,
    groupId: platform === 'facebook' && postType === 'page' ? '' : groupId,
    product: product.trim(),
    ...(preserveProductId
      ? { productId: post.productId }
      : matchingProducts.length === 1
        ? { productId: matchingProducts[0].id }
        : {}),
    platform,
    publicationStatus,
    ...(post?.metaSourceRow ? { metaSourceRow: post.metaSourceRow } : {}),
    ...(post?.metaPublishedLabel ? { metaPublishedLabel: post.metaPublishedLabel } : {}),
    ...(post?.metaGroupName ? { metaGroupName: post.metaGroupName } : {}),
    ...(post?.metaGroupKey ? { metaGroupKey: post.metaGroupKey } : {}),
    ...(post?.destinationId &&
    post.storeId === selectedStore &&
    post.platform === platform &&
    post.groupId === groupId &&
    postType === 'group'
      ? { destinationId: post.destinationId }
      : {}),
    publishedAt: candidatePublishedAt,
    facebookPostId: facebookPostId.trim(),
    url: url.trim(),
    color,
    viewers: viewersInput.trim() === '' ? null : Number(viewersInput),
    pinned: post?.pinned === true,
  };
  const linkReview = useMemo(
    () => reviewPostLink(data, candidate, pendingGroup),
    [
      data,
      candidate.id,
      candidate.storeId,
      candidate.groupId,
      candidate.platform,
      candidate.facebookPostId,
      candidate.url,
      candidate.metaGroupKey,
      pendingGroup,
    ],
  );
  const generatedUrl =
    (platform === 'facebook' && postType === 'group'
      ? canonicalPostUrl(group?.facebookId ?? '', facebookPostId.trim())
      : '') || (safeUrl(url.trim()) ? url.trim() : '');
  const originalGroup = data.groups.find((item) => item.id === post?.groupId);
  const legacyLinkedGroupWithoutId =
    !!post?.id &&
    !!originalGroup &&
    !originalGroup.facebookId &&
    groupId === post.groupId &&
    !pendingGroup;
  const existingWithoutLink =
    !!post?.id &&
    postType === initialPostType &&
    !post.url &&
    !canonicalPostUrl(originalGroup?.facebookId ?? '', post.facebookPostId);

  useLayoutEffect(() => {
    const element = dialog.current;
    const previousFocus = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    if (element && !element.open) element.showModal();
    (post?.id ? productInput.current : linkInput.current)?.focus({ preventScroll: true });
    return () => {
      if (element?.open) element.close();
      document.body.style.overflow = overflow;
      previousFocus?.focus({ preventScroll: true });
    };
  }, []);

  useEffect(() => {
    if (!dirty || saving || deleting) return;
    function protectUnsavedChanges(event: BeforeUnloadEvent) {
      if (savingRef.current) return;
      event.preventDefault();
      event.returnValue = '';
    }
    window.addEventListener('beforeunload', protectUnsavedChanges);
    return () => window.removeEventListener('beforeunload', protectUnsavedChanges);
  }, [dirty, saving, deleting]);

  useLayoutEffect(() => {
    if (confirmingDiscard) keepEditingButton.current?.focus();
    else if (shouldRestoreEditingFocus.current) {
      (lastEditingFocus.current ?? (post?.id ? productInput.current : linkInput.current))?.focus();
      shouldRestoreEditingFocus.current = false;
    }
  }, [confirmingDiscard]);

  function requestClose() {
    if (savingRef.current || confirmingDiscard) return;
    setReviewTarget(null);
    if (!dirty) {
      if (dialog.current?.open) dialog.current.close();
      onClose();
      return;
    }
    shouldRestoreEditingFocus.current = true;
    setConfirmingDiscard(true);
  }

  function keepEditing() {
    if (!savingRef.current) {
      setReviewTarget(null);
      setConfirmingDiscard(false);
    }
  }

  function discardChanges() {
    if (!savingRef.current) {
      if (dialog.current?.open) dialog.current.close();
      if (reviewTarget) onOpenPost(reviewTarget.post, reviewTarget.initialUrl);
      else onClose();
    }
  }

  function openExistingPost(target: Post, prefillLink?: string) {
    if (savingRef.current || confirmingDiscard) return;
    if (dirty) {
      setReviewTarget({ post: target, initialUrl: prefillLink });
      setConfirmingDiscard(true);
    } else {
      onOpenPost(target, prefillLink);
    }
  }

  function resetPostLink(message: string) {
    if (facebookPostId || url) setLinkNotice(message);
    setFacebookPostId('');
    setUrl('');
    setFacebookGroupId('');
    setPendingGroup(null);
    setAutoExtracted(null);
  }

  function selectGroupByFacebookId(id: string): string {
    if (!/^\d{1,40}$/.test(id)) {
      setGroupId('');
      setPendingGroup(null);
      return '';
    }
    const savedGroup = groups.find((item) => item.facebookId === id);
    if (savedGroup) {
      setGroupId(savedGroup.id);
      setPendingGroup(null);
      return savedGroup.id;
    }
    const nextGroup =
      pendingGroup?.facebookId === id && pendingGroup.storeId === selectedStore
        ? pendingGroup
        : {
            id: crypto.randomUUID(),
            storeId: selectedStore,
            name: resolveFacebookGroupName(id),
            facebookId: id,
            category: '',
            notes: '',
          };
    setPendingGroup(nextGroup);
    setGroupId(nextGroup.id);
    return nextGroup.id;
  }

  function updateGroupId(value: string) {
    setFacebookGroupId(value);
    selectGroupByFacebookId(value.trim());
    setAutoExtracted(null);
    setLinkNotice('');
  }

  function updatePostType(value: FacebookPostType) {
    if (value === postType) return;
    setPostType(value);
    setError('');
    const hadGroupLink = !!parseFacebookGroupPostUrl(url);
    const clearLink = value === 'group' || hadGroupLink;
    const hadLink = !!((clearLink && url) || facebookPostId || facebookGroupId || groupId);
    if (clearLink) setUrl('');
    setFacebookPostId('');
    setGroupId('');
    setFacebookGroupId('');
    setPendingGroup(null);
    setAutoExtracted(null);
    setLinkNotice(
      hadLink
        ? t(
            clearLink
              ? `Post type changed. The previous link and IDs were cleared. Add a ${value === 'group' ? 'Group' : 'Page'} post link.`
              : 'Post type changed. The Group IDs were cleared; please check the post link.',
            clearLink
              ? `เปลี่ยนประเภทโพสต์แล้ว ระบบล้างลิงก์และ ID เดิม กรุณาใส่ลิงก์โพสต์${value === 'group' ? 'ในกลุ่ม' : 'บนเพจ'}`
              : 'เปลี่ยนประเภทโพสต์แล้ว ระบบล้าง Group ID และ Post ID กรุณาตรวจสอบลิงก์โพสต์',
          )
        : '',
    );
  }

  function updatePostUrl(value: string) {
    setUrl(value);
    setLinkNotice('');
    const ids = parseFacebookGroupPostUrl(value);
    if (ids) {
      setPlatform('facebook');
      setPostType('group');
      setFacebookPostId(ids.postId);
      setFacebookGroupId(ids.groupId);
      const selectedGroupId = selectGroupByFacebookId(ids.groupId);
      setAutoExtracted({ ...ids, selectedGroupId });
    } else if (autoExtracted) {
      if (facebookPostId === autoExtracted.postId) setFacebookPostId('');
      if (groupId === autoExtracted.selectedGroupId && facebookGroupId === autoExtracted.groupId) {
        setFacebookGroupId('');
        setGroupId('');
        setPendingGroup(null);
      }
      setAutoExtracted(null);
    }
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (savingRef.current || confirmingDiscard) return;
    setError('');
    if (publicationStatus === 'published' && !candidate.publishedAt)
      return setError(
        t(
          'Add a valid publication date for Published, or select Pending.',
          'ระบุวันที่เผยแพร่ที่ถูกต้องสำหรับสถานะเผยแพร่แล้ว หรือเลือกรอดำเนินการ',
        ),
      );
    if (linkReview.exactMatch)
      return setError(
        t(
          'This link already belongs to another tracked post. Open that record instead.',
          'ลิงก์นี้เป็นของโพสต์ที่ติดตามอยู่แล้ว กรุณาเปิดรายการเดิมแทน',
        ),
      );
    if (!selectedStore || !data.stores.some((item) => item.id === selectedStore))
      return setError(t('Choose a store for this post.', 'เลือกร้านค้าสำหรับโพสต์นี้'));
    if (candidate.groupId && !group)
      return setError(
        t('Choose an available group for this store.', 'เลือกกลุ่มที่ใช้งานได้สำหรับร้านค้านี้'),
      );
    if (platform === 'facebook' && postType === 'group') {
      if (!facebookGroupId.trim() && !legacyLinkedGroupWithoutId)
        return setError(
          t(
            'Paste a Facebook group post link or enter its Group ID.',
            'วางลิงก์โพสต์ในกลุ่ม Facebook หรือระบุ Group ID',
          ),
        );
      if (facebookGroupId.trim() && !/^\d{1,40}$/.test(facebookGroupId.trim()))
        return setError(
          t('Group ID must contain 1–40 digits.', 'Group ID ต้องเป็นตัวเลข 1–40 หลัก'),
        );
      if (!group || (facebookGroupId.trim() && group.facebookId !== facebookGroupId.trim()))
        return setError(
          t(
            'The Group ID is not linked to this store. Enter it again.',
            'Group ID ยังไม่เชื่อมกับร้านค้านี้ กรุณาระบุใหม่',
          ),
        );
    }
    if (url.trim() && !safeUrl(url.trim()))
      return setError(
        t(
          'Use a valid link that starts with https://.',
          'ใช้ลิงก์ที่ถูกต้องและขึ้นต้นด้วย https://',
        ),
      );
    if (facebookPostId.trim() && !/^\d{1,40}$/.test(facebookPostId.trim()))
      return setError(
        t(
          'Facebook Post ID must contain 1–40 digits.',
          'Post ID ของ Facebook ต้องเป็นตัวเลข 1–40 หลัก',
        ),
      );
    if (platform === 'facebook' && url.trim()) {
      const ids = parseFacebookGroupPostUrl(url.trim());
      if (postType === 'page' && ids)
        return setError(
          t(
            'This is a Group post link. Select Group or add a Page post link.',
            'ลิงก์นี้เป็นโพสต์ในกลุ่ม เลือกกลุ่มหรือใส่ลิงก์โพสต์บนเพจ',
          ),
        );
      if (
        ids &&
        ((group?.facebookId && ids.groupId !== group.facebookId) ||
          (facebookPostId.trim() && ids.postId !== facebookPostId.trim()))
      )
        return setError(
          t(
            'The Facebook IDs do not match the pasted post URL.',
            'Facebook ID ไม่ตรงกับลิงก์โพสต์ที่วาง',
          ),
        );
    }
    if (Date.parse(candidate.publishedAt) > Date.now())
      return setError(
        t('Publication date cannot be in the future.', 'วันที่เผยแพร่ต้องไม่อยู่ในอนาคต'),
      );
    if (publicationStatus === 'published' && !generatedUrl && !existingWithoutLink)
      return setError(
        platform === 'facebook' && postType === 'group'
          ? t(
              'Add a Group post link, or enter Group ID and Post ID.',
              'เพิ่มลิงก์โพสต์ในกลุ่ม หรือระบุ Group ID และ Post ID',
            )
          : t('Add the published post URL.', 'เพิ่มลิงก์โพสต์ที่เผยแพร่'),
      );
    if (
      viewersInput.trim() !== '' &&
      (!/^\d+$/.test(viewersInput.trim()) || !Number.isSafeInteger(Number(viewersInput.trim())))
    )
      return setError(
        t(
          'Viewers must be a whole number of zero or more.',
          'จำนวนผู้ชมต้องเป็นจำนวนเต็มตั้งแต่ศูนย์ขึ้นไป',
        ),
      );
    savingRef.current = true;
    setSaving(true);
    try {
      await onSave(
        {
          ...candidate,
          id: post?.id || crypto.randomUUID(),
        },
        platform === 'facebook' && postType === 'group' ? pendingGroup : null,
      );
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : t(
              'This post could not be saved. Please try again.',
              'บันทึกโพสต์ไม่สำเร็จ กรุณาลองอีกครั้ง',
            ),
      );
      savingRef.current = false;
      setSaving(false);
    }
  }

  async function deletePost() {
    if (!post?.id || savingRef.current || confirmingDiscard) return;
    savingRef.current = true;
    setDeleting(true);
    setError('');
    try {
      // Delete the saved record, without submitting unsaved form fields or a pending group.
      if (await onDelete(post)) {
        onClose();
        return;
      }
      setError(
        t(
          'Could not delete this post. Your edits are still here. Please try again.',
          'ลบโพสต์ไม่สำเร็จ การแก้ไขของคุณยังอยู่ที่นี่ กรุณาลองอีกครั้ง',
        ),
      );
    } catch {
      setError(
        t('Could not delete this post. Please try again.', 'ลบโพสต์ไม่สำเร็จ กรุณาลองอีกครั้ง'),
      );
    }
    savingRef.current = false;
    setDeleting(false);
  }

  return (
    <dialog
      ref={dialog}
      className={`${styles.dialog} ${confirmingDiscard ? styles.confirmingDialog : ''}`}
      role={confirmingDiscard ? 'alertdialog' : 'dialog'}
      aria-modal="true"
      aria-labelledby={confirmingDiscard ? 'discard-changes-title' : 'post-editor-title'}
      aria-describedby={confirmingDiscard ? 'discard-changes-description' : undefined}
      aria-busy={saving || deleting || undefined}
      onCancel={(event) => {
        event.preventDefault();
        if (confirmingDiscard) keepEditing();
        else requestClose();
      }}
      onKeyDown={(event) => {
        if (!confirmingDiscard || event.key !== 'Tab') return;
        if (event.shiftKey && document.activeElement === keepEditingButton.current) {
          event.preventDefault();
          discardButton.current?.focus();
        } else if (!event.shiftKey && document.activeElement === discardButton.current) {
          event.preventDefault();
          keepEditingButton.current?.focus();
        }
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          const bounds = event.currentTarget.getBoundingClientRect();
          if (
            event.clientX < bounds.left ||
            event.clientX > bounds.right ||
            event.clientY < bounds.top ||
            event.clientY > bounds.bottom
          )
            requestClose();
        }
      }}
    >
      <div
        className={styles.editingContent}
        hidden={confirmingDiscard}
        onFocusCapture={(event) => {
          lastEditingFocus.current = event.target as HTMLElement;
        }}
      >
        <header className={styles.header}>
          <div>
            <span className={styles.eyebrow}>
              {publicationStatus === 'pending'
                ? t('PENDING POST', 'โพสต์ที่รอดำเนินการ')
                : t('PUBLISHED POST', 'โพสต์ที่เผยแพร่แล้ว')}
            </span>
            <h2 id="post-editor-title">
              {post?.id
                ? t('Edit tracked post', 'แก้ไขโพสต์ที่ติดตาม')
                : t('Add post', 'เพิ่มโพสต์')}
            </h2>
            <p>
              {post?.metaSourceRow
                ? t(
                    'Add missing details when available. Meta row details are kept below.',
                    'เพิ่มข้อมูลที่ยังไม่ทราบภายหลังได้ และดูข้อมูลจากแถว Meta ด้านล่าง',
                  )
                : t(
                    'Record the link, actual publication date, and Viewers.',
                    'บันทึกลิงก์ วันที่เผยแพร่จริง และยอดผู้ชม',
                  )}
            </p>
          </div>
          <button
            className={styles.iconButton}
            type="button"
            aria-label={t('Close editor', 'ปิดหน้าต่างแก้ไข')}
            onClick={requestClose}
            disabled={saving || deleting}
          >
            <X size={22} />
          </button>
        </header>
        <form ref={form} onSubmit={submit} className={styles.form}>
          <div className={styles.body}>
            <div className={styles.fields}>
              <div className={styles.pair}>
                <label>
                  {t('Store', 'ร้านค้า')}
                  <select
                    value={selectedStore}
                    required
                    onChange={(event) => {
                      setSelectedStore(event.target.value);
                      setGroupId('');
                      resetPostLink(
                        t(
                          'Store changed. The previous group, Post ID, and link were cleared. Add the details for this store.',
                          'เปลี่ยนร้านค้าแล้ว ระบบล้างกลุ่ม Post ID และลิงก์เดิม กรุณาระบุข้อมูลสำหรับร้านค้านี้',
                        ),
                      );
                    }}
                  >
                    <option value="" disabled>
                      {t('Choose a store', 'เลือกร้านค้า')}
                    </option>
                    {sortCatalog(data.stores).map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  {t('Platform', 'แพลตฟอร์ม')}
                  <select
                    value={platform}
                    onChange={(event) => {
                      setPlatform(event.target.value as Platform);
                      setGroupId('');
                      resetPostLink(
                        t(
                          'Platform changed. The previous Post ID and link were cleared. Add the link for this platform.',
                          'เปลี่ยนแพลตฟอร์มแล้ว ระบบล้าง Post ID และลิงก์เดิม กรุณาเพิ่มลิงก์สำหรับแพลตฟอร์มนี้',
                        ),
                      );
                    }}
                  >
                    <option value="facebook">Facebook</option>
                    <option value="instagram">Instagram</option>
                    <option value="tiktok">TikTok</option>
                    <option value="linkedin">LinkedIn</option>
                  </select>
                </label>
              </div>
              <div className={platform === 'facebook' ? styles.pair : undefined}>
                <label>
                  {t('Post status', 'สถานะโพสต์')}
                  <select
                    value={publicationStatus}
                    onChange={(event) =>
                      setPublicationStatus(event.target.value as 'published' | 'pending')
                    }
                  >
                    <option value="published">{t('Published', 'เผยแพร่แล้ว')}</option>
                    <option value="pending">{t('Pending', 'รอดำเนินการ')}</option>
                  </select>
                </label>
                {platform === 'facebook' && (
                  <label>
                    {t('Post type', 'ประเภทโพสต์')}
                    <select
                      value={postType}
                      onChange={(event) => updatePostType(event.target.value as FacebookPostType)}
                    >
                      <option value="group">{t('Group', 'กลุ่ม')}</option>
                      <option value="page">{t('Page', 'เพจ')}</option>
                    </select>
                  </label>
                )}
              </div>
              {platform === 'facebook' && (
                <p className={`${styles.helper} ${styles.postTypeHint}`}>
                  {postType === 'group'
                    ? t(
                        'Paste a Group post URL to fill both IDs, or enter them manually below.',
                        'วางลิงก์โพสต์ในกลุ่มเพื่อกรอก ID ทั้งสองอัตโนมัติ หรือระบุเองด้านล่าง',
                      )
                    : publicationStatus === 'pending'
                      ? t(
                          'Add the Facebook Page post URL when available.',
                          'เพิ่มลิงก์โพสต์บนเพจ Facebook เมื่อมีข้อมูล',
                        )
                      : t(
                          'Add the published Facebook Page post URL.',
                          'เพิ่มลิงก์โพสต์บนเพจ Facebook ที่เผยแพร่แล้ว',
                        )}
                </p>
              )}
              {post?.metaSourceRow && (
                <div className={styles.metaSourceNote}>
                  <div className={styles.metaSourceHeading}>
                    <span>
                      {t(`Meta row ${post.metaSourceRow}`, `แถว Meta ${post.metaSourceRow}`)}
                    </span>
                    {publicationStatus === 'pending' && (
                      <span className={styles.pendingBadge}>{t('Pending', 'รอดำเนินการ')}</span>
                    )}
                  </div>
                  <p>
                    {publicationStatus === 'pending'
                      ? t(
                          'Select Published and add the confirmed publication date when available.',
                          'เลือกเผยแพร่แล้วและระบุวันที่เผยแพร่ที่ยืนยันแล้วเมื่อมีข้อมูล',
                        )
                      : post.metaPublishedLabel && !publishedAt
                        ? t(
                            `Meta showed “${post.metaPublishedLabel}” without a full date. Add the year when known.`,
                            `Meta แสดง “${post.metaPublishedLabel}” โดยไม่มีวันที่ครบถ้วน เพิ่มปีเมื่อทราบ`,
                          )
                        : t(
                            'Keep the original Meta row as a reference while completing this post.',
                            'ใช้แถว Meta เดิมเป็นข้อมูลอ้างอิงระหว่างเติมรายละเอียดโพสต์',
                          )}
                  </p>
                  {post.metaGroupKey && (
                    <p className={styles.metaGroupKey}>
                      {t('Group ID / slug', 'Group ID / ชื่อย่อ')}: {post.metaGroupKey}
                    </p>
                  )}
                </div>
              )}
              <label>
                {t('Product / campaign', 'สินค้า / แคมเปญ')}
                <input
                  ref={productInput}
                  list="post-product-catalog"
                  value={product}
                  onChange={(event) => setProduct(event.target.value)}
                  maxLength={200}
                  placeholder={t('e.g. New collection', 'เช่น คอลเลกชันใหม่')}
                />
                <datalist id="post-product-catalog">
                  {sortCatalog(storeProducts).map((item) => (
                    <option key={item.id} value={item.name} />
                  ))}
                </datalist>
              </label>
              <div className={styles.dateFields}>
                <label>
                  {t('Published on', 'วันที่เผยแพร่')}
                  <input
                    type="datetime-local"
                    value={publicationStatus === 'pending' ? '' : publishedAt}
                    disabled={publicationStatus === 'pending'}
                    required={publicationStatus === 'published'}
                    max={bangkokDateTime(new Date().toISOString())}
                    aria-describedby="post-publication-hint"
                    onChange={(event) => setPublishedAt(event.target.value)}
                  />
                </label>
                <p className={styles.helper} id="post-publication-hint">
                  <CalendarDays size={16} />
                  {publicationStatus === 'pending'
                    ? t(
                        'Pending posts are saved without a publication date. Select Published to add it.',
                        'โพสต์ที่รอดำเนินการจะบันทึกโดยไม่มีวันที่เผยแพร่ เลือกเผยแพร่แล้วเพื่อระบุวันที่',
                      )
                    : t(
                        'Required for Published · Actual publication time in Bangkok (UTC+7).',
                        'จำเป็นสำหรับสถานะเผยแพร่แล้ว · เวลาที่เผยแพร่จริงในกรุงเทพฯ (UTC+7)',
                      )}
                </p>
              </div>
              <section className={styles.section} aria-labelledby="post-link-title">
                <h3 id="post-link-title">
                  <Link2 size={18} />
                  {t('Post link', 'ลิงก์โพสต์')}
                </h3>
                {linkNotice && (
                  <p className={styles.linkNotice} role="status">
                    {linkNotice}
                  </p>
                )}
                {existingWithoutLink && (
                  <p className={styles.helper}>
                    {t(
                      'Post link: Null. Add it when available; you can still save this record.',
                      'ลิงก์โพสต์: Null เพิ่มได้เมื่อมีข้อมูล และยังบันทึกรายการนี้ได้',
                    )}
                  </p>
                )}
                <label>
                  {publicationStatus === 'pending'
                    ? t('Post URL (when available)', 'ลิงก์โพสต์ (เมื่อมี)')
                    : t('Published post URL', 'ลิงก์โพสต์ที่เผยแพร่')}
                  <input
                    ref={linkInput}
                    type="url"
                    value={url}
                    onChange={(event) => updatePostUrl(event.target.value)}
                    placeholder="https://"
                    maxLength={2048}
                    required={
                      publicationStatus === 'published' &&
                      !existingWithoutLink &&
                      !(
                        platform === 'facebook' &&
                        postType === 'group' &&
                        canonicalPostUrl(group?.facebookId ?? '', facebookPostId.trim())
                      )
                    }
                  />
                </label>
                {idsInUrl && (
                  <div className={styles.detectedIds} role="status">
                    <Check size={16} aria-hidden="true" />
                    <span>
                      {t('Group ID', 'Group ID')} <strong>{idsInUrl.groupId}</strong>
                    </span>
                    <span>
                      {t('Post ID', 'Post ID')} <strong>{idsInUrl.postId}</strong>
                    </span>
                    {group && (
                      <small>
                        {pendingGroup?.id === groupId
                          ? matchedGroupName
                            ? t(
                                `Matched your group list: ${matchedGroupName}`,
                                `พบชื่อกลุ่มจากรายการ: ${matchedGroupName}`,
                              )
                            : t(
                                `New group will be saved as “${pendingGroup.name}”. Rename it in Groups later.`,
                                `จะบันทึกกลุ่มใหม่ชื่อ “${pendingGroup.name}” เปลี่ยนชื่อได้ในหน้ากลุ่มภายหลัง`,
                              )
                          : t(`Saved group: ${group.name}`, `กลุ่มที่บันทึกไว้: ${group.name}`)}
                      </small>
                    )}
                  </div>
                )}
                {linkReview.exactMatch && (
                  <div className={`${styles.linkReview} ${styles.exactLinkMatch}`} role="alert">
                    <div className={styles.linkReviewHeading}>
                      <TriangleAlert size={18} aria-hidden="true" />
                      <strong>
                        {t('This post is already tracked', 'โพสต์นี้ถูกติดตามอยู่แล้ว')}
                      </strong>
                    </div>
                    <p>
                      {linkReview.exactMatch.deletedAt
                        ? t(
                            'The same post is in Trash. Restore that record before adding this link.',
                            'โพสต์เดียวกันอยู่ในถังขยะ กรุณากู้คืนรายการเดิมก่อนเพิ่มลิงก์นี้',
                          )
                        : t(
                            'This link or Post ID belongs to an existing record. Open it instead of creating a duplicate.',
                            'ลิงก์หรือ Post ID นี้เป็นของรายการเดิม เปิดรายการนั้นแทนการสร้างซ้ำ',
                          )}
                    </p>
                    <span className={styles.linkReviewDetail}>
                      {linkReview.exactMatch.product || 'Null'}
                      {linkReview.exactMatch.metaSourceRow
                        ? ` · ${t(`Meta row ${linkReview.exactMatch.metaSourceRow}`, `แถว Meta ${linkReview.exactMatch.metaSourceRow}`)}`
                        : ''}
                    </span>
                    {!linkReview.exactMatch.deletedAt && (
                      <button
                        type="button"
                        className={styles.reviewPostButton}
                        onClick={() => openExistingPost(linkReview.exactMatch!)}
                      >
                        {t('Open existing record', 'เปิดรายการเดิม')}
                      </button>
                    )}
                  </div>
                )}
                {!linkReview.exactMatch && linkReview.possibleMetaRows.length > 0 && (
                  <div className={styles.linkReview} role="status">
                    <div className={styles.linkReviewHeading}>
                      <TriangleAlert size={18} aria-hidden="true" />
                      <strong>
                        {t(
                          'Check existing Meta rows in this group',
                          'ตรวจสอบแถว Meta ที่มีอยู่ในกลุ่มนี้',
                        )}
                      </strong>
                    </div>
                    <p>
                      {t(
                        'A group may have several posts. If this link belongs to one of these rows, open it with the link filled in, review, then save.',
                        'หนึ่งกลุ่มอาจมีหลายโพสต์ หากลิงก์นี้เป็นของแถวใด ให้เปิดแถวนั้นโดยระบบจะใส่ลิงก์ให้ ตรวจสอบแล้วจึงบันทึก',
                      )}
                    </p>
                    <ul className={styles.possibleMetaRows}>
                      {linkReview.possibleMetaRows.map((row) => (
                        <li key={row.id}>
                          <span>
                            <strong>
                              {t(`Meta row ${row.metaSourceRow}`, `แถว Meta ${row.metaSourceRow}`)}
                            </strong>
                            <small>
                              {postPublicationStatus(row) === 'pending'
                                ? t('Pending', 'รอดำเนินการ')
                                : t('Published', 'เผยแพร่แล้ว')}{' '}
                              · {row.metaPublishedLabel || t('Date: Null', 'วันที่: Null')} ·{' '}
                              {row.viewers === null ? 'Null' : row.viewers} {t('Viewers', 'ผู้ชม')}
                            </small>
                          </span>
                          <button
                            type="button"
                            className={styles.reviewPostButton}
                            onClick={() => openExistingPost(row, generatedUrl)}
                          >
                            {t('Use this row', 'ใช้แถวนี้')}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {platform === 'facebook' && postType === 'group' && (
                  <div className={styles.facebookIds}>
                    <p className={styles.facebookIdsTitle}>{t('Facebook IDs', 'Facebook ID')}</p>
                    <div className={styles.pair}>
                      <label>
                        {t('Group ID', 'Group ID')}
                        <input
                          value={facebookGroupId}
                          type="text"
                          inputMode="numeric"
                          onChange={(event) => updateGroupId(event.target.value)}
                          placeholder="878540877111439"
                          maxLength={100}
                        />
                      </label>
                      <label>
                        {t('Post ID', 'Post ID')}
                        <input
                          value={facebookPostId}
                          type="text"
                          inputMode="numeric"
                          onChange={(event) => setFacebookPostId(event.target.value)}
                          placeholder="123456789012345"
                          maxLength={100}
                        />
                      </label>
                    </div>
                  </div>
                )}
                {platform === 'facebook' && postType === 'group' && !idsInUrl && group && (
                  <p className={styles.groupIdentity} role="status">
                    {pendingGroup?.id === groupId
                      ? matchedGroupName
                        ? t(
                            `Matched your group list: ${matchedGroupName}`,
                            `พบชื่อกลุ่มจากรายการ: ${matchedGroupName}`,
                          )
                        : t(
                            `New group will be saved as “${pendingGroup.name}”. Rename it in Groups later.`,
                            `จะบันทึกกลุ่มใหม่ชื่อ “${pendingGroup.name}” เปลี่ยนชื่อได้ในหน้ากลุ่มภายหลัง`,
                          )
                      : t(`Saved group: ${group.name}`, `กลุ่มที่บันทึกไว้: ${group.name}`)}
                  </p>
                )}
                {!!generatedUrl && (
                  <a
                    className={styles.generatedLink}
                    href={generatedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <span>{generatedUrl}</span>
                    <ArrowUpRight size={17} />
                  </a>
                )}
              </section>
              <section className={styles.section} aria-labelledby="viewers-title">
                <div className={styles.sectionHeader}>
                  <h3 id="viewers-title">
                    <Eye size={18} />
                    {t('Current Viewers total', 'ยอดผู้ชมล่าสุด')}
                  </h3>
                </div>
                <p className={styles.helper}>
                  {publicationStatus === 'pending'
                    ? t(
                        'This total is excluded from published performance until a publication date is saved.',
                        'ยอดนี้จะไม่นับรวมในผลลัพธ์ของโพสต์ที่เผยแพร่แล้วจนกว่าจะบันทึกวันที่เผยแพร่',
                      )
                    : t(
                        'Enter the latest total shown on the post. Updating it replaces the previous total.',
                        'ใส่ยอดผู้ชมสะสมล่าสุดของโพสต์ เมื่ออัปเดต ระบบจะแทนที่ยอดเดิม',
                      )}
                </p>
                <label>
                  {t('Total Viewers', 'ผู้ชมสะสม')}
                  <input
                    type="text"
                    inputMode="numeric"
                    value={viewersInput}
                    onChange={(event) => setViewersInput(event.target.value)}
                    placeholder="0"
                  />
                </label>
              </section>
            </div>
          </div>
          <footer className={styles.footer}>
            {error && (
              <p role="alert" className={styles.error}>
                {error}
              </p>
            )}
            <div className={styles.footerActions}>
              {post?.id ? (
                <button
                  type="button"
                  className={styles.deleteButton}
                  onClick={deletePost}
                  disabled={saving || deleting}
                  title={t('Recover from Trash for 30 days', 'กู้คืนจากถังขยะได้ภายใน 30 วัน')}
                >
                  {deleting ? t('Deleting…', 'กำลังลบ…') : t('Delete post', 'ลบโพสต์')}
                </button>
              ) : (
                <span>{t('Stored in this browser', 'จัดเก็บในเบราว์เซอร์นี้')}</span>
              )}
              <button
                type="button"
                className={styles.cancelButton}
                onClick={requestClose}
                disabled={saving || deleting}
              >
                {t('Cancel', 'ยกเลิก')}
              </button>
              <button
                type="submit"
                disabled={saving || deleting || Boolean(linkReview.exactMatch)}
                className={`${styles.saveButton} ${linkReview.exactMatch ? styles.duplicateDisabled : ''}`}
              >
                <Check size={18} />
                {saving
                  ? t('Saving…', 'กำลังบันทึก…')
                  : t('Save tracked post', 'บันทึกโพสต์ที่ติดตาม')}
              </button>
            </div>
          </footer>
        </form>
      </div>
      {confirmingDiscard && (
        <section className={styles.discardPanel}>
          <div className={styles.discardIcon} aria-hidden="true">
            <TriangleAlert size={26} />
          </div>
          <span className={styles.eyebrow}>
            {t('UNSAVED CHANGES', 'มีการเปลี่ยนแปลงที่ยังไม่ได้บันทึก')}
          </span>
          <h2 id="discard-changes-title">
            {reviewTarget
              ? t('Open the existing record?', 'เปิดรายการเดิมหรือไม่?')
              : t('Keep these changes?', 'เก็บการเปลี่ยนแปลงนี้ไว้ไหม?')}
          </h2>
          <p id="discard-changes-description">
            {reviewTarget
              ? t(
                  'Your changes here are not saved. Discard them to open the existing record, or keep editing this one.',
                  'การแก้ไขรายการนี้ยังไม่ถูกบันทึก ทิ้งการแก้ไขเพื่อเปิดรายการเดิม หรือแก้ไขรายการนี้ต่อ',
                )
              : t(
                  'Your changes have not been saved. Keep editing to save them, or discard these changes and close the editor.',
                  'การเปลี่ยนแปลงของคุณยังไม่ได้บันทึก เลือกแก้ไขต่อเพื่อบันทึก หรือทิ้งการเปลี่ยนแปลงและปิดหน้าต่างนี้',
                )}
          </p>
          <div className={styles.discardActions}>
            <button
              ref={keepEditingButton}
              type="button"
              className={styles.saveButton}
              onClick={keepEditing}
            >
              {t('Keep editing', 'แก้ไขต่อ')}
            </button>
            <button
              ref={discardButton}
              type="button"
              className={styles.discardButton}
              onClick={discardChanges}
            >
              {reviewTarget
                ? t('Discard and open', 'ทิ้งแล้วเปิดรายการเดิม')
                : t('Discard changes', 'ทิ้งการเปลี่ยนแปลง')}
            </button>
          </div>
        </section>
      )}
    </dialog>
  );
}
