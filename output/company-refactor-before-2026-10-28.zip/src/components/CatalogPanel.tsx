'use client';

import {
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from 'react';
import { createPortal } from 'react-dom';
import { Check, GripVertical, Package, Pencil, Plus, Search, X } from 'lucide-react';
import {
  MAX_SORT_ORDER,
  nextSortOrder,
  reorderStores,
  sortCatalog,
  validSortOrder,
} from '@/lib/catalog';
import { safeCatalogImageUrl, validateWorkspace } from '@/lib/data';
import { entityEditIsCurrent } from '@/lib/entity-edit';
import { retainCloudinaryImage } from '@/lib/cloudinary-media';
import { productStoreIdMap } from '@/lib/product-store';
import type { Product, Store, Translate, Workspace } from '@/lib/types';
import styles from './WorkspacePanels.module.css';

interface Props {
  kind: 'products' | 'stores';
  data: Workspace;
  storeId: string;
  update: (next: Workspace) => Promise<boolean>;
  t: Translate;
  notify: (message: string) => void;
}
interface Draft {
  id: string;
  name: string;
  imageUrl: string;
  ownerName: string;
  sortOrder: string;
  storeIds: string[];
}
interface StoreDragSession {
  id: string;
  pointerId: number;
  handle: HTMLButtonElement;
  startX: number;
  startY: number;
  x: number;
  y: number;
  active: boolean;
  targetId: string | null;
}

function CatalogImage({ url, name, product }: { url: string; name: string; product: boolean }) {
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  return (
    <span className={product ? styles.productImage : styles.storeAvatar}>
      {url && safeCatalogImageUrl(url) && failedUrl !== url ? (
        <img
          src={url}
          alt=""
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailedUrl(url)}
        />
      ) : product ? (
        <Package size={32} aria-hidden="true" />
      ) : (
        <span aria-hidden="true">{name.trim().slice(0, 2).toUpperCase() || 'V'}</span>
      )}
    </span>
  );
}

/** Both catalogs use the same validated, revision-checked workspace repository. */
export default function CatalogPanel({ kind, data, update, t, notify, storeId }: Props) {
  const isProduct = kind === 'products';
  const [draft, setDraft] = useState<Draft | null>(null);
  const [baseline, setBaseline] = useState<Product | Store | null>(null);
  const [query, setQuery] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [draggingStoreId, setDraggingStoreId] = useState<string | null>(null);
  const [dropTargetId, setDropTargetId] = useState<string | null>(null);
  const [orderMessage, setOrderMessage] = useState('');
  const busyRef = useRef(false);
  const storeGridRef = useRef<HTMLDivElement>(null);
  const dragSessionRef = useRef<StoreDragSession | null>(null);
  const dragGhostRef = useRef<HTMLDivElement>(null);
  const autoScrollFrameRef = useRef<number | null>(null);
  const beforeReorderRef = useRef<Map<string, DOMRect> | null>(null);
  const reorderAnimationsRef = useRef<Map<string, Animation>>(new Map());
  const editorRef = useRef<HTMLFormElement>(null);
  const addButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const closeEditor = () => {
    setDraft(null);
    setError('');
    requestAnimationFrame(() => {
      const target = previousFocus.current;
      if (target?.isConnected) target.focus();
      else addButtonRef.current?.focus();
    });
  };
  const productStoresById = useMemo(
    () => productStoreIdMap(data.products, data.posts),
    [data.products, data.posts],
  );
  const items: (Product | Store)[] = isProduct
    ? data.products.filter((item) => !item.deletedAt)
    : data.stores;
  const visible = sortCatalog(items).filter((item) => {
    const productStores = 'imageUrl' in item ? (productStoresById.get(item.id) ?? []) : [];
    if ('imageUrl' in item && storeId !== 'all' && !productStores.includes(storeId)) return false;
    const storeNames = productStores
      .map((id) => data.stores.find((store) => store.id === id)?.name ?? '')
      .join(' ');
    return `${item.name} ${'ownerName' in item ? item.ownerName : ''} ${storeNames}`
      .toLocaleLowerCase()
      .includes(query.trim().toLocaleLowerCase());
  });
  const canReorderStores = !isProduct && data.stores.length > 1 && !draft && !busy && !query.trim();
  const clearDrag = () => {
    const session = dragSessionRef.current;
    dragSessionRef.current = null;
    if (autoScrollFrameRef.current !== null) {
      cancelAnimationFrame(autoScrollFrameRef.current);
      autoScrollFrameRef.current = null;
    }
    if (session?.handle.hasPointerCapture(session.pointerId))
      session.handle.releasePointerCapture(session.pointerId);
    setDraggingStoreId(null);
    setDropTargetId(null);
  };
  useEffect(() => {
    const onEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape' || !dragSessionRef.current) return;
      event.preventDefault();
      clearDrag();
      setOrderMessage(t('Store move canceled.', 'ยกเลิกการย้ายร้านค้าแล้ว'));
    };
    window.addEventListener('keydown', onEscape);
    return () => window.removeEventListener('keydown', onEscape);
  });
  useEffect(
    () => () => {
      if (autoScrollFrameRef.current !== null) cancelAnimationFrame(autoScrollFrameRef.current);
      const session = dragSessionRef.current;
      dragSessionRef.current = null;
      if (session?.handle.hasPointerCapture(session.pointerId))
        session.handle.releasePointerCapture(session.pointerId);
    },
    [],
  );
  useLayoutEffect(() => {
    const before = beforeReorderRef.current;
    if (!before || isProduct) return;
    beforeReorderRef.current = null;
    for (const animation of reorderAnimationsRef.current.values()) animation.cancel();
    reorderAnimationsRef.current.clear();
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    storeGridRef.current?.querySelectorAll<HTMLElement>('[data-store-card-id]').forEach((card) => {
      const oldRect = before.get(card.dataset.storeCardId ?? '');
      if (!oldRect) return;
      const nextRect = card.getBoundingClientRect();
      const x = oldRect.left - nextRect.left;
      const y = oldRect.top - nextRect.top;
      if (Math.abs(x) < 1 && Math.abs(y) < 1) return;
      const animation = card.animate(
        [{ transform: `translate3d(${x}px, ${y}px, 0)` }, { transform: 'translate3d(0, 0, 0)' }],
        { duration: 250, easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)' },
      );
      const id = card.dataset.storeCardId ?? '';
      reorderAnimationsRef.current.set(id, animation);
      animation.onfinish = () => {
        if (reorderAnimationsRef.current.get(id) === animation)
          reorderAnimationsRef.current.delete(id);
      };
    });
  }, [data.stores, isProduct]);
  const findDropTarget = (x: number, y: number): string | null => {
    const grid = storeGridRef.current;
    if (!grid) return null;
    const bounds = grid.getBoundingClientRect();
    if (
      x < bounds.left - 24 ||
      x > bounds.right + 24 ||
      y < bounds.top - 24 ||
      y > bounds.bottom + 24
    )
      return null;
    const direct = (document.elementFromPoint(x, y) as HTMLElement | null)?.closest<HTMLElement>(
      '[data-store-card-id]',
    );
    if (direct && grid.contains(direct)) return direct.dataset.storeCardId ?? null;
    let closest: string | null = null;
    let distance = Infinity;
    grid.querySelectorAll<HTMLElement>('[data-store-card-id]').forEach((card) => {
      const rect = card.getBoundingClientRect();
      const squared =
        (x - (rect.left + rect.right) / 2) ** 2 + (y - (rect.top + rect.bottom) / 2) ** 2;
      if (squared < distance) {
        distance = squared;
        closest = card.dataset.storeCardId ?? null;
      }
    });
    return closest;
  };
  const moveGhost = (x: number, y: number) => {
    const ghost = dragGhostRef.current;
    if (!ghost) return;
    const width = Math.min(272, window.innerWidth - 24);
    ghost.style.left = `${Math.max(12, Math.min(x + 12, window.innerWidth - width - 12))}px`;
    ghost.style.top = `${Math.max(12, Math.min(y + 12, window.innerHeight - 76))}px`;
  };
  const updateDropTarget = (session: StoreDragSession) => {
    const target = findDropTarget(session.x, session.y);
    const targetId = target === session.id ? null : target;
    if (targetId !== session.targetId) {
      session.targetId = targetId;
      setDropTargetId(targetId);
    }
  };
  const autoScroll = () => {
    autoScrollFrameRef.current = null;
    const session = dragSessionRef.current;
    if (!session?.active) return;
    const edge = Math.min(96, Math.max(48, window.innerHeight * 0.15));
    const speed =
      session.y < edge
        ? -Math.min(18, ((edge - session.y) / edge) * 18)
        : session.y > window.innerHeight - edge
          ? Math.min(18, ((session.y - (window.innerHeight - edge)) / edge) * 18)
          : 0;
    if (!speed) return;
    const previousScroll = window.scrollY;
    window.scrollBy(0, speed);
    updateDropTarget(session);
    if (window.scrollY === previousScroll) return;
    autoScrollFrameRef.current = requestAnimationFrame(autoScroll);
  };
  const saveStoreOrder = async (sourceId: string, targetId: string) => {
    if (busyRef.current || draft || query.trim() || isProduct || sourceId === targetId) return;
    const ordered = sortCatalog(data.stores);
    const targetIndex = ordered.findIndex((store) => store.id === targetId);
    const source = ordered.find((store) => store.id === sourceId);
    if (!source || targetIndex < 0) return;
    const stores = reorderStores(data.stores, sourceId, targetId);
    beforeReorderRef.current = new Map(
      [...(storeGridRef.current?.querySelectorAll<HTMLElement>('[data-store-card-id]') ?? [])].map(
        (card) => [card.dataset.storeCardId ?? '', card.getBoundingClientRect()],
      ),
    );
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      if (!(await update({ ...data, stores }))) {
        beforeReorderRef.current = null;
        setError(
          t(
            'Could not save the store order. Try again.',
            'บันทึกลำดับร้านค้าไม่สำเร็จ โปรดลองอีกครั้ง',
          ),
        );
        return;
      }
      const position = stores.findIndex((store) => store.id === sourceId) + 1;
      setOrderMessage(
        t(
          `${source.name} is now position ${position} of ${stores.length}.`,
          `${source.name} อยู่ลำดับที่ ${position} จาก ${stores.length} ร้านค้า`,
        ),
      );
      notify(t('Store order saved.', 'บันทึกลำดับร้านค้าแล้ว'));
    } catch {
      beforeReorderRef.current = null;
      setError(
        t(
          'Could not save the store order. Try again.',
          'บันทึกลำดับร้านค้าไม่สำเร็จ โปรดลองอีกครั้ง',
        ),
      );
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  };
  const startStoreDrag = (event: ReactPointerEvent<HTMLButtonElement>, id: string) => {
    if (
      !canReorderStores ||
      busyRef.current ||
      dragSessionRef.current ||
      (event.pointerType === 'mouse' && event.button !== 0)
    )
      return;
    event.currentTarget.focus();
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    dragSessionRef.current = {
      id,
      pointerId: event.pointerId,
      handle: event.currentTarget,
      startX: event.clientX,
      startY: event.clientY,
      x: event.clientX,
      y: event.clientY,
      active: false,
      targetId: null,
    };
  };
  const moveStoreDrag = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const session = dragSessionRef.current;
    if (!session || session.pointerId !== event.pointerId) return;
    session.x = event.clientX;
    session.y = event.clientY;
    if (!session.active) {
      if (Math.hypot(session.x - session.startX, session.y - session.startY) < 7) return;
      session.active = true;
      setDraggingStoreId(session.id);
      setError('');
    }
    event.preventDefault();
    moveGhost(session.x, session.y);
    updateDropTarget(session);
    if (autoScrollFrameRef.current === null)
      autoScrollFrameRef.current = requestAnimationFrame(autoScroll);
  };
  const endStoreDrag = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const session = dragSessionRef.current;
    if (!session || session.pointerId !== event.pointerId) return;
    const target = session.active ? findDropTarget(event.clientX, event.clientY) : null;
    clearDrag();
    if (target && target !== session.id) void saveStoreOrder(session.id, target);
  };
  const cancelStoreDrag = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const session = dragSessionRef.current;
    if (session?.pointerId === event.pointerId && session.handle === event.currentTarget)
      clearDrag();
  };
  const moveStoreWithKeyboard = (event: ReactKeyboardEvent<HTMLButtonElement>, id: string) => {
    if (!canReorderStores || busyRef.current) return;
    const direction =
      event.key === 'ArrowUp' || event.key === 'ArrowLeft'
        ? -1
        : event.key === 'ArrowDown' || event.key === 'ArrowRight'
          ? 1
          : 0;
    if (!direction) return;
    event.preventDefault();
    const ordered = sortCatalog(data.stores);
    const index = ordered.findIndex((store) => store.id === id);
    const target = ordered[index + direction];
    if (target) void saveStoreOrder(id, target.id);
  };
  const begin = (item?: Product | Store) => {
    if (busyRef.current || dragSessionRef.current) return;
    previousFocus.current = document.activeElement as HTMLElement | null;
    setBaseline(item ? { ...item } : null);
    setDraft({
      id: item?.id ?? crypto.randomUUID(),
      name: item?.name ?? '',
      imageUrl: item ? ('imageUrl' in item ? item.imageUrl : item.logoImageUrl) : '',
      ownerName: item && 'ownerName' in item ? item.ownerName : '',
      sortOrder: String(item?.sortOrder ?? nextSortOrder(items)),
      storeIds:
        item && 'imageUrl' in item
          ? (productStoresById.get(item.id) ?? [])
          : storeId !== 'all' && data.stores.some((store) => store.id === storeId)
            ? [storeId]
            : data.stores.length === 1
              ? [data.stores[0].id]
              : [],
    });
    setError('');
    requestAnimationFrame(() => {
      editorRef.current?.scrollIntoView({ block: 'start' });
      editorRef.current?.querySelector<HTMLInputElement>('input')?.focus({ preventScroll: true });
    });
  };

  const commit = async (deleting = false) => {
    if (!draft || busyRef.current) return;
    const current = (isProduct ? data.products : data.stores).find((item) => item.id === draft.id);
    if (!entityEditIsCurrent<Product | Store>(baseline, current)) {
      setError(
        t(
          'This item changed in another tab. Your edits are still here; reopen the latest item before saving.',
          'รายการนี้ถูกแก้ไขในแท็บอื่น การแก้ไขของคุณยังอยู่ที่นี่ โปรดเปิดรายการล่าสุดก่อนบันทึก',
        ),
      );
      return;
    }
    const name = draft.name.trim();
    const imageUrl = draft.imageUrl.trim();
    const order = Number(draft.sortOrder);
    if (
      !deleting &&
      (!name || !draft.sortOrder.trim() || !validSortOrder(order) || !safeCatalogImageUrl(imageUrl))
    ) {
      setError(
        isProduct
          ? t(
              'Enter a name, an HTTPS image URL (or leave it blank), and a whole sort number from 0 to 1,000,000.',
              'กรอกชื่อ ลิงก์รูปภาพ HTTPS (หรือเว้นว่าง) และลำดับเป็นจำนวนเต็มตั้งแต่ 0 ถึง 1,000,000',
            )
          : t(
              'Enter a store name and an HTTPS logo URL (or leave it blank).',
              'กรอกชื่อร้านและลิงก์โลโก้ HTTPS (หรือเว้นว่าง)',
            ),
      );
      return;
    }
    if (isProduct && !deleting && draft.storeIds.length === 0) {
      setError(
        t(
          'Select at least one store for this product.',
          'เลือกร้านค้าอย่างน้อยหนึ่งร้านสำหรับสินค้านี้',
        ),
      );
      return;
    }
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      let next: Workspace;
      if (isProduct) {
        if (deleting && (!current || !('imageUrl' in current))) return;
        const product: Product = deleting
          ? { ...(current as Product), deletedAt: new Date().toISOString() }
          : {
              ...((baseline as Product | null) ?? {}),
              id: draft.id,
              name,
              imageUrl,
              sortOrder: order,
              storeIds: draft.storeIds,
              imageAsset: retainCloudinaryImage((baseline as Product | null)?.imageAsset, imageUrl),
            };
        next = {
          ...data,
          products: current
            ? data.products.map((item) => (item.id === product.id ? product : item))
            : [...data.products, product],
        };
      } else {
        const store: Store = {
          ...((baseline as Store | null) ?? {
            initials: name.slice(0, 2).toUpperCase(),
            color: '#263b4b',
            description: '',
          }),
          id: draft.id,
          name,
          logoImageUrl: imageUrl,
          logoAsset: retainCloudinaryImage((baseline as Store | null)?.logoAsset, imageUrl),
          ownerName: draft.ownerName.trim(),
          sortOrder: order,
        };
        next = {
          ...data,
          stores: current
            ? data.stores.map((item) => (item.id === store.id ? store : item))
            : [...data.stores, store],
        };
      }
      validateWorkspace(next);
      if (!(await update(next))) {
        setError(
          t(
            'Could not save. Your edits are still here. Try again after checking the workspace message.',
            'บันทึกไม่สำเร็จ การแก้ไขของคุณยังอยู่ โปรดตรวจสอบข้อความของพื้นที่ทำงานแล้วลองอีกครั้ง',
          ),
        );
        return;
      }
      setQuery('');
      closeEditor();
      notify(
        deleting
          ? t(
              'Product moved to Trash. Restore it within 30 days.',
              'ย้ายสินค้าไปถังขยะแล้ว กู้คืนได้ภายใน 30 วัน',
            )
          : isProduct
            ? t('Product saved.', 'บันทึกสินค้าแล้ว')
            : t('Store saved.', 'บันทึกร้านค้าแล้ว'),
      );
    } catch {
      setError(
        t(
          'Could not save this item. Check the fields and try again. Your edits are still here.',
          'บันทึกรายการไม่สำเร็จ ตรวจสอบข้อมูลแล้วลองอีกครั้ง การแก้ไขของคุณยังอยู่',
        ),
      );
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  };
  const save = (event: FormEvent) => {
    event.preventDefault();
    void commit();
  };

  return (
    <div className={styles.stack}>
      <div className={styles.toolbar}>
        <div>
          <h2>
            {isProduct ? t('Your products', 'สินค้าของคุณ') : t('Your stores', 'ร้านค้าของคุณ')}
          </h2>
          <p id={isProduct ? undefined : 'store-order-instructions'}>
            {isProduct
              ? t(
                  'Link each product to the stores that offer it.',
                  'เชื่อมสินค้าแต่ละรายการกับร้านค้าที่จำหน่าย',
                )
              : t(
                  'Drag the handle to reorder stores, or focus it and use arrow keys.',
                  'ลากปุ่มจับเพื่อจัดลำดับร้านค้า หรือใช้ปุ่มลูกศรเมื่อโฟกัสอยู่',
                )}
          </p>
        </div>
        <button
          ref={addButtonRef}
          className={styles.primaryButton}
          disabled={busy || !!draft}
          onClick={() => begin()}
        >
          <Plus size={19} />
          {isProduct ? t('Add product', 'เพิ่มสินค้า') : t('Add store', 'เพิ่มร้านค้า')}
        </button>
      </div>
      <label className={styles.search}>
        <Search size={19} aria-hidden="true" />
        <input
          aria-label={
            isProduct ? t('Search products', 'ค้นหาสินค้า') : t('Search stores', 'ค้นหาร้านค้า')
          }
          placeholder={
            isProduct
              ? t('Search products…', 'ค้นหาสินค้า…')
              : t('Search stores or owners…', 'ค้นหาร้านค้าหรือเจ้าของร้าน…')
          }
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
        <span>{visible.length}</span>
      </label>
      {!isProduct && query.trim() && (
        <p className={styles.reorderHint}>
          {t('Clear search to reorder stores.', 'ล้างคำค้นหาก่อนจัดลำดับร้านค้า')}
        </p>
      )}
      {!isProduct && !draft && error && (
        <p className={styles.error} role="alert">
          {error}
        </p>
      )}
      {!isProduct && (
        <span className={styles.visuallyHidden} role="status">
          {orderMessage}
        </span>
      )}
      {draft && (
        <form
          ref={editorRef}
          className={`${styles.editor} ${styles.catalogEditor}`}
          onSubmit={save}
          aria-busy={busy}
        >
          <div className={styles.sectionHeading}>
            <h3>
              {isProduct
                ? baseline
                  ? t('Edit product', 'แก้ไขสินค้า')
                  : t('Add product', 'เพิ่มสินค้า')
                : baseline
                  ? t('Edit store', 'แก้ไขร้านค้า')
                  : t('Add store', 'เพิ่มร้านค้า')}
            </h3>
            <button
              type="button"
              className={styles.iconButton}
              disabled={busy}
              aria-label={t('Close editor', 'ปิดการแก้ไข')}
              onClick={closeEditor}
            >
              <X size={20} />
            </button>
          </div>
          <fieldset className={`${styles.formGrid} ${styles.catalogFields}`} disabled={busy}>
            <legend className={styles.visuallyHidden}>
              {isProduct
                ? t('Product details', 'ข้อมูลสินค้า')
                : t('Store details', 'ข้อมูลร้านค้า')}
            </legend>
            <label className={isProduct ? styles.fullWidth : undefined}>
              {isProduct ? t('Product name', 'ชื่อสินค้า') : t('Store name', 'ชื่อร้านค้า')}
              <input
                required
                maxLength={isProduct ? 200 : 100}
                value={draft.name}
                onChange={(event) => setDraft({ ...draft, name: event.target.value })}
              />
            </label>
            {isProduct && (
              <fieldset className={`${styles.productStores} ${styles.fullWidth}`}>
                <legend>{t('Stores for this product', 'ร้านค้าของสินค้านี้')}</legend>
                <div className={styles.productStoreOptions}>
                  {sortCatalog(data.stores).map((store) => (
                    <label key={store.id} className={styles.productStoreOption}>
                      <input
                        type="checkbox"
                        checked={draft.storeIds.includes(store.id)}
                        onChange={(event) =>
                          setDraft({
                            ...draft,
                            storeIds: event.target.checked
                              ? [...draft.storeIds, store.id]
                              : draft.storeIds.filter((id) => id !== store.id),
                          })
                        }
                      />
                      <span>{store.name}</span>
                    </label>
                  ))}
                </div>
                <small>
                  {t(
                    'Select every store that offers this product.',
                    'เลือกร้านค้าทุกร้านที่จำหน่ายสินค้านี้',
                  )}
                </small>
              </fieldset>
            )}
            {!isProduct && (
              <label>
                {t('Owner name', 'ชื่อเจ้าของร้าน')}
                <input
                  maxLength={100}
                  value={draft.ownerName}
                  onChange={(event) => setDraft({ ...draft, ownerName: event.target.value })}
                />
              </label>
            )}
            <label>
              {isProduct ? t('Image URL', 'ลิงก์รูปสินค้า') : t('Logo image URL', 'ลิงก์รูปโลโก้')}
              <input
                type="text"
                inputMode="url"
                maxLength={2048}
                placeholder="https://…"
                value={draft.imageUrl}
                onChange={(event) => setDraft({ ...draft, imageUrl: event.target.value })}
              />
              <small>
                {t(
                  'Optional · use an HTTPS link or keep the supplied image path.',
                  'ไม่บังคับ · ใช้ลิงก์ HTTPS หรือเก็บพาธรูปภาพที่ให้มาไว้',
                )}
              </small>
            </label>
            {isProduct && (
              <label>
                {t('Sort order', 'ลำดับการแสดงผล')}
                <input
                  required
                  type="number"
                  min={0}
                  max={MAX_SORT_ORDER}
                  step={1}
                  value={draft.sortOrder}
                  onChange={(event) => setDraft({ ...draft, sortOrder: event.target.value })}
                />
                <small>{t('Lower numbers appear first.', 'ตัวเลขน้อยแสดงก่อน')}</small>
              </label>
            )}
          </fieldset>
          {error && (
            <p className={styles.error} role="alert">
              {error}
            </p>
          )}
          <div className={styles.formActions}>
            {isProduct && baseline && (
              <button
                type="button"
                className={styles.catalogDelete}
                disabled={busy}
                onClick={() => void commit(true)}
              >
                {t('Delete product', 'ลบสินค้า')}
              </button>
            )}
            <button
              type="button"
              className={styles.secondaryButton}
              disabled={busy}
              onClick={closeEditor}
            >
              {t('Cancel', 'ยกเลิก')}
            </button>
            <button type="submit" className={styles.primaryButton} disabled={busy}>
              <Check size={18} />
              {busy ? t('Saving…', 'กำลังบันทึก…') : t('Save', 'บันทึก')}
            </button>
          </div>
        </form>
      )}
      {visible.length ? (
        <div className={styles.cardGrid} ref={storeGridRef}>
          {visible.map((item, index) => (
            <article
              className={`${styles.storeCard} ${!isProduct && draggingStoreId === item.id ? styles.storeCardDragging : ''} ${!isProduct && dropTargetId === item.id ? styles.storeCardTarget : ''}`}
              key={item.id}
              data-store-card-id={isProduct ? undefined : item.id}
            >
              <div className={styles.cardTop}>
                <span className={styles.muted}>
                  {isProduct ? t('Order', 'ลำดับ') : t('Position', 'ลำดับที่')}{' '}
                  {isProduct ? item.sortOrder : index + 1}
                </span>
                {!isProduct && (
                  <button
                    type="button"
                    className={`${styles.iconButton} ${styles.storeDragHandle}`}
                    aria-label={t(
                      `Reorder ${item.name}. Use arrow keys to move it.`,
                      `จัดลำดับ ${item.name} ใช้ปุ่มลูกศรเพื่อย้าย`,
                    )}
                    aria-describedby="store-order-instructions"
                    aria-disabled={!canReorderStores}
                    title={t('Drag to reorder', 'ลากเพื่อจัดลำดับ')}
                    onPointerDown={(event) => startStoreDrag(event, item.id)}
                    onPointerMove={moveStoreDrag}
                    onPointerUp={endStoreDrag}
                    onPointerCancel={cancelStoreDrag}
                    onLostPointerCapture={cancelStoreDrag}
                    onKeyDown={(event) => moveStoreWithKeyboard(event, item.id)}
                  >
                    <GripVertical size={19} aria-hidden="true" />
                  </button>
                )}
              </div>
              <CatalogImage
                url={'imageUrl' in item ? item.imageUrl : item.logoImageUrl}
                name={item.name}
                product={isProduct}
              />
              <h3 className={styles.catalogName}>{item.name}</h3>
              {'imageUrl' in item && (
                <div className={styles.productStoreNames}>
                  <strong className={styles.productStoreLabel}>{t('Stores', 'ร้านค้า')}</strong>
                  {(productStoresById.get(item.id) ?? []).length ? (
                    (productStoresById.get(item.id) ?? []).map((id) => {
                      const store = data.stores.find((candidate) => candidate.id === id);
                      return store ? <span key={id}>{store.name}</span> : null;
                    })
                  ) : (
                    <span className={styles.unassignedStore}>
                      {t('Store not assigned', 'ยังไม่ได้กำหนดร้านค้า')}
                    </span>
                  )}
                </div>
              )}
              {'ownerName' in item && item.ownerName && (
                <p>
                  {t('Owner', 'เจ้าของร้าน')}: {item.ownerName}
                </p>
              )}
              <button
                className={`${styles.storeEdit} ${styles.catalogEdit}`}
                disabled={busy || !!draft}
                aria-label={`${t('Edit', 'แก้ไข')} ${item.name}`}
                onClick={() => begin(item)}
              >
                {isProduct ? t('Edit product', 'แก้ไขสินค้า') : t('Edit store', 'แก้ไขร้านค้า')}
                <Pencil size={17} />
              </button>
            </article>
          ))}
        </div>
      ) : (
        <div className={styles.empty}>
          <span className={styles.emptyIcon}>
            <Package size={28} />
          </span>
          <h3>
            {query
              ? t('No matching items', 'ไม่พบรายการที่ค้นหา')
              : isProduct && storeId !== 'all'
                ? t('No products for this store', 'ยังไม่มีสินค้าสำหรับร้านค้านี้')
                : isProduct
                  ? t('Add your first product', 'เพิ่มสินค้ารายการแรก')
                  : t('Add your first store', 'เพิ่มร้านค้าแรก')}
          </h3>
          <p>
            {query
              ? isProduct
                ? t('Try a different name or store.', 'ลองค้นด้วยชื่อหรือร้านค้าอื่น')
                : t('Try a different name or owner.', 'ลองค้นด้วยชื่อร้านหรือเจ้าของอื่น')
              : isProduct
                ? t(
                    'Add a product and choose the stores that offer it.',
                    'เพิ่มสินค้าและเลือกร้านค้าที่จำหน่าย',
                  )
                : t('Add a store to organize your catalog.', 'เพิ่มร้านค้าเพื่อจัดการรายการสินค้า')}
          </p>
        </div>
      )}
      {draggingStoreId &&
        dragSessionRef.current &&
        createPortal(
          <div
            ref={dragGhostRef}
            className={styles.storeDragGhost}
            style={{
              left: dragSessionRef.current.x + 12,
              top: dragSessionRef.current.y + 12,
            }}
            aria-hidden="true"
          >
            <GripVertical size={18} />
            <strong>{data.stores.find((store) => store.id === draggingStoreId)?.name}</strong>
          </div>,
          document.body,
        )}
    </div>
  );
}
