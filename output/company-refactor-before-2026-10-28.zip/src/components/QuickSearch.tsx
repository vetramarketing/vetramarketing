'use client';

import { useEffect, useId, useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react';
import {
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  BarChart3,
  ClipboardList,
  CornerDownLeft,
  FileText,
  LayoutDashboard,
  Package,
  Pin,
  Plus,
  Search,
  Settings2,
  Store as StoreIcon,
  Trash2,
  Users,
  X,
  type LucideIcon,
} from 'lucide-react';
import type { Locale, Post, Translate, View, Workspace } from '@/lib/types';
import { sortPosts } from '@/lib/post-tools';
import { sortCatalog } from '@/lib/catalog';
import styles from './QuickSearch.module.css';

interface QuickSearchProps {
  data: Workspace;
  locale: Locale;
  t: Translate;
  onClose: () => void;
  onNavigate: (view: View) => void;
  onOpenPost: (post: Post) => void;
  onSelectStore: (id: string) => void;
  onCreatePost: () => void;
}

interface SearchResult {
  key: string;
  label: string;
  detail: string;
  icon: LucideIcon;
  action: () => void;
  color?: string;
  date?: string;
}

interface ResultSection {
  key: string;
  label: string;
  results: SearchResult[];
}

const destinations: { view: View; en: string; th: string; keywords: string; icon: LucideIcon }[] = [
  {
    view: 'overview',
    en: 'Overview',
    th: 'ภาพรวม',
    keywords: 'dashboard home หน้าหลัก',
    icon: LayoutDashboard,
  },
  {
    view: 'posts',
    en: 'Post library',
    th: 'คลังโพสต์',
    keywords: 'published posts links เผยแพร่ ลิงก์โพสต์',
    icon: ClipboardList,
  },
  {
    view: 'groups',
    en: 'Facebook groups',
    th: 'กลุ่ม Facebook',
    keywords: 'communities ชุมชน',
    icon: Users,
  },
  {
    view: 'analytics',
    en: 'Performance',
    th: 'ผลลัพธ์',
    keywords: 'analytics viewers totals วิเคราะห์ ผู้ชม ยอดรวม',
    icon: BarChart3,
  },
  {
    view: 'products',
    en: 'Products',
    th: 'สินค้า',
    keywords: 'catalog image สินค้า รูปภาพ',
    icon: Package,
  },
  {
    view: 'stores',
    en: 'Stores & brands',
    th: 'ร้านค้าและแบรนด์',
    keywords: 'business ธุรกิจ',
    icon: StoreIcon,
  },
  {
    view: 'settings',
    en: 'Workspace settings',
    th: 'ตั้งค่าพื้นที่ทำงาน',
    keywords: 'backup restore data สำรอง กู้คืน ข้อมูล',
    icon: Settings2,
  },
  { view: 'trash', en: 'Trash', th: 'ถังขยะ', keywords: 'deleted restore ลบ กู้คืน', icon: Trash2 },
];

export default function QuickSearch({
  data,
  locale,
  t,
  onClose,
  onNavigate,
  onOpenPost,
  onSelectStore,
  onCreatePost,
}: QuickSearchProps) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const choosing = useRef(false);
  const id = useId();
  const listId = `${id}-results`;
  const titleId = `${id}-title`;
  const scopeId = `${id}-scope`;
  const normalized = query.trim().toLocaleLowerCase(locale);
  const matches = (...values: (string | undefined)[]) =>
    values.join(' ').toLocaleLowerCase(locale).includes(normalized);
  const storeLookup = new Map(data.stores.map((store) => [store.id, store]));
  const groupLookup = new Map(data.groups.map((group) => [group.id, group]));
  const activePosts = data.posts.filter((post) => !post.deletedAt);
  const postMatches = activePosts.filter((post) =>
    matches(
      post.product,
      storeLookup.get(post.storeId)?.name,
      post.platform === 'facebook' ? groupLookup.get(post.groupId)?.name : undefined,
    ),
  );
  const storeMatches = sortCatalog(data.stores).filter((store) =>
    matches(store.name, store.ownerName),
  );
  const number = (value: number) =>
    new Intl.NumberFormat(locale === 'th' ? 'th-TH' : 'en-US').format(value);
  const dateLabel = (value: string) =>
    value && Number.isFinite(Date.parse(value))
      ? new Intl.DateTimeFormat(locale === 'th' ? 'th-TH' : 'en-GB', {
          day: 'numeric',
          month: 'short',
          timeZone: 'Asia/Bangkok',
        }).format(new Date(value))
      : '';
  const quickActions: SearchResult[] = matches(
    'Add existing published post track',
    'เพิ่มโพสต์ เผยแพร่แล้ว ติดตาม',
  )
    ? [
        {
          key: 'create-post',
          label: t('Add post', 'เพิ่มโพสต์'),
          detail: t('Track a post that is already live', 'ติดตามโพสต์ที่เผยแพร่แล้ว'),
          icon: Plus,
          action: onCreatePost,
        },
      ]
    : [];
  const pageResults: SearchResult[] = destinations
    .filter((item) => matches(item.en, item.th, item.keywords))
    .map((item) => ({
      key: `page-${item.view}`,
      label: t(item.en, item.th),
      detail: t('Open page', 'เปิดหน้า'),
      icon: item.icon,
      action: () => onNavigate(item.view),
    }));
  const postResults: SearchResult[] = sortPosts(postMatches, 'recent', locale)
    .slice(0, normalized ? 8 : 4)
    .map((post) => ({
      key: `post-${post.id}`,
      label: post.product || t('Published post', 'โพสต์ที่เผยแพร่แล้ว'),
      detail: [
        post.pinned ? t('Pinned', 'ปักหมุด') : '',
        storeLookup.get(post.storeId)?.name,
        (post.platform === 'facebook' ? groupLookup.get(post.groupId)?.name : '') ||
          post.product ||
          post.platform,
      ]
        .filter(Boolean)
        .join(' · '),
      icon: post.pinned ? Pin : FileText,
      date: dateLabel(post.publishedAt),
      color: storeLookup.get(post.storeId)?.color,
      action: () => onOpenPost(post),
    }));
  const storeResults: SearchResult[] = storeMatches.slice(0, 6).map((store) => ({
    key: `store-${store.id}`,
    label: store.name,
    detail: t(
      `${number(activePosts.filter((post) => post.storeId === store.id).length)} posts · Switch store`,
      `${number(activePosts.filter((post) => post.storeId === store.id).length)} โพสต์ · เปลี่ยนร้านค้า`,
    ),
    icon: StoreIcon,
    color: store.color,
    action: () => onSelectStore(store.id),
  }));
  const sections: ResultSection[] = (
    normalized
      ? [
          { key: 'actions', label: t('Quick action', 'คำสั่งด่วน'), results: quickActions },
          { key: 'posts', label: t('Posts', 'โพสต์'), results: postResults },
          { key: 'stores', label: t('Stores', 'ร้านค้า'), results: storeResults },
          { key: 'pages', label: t('Go to', 'ไปที่'), results: pageResults },
        ]
      : [
          { key: 'actions', label: t('Quick action', 'คำสั่งด่วน'), results: quickActions },
          { key: 'pages', label: t('Go to', 'ไปที่'), results: pageResults },
          {
            key: 'posts',
            label: t('Pinned & recent posts', 'โพสต์ที่ปักหมุดและโพสต์ล่าสุด'),
            results: postResults,
          },
          { key: 'stores', label: t('Stores', 'ร้านค้า'), results: storeResults },
        ]
  ).filter((section) => section.results.length > 0);
  const results = sections.flatMap((section) => section.results);
  const selectedIndex = Math.min(activeIndex, Math.max(0, results.length - 1));
  const activeId = results.length ? `${id}-option-${selectedIndex}` : undefined;

  useLayoutEffect(() => {
    const element = dialogRef.current;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    if (element && !element.open) element.showModal();
    inputRef.current?.focus();
    return () => {
      element?.close();
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, []);

  useEffect(() => {
    resultRefs.current[selectedIndex]?.scrollIntoView({ block: 'nearest' });
  }, [selectedIndex, normalized]);

  function choose(result: SearchResult) {
    if (choosing.current) return;
    choosing.current = true;
    dialogRef.current?.close();
    onClose();
    // Let the dialog unmount and restore focus before opening the destination.
    requestAnimationFrame(result.action);
  }

  function moveSelection(event: KeyboardEvent<HTMLInputElement>) {
    if (event.nativeEvent.isComposing || !results.length) return;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      setActiveIndex(
        (selectedIndex + (event.key === 'ArrowDown' ? 1 : -1) + results.length) % results.length,
      );
    } else if (event.key === 'Enter') {
      event.preventDefault();
      choose(results[selectedIndex]);
    }
  }

  function moveFocusedResult(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
    event.preventDefault();
    const next = (index + (event.key === 'ArrowDown' ? 1 : -1) + results.length) % results.length;
    setActiveIndex(next);
    resultRefs.current[next]?.focus({ preventScroll: true });
  }

  let resultIndex = 0;
  return (
    <dialog
      ref={dialogRef}
      className={styles.dialog}
      aria-labelledby={titleId}
      aria-describedby={scopeId}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target !== event.currentTarget) return;
        const bounds = event.currentTarget.getBoundingClientRect();
        if (
          event.clientX < bounds.left ||
          event.clientX > bounds.right ||
          event.clientY < bounds.top ||
          event.clientY > bounds.bottom
        )
          onClose();
      }}
    >
      <div className={styles.heading}>
        <div className={styles.headingText}>
          <span className={styles.searchMark}>
            <Search size={20} />
          </span>
          <h2 id={titleId}>{t('Find your next move', 'ค้นหาสิ่งที่ต้องการ')}</h2>
        </div>
        <div className={styles.headingTools}>
          <kbd>Ctrl K</kbd>
          <button
            className={styles.closeButton}
            type="button"
            aria-label={t('Close search', 'ปิดการค้นหา')}
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
      </div>
      <div className={styles.searchBox}>
        <Search size={23} aria-hidden="true" />
        <input
          ref={inputRef}
          type="search"
          role="combobox"
          aria-label={t('Search posts, stores, and pages', 'ค้นหาโพสต์ ร้านค้า และหน้า')}
          aria-controls={listId}
          aria-expanded="true"
          aria-autocomplete="list"
          aria-activedescendant={activeId}
          aria-describedby={scopeId}
          autoComplete="off"
          spellCheck={false}
          value={query}
          placeholder={t('Search posts, stores, or a page…', 'ค้นหาโพสต์ ร้านค้า หรือหน้า…')}
          onChange={(event) => {
            setQuery(event.target.value);
            setActiveIndex(0);
          }}
          onKeyDown={moveSelection}
        />
        {query && (
          <button
            type="button"
            className={styles.clearButton}
            aria-label={t('Clear search', 'ล้างคำค้นหา')}
            onClick={() => {
              setQuery('');
              setActiveIndex(0);
              inputRef.current?.focus();
            }}
          >
            <X size={18} />
          </button>
        )}
      </div>
      <div className={styles.scope}>
        <span id={scopeId}>{t('Search across all stores', 'ค้นหาในทุกร้านค้า')}</span>
        <span aria-live="polite" aria-atomic="true">
          {normalized
            ? t(
                `${number(results.length)} ${results.length === 1 ? 'result' : 'results'} shown`,
                `แสดง ${number(results.length)} ผลลัพธ์`,
              )
            : t('Your workspace, one shortcut away', 'เข้าถึงพื้นที่ทำงานได้ในพริบตา')}
        </span>
      </div>
      <div
        id={listId}
        className={styles.results}
        role="listbox"
        aria-label={t('Search results', 'ผลการค้นหา')}
      >
        {sections.map((section) => (
          <div
            key={section.key}
            role="group"
            aria-labelledby={`${id}-section-${section.key}`}
            className={styles.section}
          >
            <div id={`${id}-section-${section.key}`} className={styles.sectionLabel}>
              {section.label}
              <span>{number(section.results.length)}</span>
            </div>
            {section.results.map((result) => {
              const index = resultIndex++;
              const Icon = result.icon;
              return (
                <button
                  key={result.key}
                  ref={(element) => {
                    resultRefs.current[index] = element;
                  }}
                  id={`${id}-option-${index}`}
                  className={`${styles.result} ${index === selectedIndex ? styles.activeResult : ''} ${result.key === 'create-post' ? styles.createResult : ''}`}
                  type="button"
                  role="option"
                  aria-selected={index === selectedIndex}
                  onFocus={() => setActiveIndex(index)}
                  onKeyDown={(event) => moveFocusedResult(event, index)}
                  onClick={() => choose(result)}
                >
                  <span
                    className={styles.resultIcon}
                    style={
                      result.color
                        ? { background: `color-mix(in srgb, ${result.color} 24%, var(--surface))` }
                        : undefined
                    }
                  >
                    <Icon size={20} />
                  </span>
                  <span className={styles.resultCopy}>
                    <strong>{result.label}</strong>
                    <span>{result.detail}</span>
                  </span>
                  <span className={styles.resultMeta}>
                    {result.date && <span className={styles.date}>{result.date}</span>}
                    <ArrowUpRight size={17} className={styles.resultArrow} aria-hidden="true" />
                  </span>
                </button>
              );
            })}
          </div>
        ))}
      </div>
      {!results.length && (
        <div className={styles.empty}>
          <span>
            <Search size={29} />
          </span>
          <h3>{t('No matches just yet', 'ยังไม่พบผลลัพธ์')}</h3>
          <p>{t('Try a product, store, or group name.', 'ลองค้นหาสินค้า ร้านค้า หรือกลุ่ม')}</p>
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setActiveIndex(0);
              inputRef.current?.focus();
            }}
          >
            {t('Clear search', 'ล้างคำค้นหา')}
          </button>
        </div>
      )}
      <footer className={styles.footer}>
        <div className={styles.shortcuts}>
          <span>
            <kbd>
              <ArrowUp size={13} />
              <ArrowDown size={13} />
            </kbd>
            {t('Navigate', 'เลื่อนเลือก')}
          </span>
          <span>
            <kbd>
              <CornerDownLeft size={15} />
            </kbd>
            {t('Open', 'เปิด')}
          </span>
          <span>
            <kbd>Esc</kbd>
            {t('Close', 'ปิด')}
          </span>
        </div>
        <span className={styles.footerNote}>
          {t('Posts in Trash are excluded', 'ไม่รวมโพสต์ในถังขยะ')}
        </span>
      </footer>
    </dialog>
  );
}
