'use client';

import { startTransition, useId, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { Check, X } from 'lucide-react';
import type { Translate } from '@/lib/types';
import s from './PostSortDialog.module.css';

export type SelectionTrigger = (open: boolean, openDialog: () => void) => ReactNode;

/** Keep open/close updates local so a large page does not render just to show a dialog. */
export function SelectionControl<T extends string>({
  title,
  options,
  value,
  t,
  onSelect,
  trigger,
  deferSelection = true,
}: {
  title: string;
  options: readonly {
    value: T;
    en: string;
    th: string;
    descriptionEn?: string;
    descriptionTh?: string;
  }[];
  value: T;
  t: Translate;
  onSelect: (value: T) => void;
  trigger: SelectionTrigger;
  deferSelection?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      {trigger(open, () => setOpen(true))}
      {open && (
        <SelectionDialog
          title={title}
          options={options}
          value={value}
          t={t}
          onSelect={onSelect}
          deferSelection={deferSelection}
          onClose={() => setOpen(false)}
        />
      )}
    </>
  );
}

export default function SelectionDialog<T extends string>({
  title,
  options,
  value,
  t,
  onSelect,
  onClose,
  deferSelection,
}: {
  title: string;
  options: readonly {
    value: T;
    en: string;
    th: string;
    descriptionEn?: string;
    descriptionTh?: string;
  }[];
  value: T;
  t: Translate;
  onSelect: (value: T) => void;
  onClose: () => void;
  deferSelection: boolean;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useLayoutEffect(() => {
    const element = dialog.current;
    const previousFocus = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    if (element && !element.open) element.showModal();
    (
      element?.querySelector<HTMLButtonElement>('[aria-pressed="true"]') ??
      element?.querySelector<HTMLButtonElement>('button')
    )?.focus({ preventScroll: true });
    return () => {
      if (element?.open) element.close();
      document.body.style.overflow = overflow;
      previousFocus?.focus({ preventScroll: true });
    };
  }, []);

  function dismiss() {
    // Close the top-layer dialog immediately; the parent can update its list afterwards.
    if (dialog.current?.open) dialog.current.close();
    onClose();
  }

  return (
    <dialog
      ref={dialog}
      className={s.dialog}
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault();
        dismiss();
      }}
      onClick={(event) => {
        if (event.target !== event.currentTarget) return;
        const rect = event.currentTarget.getBoundingClientRect();
        if (
          event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom
        )
          dismiss();
      }}
    >
      <header className={s.header}>
        <h2 id={titleId}>{title}</h2>
        <button type="button" className={s.close} onClick={dismiss} aria-label={t('Close', 'ปิด')}>
          <X size={20} aria-hidden="true" />
        </button>
      </header>
      <div className={s.options}>
        {options.map((option) => (
          <button
            type="button"
            key={option.value}
            className={s.option}
            aria-pressed={value === option.value}
            onClick={() => {
              dismiss();
              if (option.value !== value) {
                if (deferSelection) startTransition(() => onSelect(option.value));
                else onSelect(option.value);
              }
            }}
          >
            <span className={s.optionCopy}>
              <span>{t(option.en, option.th)}</span>
              {option.descriptionEn && option.descriptionTh && (
                <small>{t(option.descriptionEn, option.descriptionTh)}</small>
              )}
            </span>
            {value === option.value && <Check size={20} aria-hidden="true" />}
          </button>
        ))}
      </div>
    </dialog>
  );
}
