# VETRA Marketing

A Thai/English workspace for monitoring social posts that are already published across multiple stores. It tracks post links, actual publication dates, and each post's current Viewers total.

## Run locally

```powershell
npm.cmd install
npm.cmd run dev
```

Open http://127.0.0.1:3100. Thai is the initial language. The app saves the language choice in this browser.

```powershell
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
```

## Use the workspace

- Add an existing post with its actual publication date and HTTPS link. For Facebook group posts, a saved Group ID plus Post ID can generate the link.
- Enter the current Viewers total for each post. Updating it replaces the previous number; the overview and Performance page show current totals.
- Find published posts in one responsive list. Search, filter by platform, sort, or export CSV. The menu opens a navigation drawer on every screen size.
- Pin important posts with the button at the start of each post row. Pinned posts appear first in the library, overview, Performance, and quick search; the chosen sort still applies within pinned and unpinned posts. Pin state is saved with each post and included in CSV and JSON backups.
- Click a linked post title or a Post library row to open it in a new tab. The library stays open with its filters and scroll position. List state is also retained in browser history for reloads and returning from other navigation.
- Use **Reset all clicks** beside Export CSV in the Post library to clear today's counters for every post in this browser, including posts hidden by filters. Posts and Viewers totals are unchanged; counters still reset automatically at midnight ICT.
- Hovering a post link or focusing it with the keyboard hints the browser to warm the destination connection. Hovering a clickable library row does the same. Repeated hints are deduplicated; warming does not load the post or count as a click.
- Import existing posts from CSV with a preview and row validation. JSON backup/restore, store/group management, and 30-day Trash recovery are available in Settings and the drawer.
- In the Post library, use **Update Viewers** to paste a Meta table or select an HTML/TXT file. Preview matched posts, current-to-new totals, dates, and rows needing review before saving. The update replaces only the latest Viewers total and fills an unknown actual publication date when the source identifies it reliably; an optional publication year handles Meta dates without a year. Ambiguous, duplicate, lower-total, and unmatched rows are skipped.
- Products: name, optional HTTPS image URL, and sort order. The shared catalog supplies name suggestions in the post form. Existing post product/campaign text stays unchanged; catalog renaming or deletion does not rewrite posts.
- The requested **น้ำผึ้งดอกกาแฟ ESHAN 320g** product is added once on app load using `public/product/Clean ESHAN honey jar cutout.png`. The PNG is served locally; no Cloudinary upload occurs. A saved update marker prevents duplicates and respects later renaming/deletion. Matching products and custom images are preserved. The supplied label reads 380 grams; the name follows the user's explicit 320g text.
- Stores: name, optional HTTPS logo URL, owner name, and sort order. Lower sort numbers appear first in cards and store selectors. Older initials, colors, and descriptions remain in saved data for compatibility.
- Delete products from their editor and restore them from Trash within 30 days. Product images and store logos have a placeholder when blank or unavailable. Catalog data is included in JSON backups; CSV remains a post-only export.
- There is no automatic publishing, live social metrics connection, team login, or cloud sync.

## Data and migration

Active data stays in this browser under `vetra-marketing.workspace.v7`. It includes the product catalog, store profiles, publishing destinations, post pin state, and optional Cloudinary asset metadata. Only existing published posts are active; the actual publication date can be unknown. Post title, content, status, planned date, and dated Viewer history are absent from v7 storage, JSON backups, and CSV exports. Older records without a pin field load as unpinned.

On first load, v1–v6 workspaces migrate to v7 with published records, their IDs and links, and only the latest Viewers total. Exact, unique product-name matches receive a stable product ID; all posts keep their saved product-name snapshot. Group destinations and identifiable page/account destinations are linked without guessing from ambiguous links. Earlier localStorage keys remain untouched for recovery; Settings can download those original workspaces, which may include older history or unpublished records. Built-in sample posts without real links are excluded from the active monitor. A new installation starts with an empty workspace.

Cloudinary data and upload/save contracts are prepared for product images and store logos. Uploads and remote deletion are not enabled. Existing image URLs remain supported; optional asset IDs survive saves, backups, and Trash. See `docs/CLOUDINARY_WORKFLOW.md` and `.env.example` for the server setup and remaining API work. Never put secrets in browser settings or `NEXT_PUBLIC_` variables.

Browser storage can be cleared by the user or browser. Download backups regularly. Corrupt saved data is preserved and edits are blocked until a valid restore. A shared deployment would need authentication, per-workspace authorization, and server persistence. No social account credentials are stored here.

Viewer totals are summed per post and may count the same people across posts. The app does not calculate daily growth or retain a measurement timeline in its active data.

## Code

- `src/components/MarketingApp.tsx`: navigation, list, overview, analytics, and persistence.
- `src/components/PostEditor.tsx`: published-post editor and current Viewers total.
- `src/components/ImportDialog.tsx`: CSV review and import.
- `src/components/MetaUpdateDialog.tsx`: Meta table review and Viewers update.
- `src/components/CatalogPanel.tsx`: simple product and store editors, images, search, and sorting.
- `src/components/WorkspacePanels.tsx`: groups, settings, and Trash.
- `src/lib/mongodb-catalog.ts`: prepared product/store document types, save request types, index definitions, and validated migration mapping; no network connection.
- `src/lib/cloudinary-media.ts` and `src/lib/catalog-media-contract.ts`: media metadata, validation, scoped upload plans, and temporary submission contracts; no network connection.
- `src/lib/workspace-storage.ts`: versioned storage and legacy migration.
- `src/lib/csv.ts`: CSV parsing, import validation, and export.
- `src/lib/meta-viewers-import.ts`: safe Meta row matching and current-total update planning.
- `src/lib/data.ts`: schema validation, URLs, retention, and Viewers totals.

Read `AGENTS.md` and the project documents before further changes. See `docs/MONGODB_WORKFLOW.md` for the future API and migration workflow.
